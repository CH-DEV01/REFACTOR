package com.davivienda.factoraje.domain.enums;

public enum GeneralStatus {

    ACTIVE,
    INACTIVE
    
}