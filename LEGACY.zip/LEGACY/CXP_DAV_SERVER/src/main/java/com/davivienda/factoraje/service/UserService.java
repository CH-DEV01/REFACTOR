package com.davivienda.factoraje.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import com.davivienda.factoraje.domain.dto.Users.AssignRolesToUserRequestDTO;
import com.davivienda.factoraje.domain.dto.Users.UserDTORequest;
import com.davivienda.factoraje.domain.dto.Users.UserDTOResponse;
import com.davivienda.factoraje.domain.dto.supplier.SupplierDTORequest;
import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.domain.model.RoleModel;
import com.davivienda.factoraje.domain.model.UserModel;
import com.davivienda.factoraje.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.RoleRepository;
import com.davivienda.factoraje.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);
    private final UserRepository userRepository;
    private final RoleService roleService;
    private final RoleRepository roleRepository;
    private final EntityRepository entityRepository;

    public UserService(UserRepository userRepository, RoleService roleService, EntityRepository entityRepository, RoleRepository roleRepository) {
        this.userRepository = userRepository;
        this.roleService = roleService;
        this.roleRepository = roleRepository;
        this.entityRepository = entityRepository;
        log.info("UserService initialized");
    }

    public List<UserModel> getAll() {
        log.debug("Fetching all users");
        return userRepository.findAll();
    }

    @Transactional
    public void deleteUser(UUID id) {

        if (!userRepository.existsById(id)) {
            throw new IllegalArgumentException("Usuario no encontrado con el ID: " + id);
        }

        userRepository.deleteById(id);
    }

    public List<UserModel> getPayers() {
        log.debug("Fetching payers");
        return userRepository.findAll().stream()
                .filter(u -> u.getRole() != null && "PAYER".equals(u.getRole().getRoleName()))
                .collect(Collectors.toList());
    }

    public UserModel createPayer(UserModel payer) {
        if (payer == null) {
            throw new IllegalArgumentException("El cuerpo de la petición no puede ser nulo");
        }
        RoleModel payerRole = roleService.getByRoleName("PAYER");
        if (payerRole == null) {
            throw new ResourceNotFoundException("Rol PAYER no existe");
        }
        payer.setRole(payerRole);
        log.debug("Saving new payer {} with role PAYER", payer.getEmail());
        return userRepository.save(payer);
    }

    public UserDTOResponse updateUser(UUID id, UserDTORequest dto) {

        UserModel user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar: ID no existe"));

        EntityModel entity = entityRepository.findById(dto.getEntityId())
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar: ID no existe"));

        RoleModel role = roleRepository.findById(dto.getRoleId())
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar: ID no existe"));

        user.setName(dto.getName());
        user.setDui(dto.getDui());
        user.setEmail(dto.getEmail());
        user.setEntity(entity);
        user.setRole(role);

        UserModel userUpdated = new UserModel();
        userUpdated = userRepository.save(user);

        UserDTOResponse response = new UserDTOResponse();

        response.setId(userUpdated.getId());
        response.setName(userUpdated.getName());

        return response;
    }

    public UserModel findByEmail(String email) {

        if (email == null) {
            throw new IllegalArgumentException("El email no puede ser nulo o vacío");
        }

        UserModel user = userRepository.findByEmail(email);

        if (user == null) {
            throw new ResourceNotFoundException("Usuario no encontrado con email=" + email);
        }

        return user;
    }

    public UserModel save(UserModel user) {

        if (user == null) {
            throw new IllegalArgumentException("El objeto de usuario no puede ser nulo");
        }

        return userRepository.save(user);
    }

    public UserModel getUserById(UUID id) {
        if (id == null) {
            throw new IllegalArgumentException("El id de usuario no puede ser nulo");
        }
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));
    }

    public UserModel assignRolesToUser(AssignRolesToUserRequestDTO dto) {
        if (dto == null || dto.getUserId() == null ||
                dto.getRoleIds() == null || dto.getRoleIds().isEmpty()) {
            throw new IllegalArgumentException("UserId u objeto dto no pueden ser null");
        }

        UserModel user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));

        for (UUID roleId : dto.getRoleIds()) {
            RoleModel role = roleService.findByIdEntity(roleId);
            user.setRole(role);
        }
        log.debug("Roles assigned to user {}", user.getId());
        return userRepository.save(user);
    }

    public UserModel findUserByDUI(String dui) {
        if (dui == null) {
            throw new IllegalArgumentException("El dui del usuario no puede ser nulo");
        }
        return userRepository.findByDui(dui)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));
    }

}
