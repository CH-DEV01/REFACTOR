package com.davivienda.factoraje.domain.dto.agreement;

import java.util.List;
import java.util.UUID;

import com.davivienda.factoraje.domain.dto.document.DocumentResponseDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgreementResumeDTOResponse {
    private UUID id; 
    private String name;
    private String identifier;
    private UUID payer;
    private UUID supplier;

    private List<DocumentResponseDTO> documents;
}