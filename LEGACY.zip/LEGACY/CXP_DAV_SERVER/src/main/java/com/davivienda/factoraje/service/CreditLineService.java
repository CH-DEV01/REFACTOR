package com.davivienda.factoraje.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.davivienda.factoraje.domain.dto.creditLine.CreditLineDetailsResponseDTO;
import com.davivienda.factoraje.domain.dto.creditLine.CreditLineHistoryDTO;
import com.davivienda.factoraje.domain.dto.creditLine.CreditLineMetricsDTO;
import com.davivienda.factoraje.domain.dto.creditLine.PayerOptionDTO;
import com.davivienda.factoraje.domain.dto.creditLine.RepaymentRequestDTO;
import com.davivienda.factoraje.domain.dto.creditLine.RepaymentResponseDTO;
import com.davivienda.factoraje.domain.model.CreditLineHistoryModel;
import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.domain.model.UserModel;
import com.davivienda.factoraje.repository.CreditLineHistoryRepository;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class CreditLineService {

    private final EntityRepository entityRepository;
    private final CreditLineHistoryRepository historyRepository;
    private final UserRepository userRepository;

    // =======================================================================
    // 1. OBTENER DETALLES Y MÉTRICAS
    // =======================================================================
    @Transactional()
    public CreditLineDetailsResponseDTO getCreditLineDetails(UUID payerId) {
        EntityModel payer = entityRepository.findById(payerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pagador no encontrado"));

        // 1. Cálculos de utilización
        BigDecimal totalLimit = payer.getCreditLineLimit() != null ? payer.getCreditLineLimit() : BigDecimal.ZERO;
        BigDecimal consumed = payer.getCurrentConsumed() != null ? payer.getCurrentConsumed() : BigDecimal.ZERO;
        BigDecimal available = payer.getAvailableLimit() != null ? payer.getAvailableLimit() : BigDecimal.ZERO;

        BigDecimal utilizationRate = BigDecimal.ZERO;
        if (totalLimit.compareTo(BigDecimal.ZERO) > 0) {
            utilizationRate = consumed.divide(totalLimit, 4, RoundingMode.HALF_UP).multiply(new BigDecimal("100"));
        }

        String riskStatus = utilizationRate.compareTo(new BigDecimal("85.00")) > 0 ? "CRITICAL" : "NORMAL";

        // 2. Historial reciente (Ejemplo: últimos 10 movimientos)
        List<CreditLineHistoryModel> recentHistory = historyRepository.findTop10ByPayerOrderByExecutionDateDesc(payer);

        BigDecimal lastAmount = BigDecimal.ZERO;
        LocalDateTime lastDate = null;

        if (!recentHistory.isEmpty()) {
            lastAmount = recentHistory.get(0).getAmount();
            lastDate = recentHistory.get(0).getExecutionDate();
        }

        List<CreditLineHistoryDTO> historyDTOs = recentHistory.stream().map(h -> CreditLineHistoryDTO.builder()
                .id(h.getId())
                .reference(h.getReferenceNumber())
                .date(h.getExecutionDate())
                .amount(h.getAmount())
                .operatorId(h.getExecutedBy())
                .operator(h.getExecutedByUser())
                .build()).collect(Collectors.toList());

        // 3. Armar Respuesta
        CreditLineMetricsDTO metrics = CreditLineMetricsDTO.builder()
                .totalLimit(totalLimit)
                .currentConsumed(consumed)
                .availableLimit(available)
                .utilizationRate(utilizationRate.setScale(2, RoundingMode.HALF_UP))
                .averageMaturityDays(42) // Esto se actualizará luego con el cálculo real de facturas
                .riskStatus(riskStatus)
                .lastRepaymentAmount(lastAmount)
                .lastRepaymentDate(lastDate)
                .build();

        return new CreditLineDetailsResponseDTO(metrics, historyDTOs);
    }

    // =======================================================================
    // 2. REDENCIÓN CON BLOQUEO PESIMISTA
    // =======================================================================
    @Transactional
    public RepaymentResponseDTO restoreCreditLine(RepaymentRequestDTO request) {

        EntityModel payer = entityRepository.findByIdForUpdate(request.getPayerId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pagador no encontrado"));

        UserModel user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado"));

        BigDecimal amountToRestore = request.getAmount();
        BigDecimal currentConsumed = payer.getCurrentConsumed() != null ? payer.getCurrentConsumed() : BigDecimal.ZERO;

        if (amountToRestore.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El monto debe ser mayor a cero.");
        }
        if (amountToRestore.compareTo(currentConsumed) > 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "El abono excede el consumo actual.");
        }

        // Matemáticas Seguras
        BigDecimal newConsumed = currentConsumed.subtract(amountToRestore);
        BigDecimal newAvailable = payer.getCreditLineLimit().subtract(newConsumed);

        BigDecimal newUtilization = BigDecimal.ZERO;
        if (payer.getCreditLineLimit().compareTo(BigDecimal.ZERO) > 0) {
            newUtilization = newConsumed.divide(payer.getCreditLineLimit(), 4, RoundingMode.HALF_UP)
                    .multiply(new BigDecimal("100"));
        }

        payer.setCurrentConsumed(newConsumed);
        payer.setAvailableLimit(newAvailable);
        entityRepository.save(payer);

        // Registro de Auditoría
        CreditLineHistoryModel auditLog = new CreditLineHistoryModel();
        auditLog.setPayer(payer);
        auditLog.setAmount(amountToRestore);
        auditLog.setReferenceNumber(request.getReference());
        auditLog.setRepaymentType(request.getType());
        auditLog.setExecutionDate(LocalDateTime.now());
        auditLog.setExecutedBy(request.getUserId());
        auditLog.setExecutedByUser(user.getName());
        historyRepository.save(auditLog);

        return new RepaymentResponseDTO(newConsumed, newAvailable, newUtilization.setScale(2, RoundingMode.HALF_UP));
    }

    @Transactional()
    public List<PayerOptionDTO> getPayerOptions() {
        // Nota: Si en tu lógica de negocio un 'Pagador' se identifica con entityType =
        // true,
        // puedes cambiar findAll() por algo como
        // entityRepository.findByEntityType(true)
        return entityRepository.findByEntityType(true).stream()
                .map(entity -> new PayerOptionDTO(
                        entity.getId(),
                        entity.getName()))
                .collect(Collectors.toList());
    }

    // =======================================================================
    // 4. CONSUMO DE LÍNEA (Invocado automáticamente al financiar facturas)
    // =======================================================================
    @Transactional
    public void consumeCreditLine(UUID payerId, BigDecimal amountToConsume, String referenceInvoice) {

        // Aplicamos el candado SELECT FOR UPDATE para que nadie altere los saldos en
        // este milisegundo
        EntityModel payer = entityRepository.findByIdForUpdate(payerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pagador no encontrado"));

        BigDecimal availableLimit = payer.getAvailableLimit() != null ? payer.getAvailableLimit() : BigDecimal.ZERO;
        BigDecimal currentConsumed = payer.getCurrentConsumed() != null ? payer.getCurrentConsumed() : BigDecimal.ZERO;

        // CONTROL DE RIESGO: Validador de sobregiro de línea
        if (amountToConsume.compareTo(availableLimit) > 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Fondos insuficientes en la línea de crédito. Cupo disponible: " + availableLimit);
        }

        // Matemáticas de consumo
        BigDecimal newConsumed = currentConsumed.add(amountToConsume);
        BigDecimal newAvailable = payer.getCreditLineLimit().subtract(newConsumed);

        payer.setCurrentConsumed(newConsumed);
        payer.setAvailableLimit(newAvailable);
        entityRepository.save(payer);

        // Registro automático en el historial (Asiento contable de cargo)
        CreditLineHistoryModel auditLog = new CreditLineHistoryModel();
        auditLog.setPayer(payer);
        auditLog.setAmount(amountToConsume.negate()); // Guardarlo en negativo o manejar una bandera de tipo "CARGO"
        auditLog.setReferenceNumber("FINAN-" + referenceInvoice);
        auditLog.setRepaymentType("CONSUMPTION");
        auditLog.setExecutionDate(LocalDateTime.now());
        auditLog.setExecutedBy(UUID.fromString("00000000-0000-0000-0000-000000000000")); // ID del Sistema / Bot

        historyRepository.save(auditLog);
    }
}