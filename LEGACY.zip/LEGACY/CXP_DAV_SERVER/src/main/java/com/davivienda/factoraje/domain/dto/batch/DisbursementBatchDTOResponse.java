package com.davivienda.factoraje.domain.dto.batch;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DisbursementBatchDTOResponse {

    private UUID id;
    private String batchNumber;
    private BigDecimal totalAmount;
    private BigDecimal totalCommission;
    private String status;
    private String createdByUserName; 
    private String createdAt; 
    private String executionDate; 
    private Integer documentCount;

    // Lista opcional de documentos anidados (se llena solo cuando se pide el detalle del lote)
    private List<DocumentPreviewDTO> documents;

}
