package com.davivienda.factoraje.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

@Service
public class BatchExcelService {

    // Inyecta aquí tus repositorios
    // private final DocumentRepository documentRepository;

    public byte[] generateDisbursementExcel(String payerId) {
        
        // 1. Obtener los documentos listos para este pagador (Reemplaza con tu lógica real)
        // List<DocumentModel> documents = documentRepository.findByPayerIdAndStatus(payerId, "SELECTED");

        // 2. Crear el libro y la hoja de Excel en memoria
        try (Workbook workbook = new XSSFWorkbook(); 
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Lote_Desembolso");

            // 3. Crear estilo para la cabecera (Negrita y fondo gris)
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // 4. Escribir la Fila de Cabeceras
            Row headerRow = sheet.createRow(0);
            String[] headers = {
                "ID Documento", "NIT Proveedor", "Nombre Proveedor", 
                "Cuenta Bancaria", "Monto Nominal", "Comisión", "Neto a Desembolsar"
            };

            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // 5. Llenar los datos de las filas
            int rowIdx = 1;
            /* DESCOMENTA Y USA TU LISTA DE DOCUMENTOS:
            for (DocumentModel doc : documents) {
                Row row = sheet.createRow(rowIdx++);

                row.createCell(0).setCellValue(doc.getId().toString());
                row.createCell(1).setCellValue(doc.getSupplier().getNit());
                row.createCell(2).setCellValue(doc.getSupplier().getName());
                row.createCell(3).setCellValue(doc.getSupplier().getBankAccount());
                
                // Formato de números
                row.createCell(4).setCellValue(doc.getAmountToFinance().doubleValue());
                row.createCell(5).setCellValue(doc.getCommission().doubleValue());
                
                // Cálculo Neto
                double neto = doc.getAmountToFinance().subtract(doc.getCommission()).doubleValue();
                row.createCell(6).setCellValue(neto);
            }
            */

            // Ejemplo de fila dummy para que pruebes que funciona:
            Row dummyRow = sheet.createRow(rowIdx);
            dummyRow.createCell(0).setCellValue("DOC-123");
            dummyRow.createCell(1).setCellValue("0614-...");
            dummyRow.createCell(2).setCellValue("Proveedor de Prueba S.A.");
            dummyRow.createCell(3).setCellValue("1234567890");
            dummyRow.createCell(4).setCellValue(1000.00);
            dummyRow.createCell(5).setCellValue(50.00);
            dummyRow.createCell(6).setCellValue(950.00);

            // Auto-ajustar el ancho de las columnas
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // 6. Volcar el Excel al Output Stream de bytes
            workbook.write(out);
            return out.toByteArray();

        } catch (IOException e) {
            throw new RuntimeException("Error crítico al generar el archivo Excel", e);
        }
    }
}
