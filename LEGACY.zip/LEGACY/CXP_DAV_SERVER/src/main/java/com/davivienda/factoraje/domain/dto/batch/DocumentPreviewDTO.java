package com.davivienda.factoraje.domain.dto.batch;

import java.math.BigDecimal;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DocumentPreviewDTO {
    
    private UUID id;
    private String documentNumber;
    private String supplierName;
    private BigDecimal amountToFinance;
    
}