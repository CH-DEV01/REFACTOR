package com.davivienda.factoraje.domain.dto.creditLine;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreditLineDetailsResponseDTO {
    private CreditLineMetricsDTO metrics;
    private List<CreditLineHistoryDTO> history;
}