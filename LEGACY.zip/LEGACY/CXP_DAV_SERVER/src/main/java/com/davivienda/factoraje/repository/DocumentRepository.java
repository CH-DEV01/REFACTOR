package com.davivienda.factoraje.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.model.DocumentModel;

@Repository
public interface DocumentRepository extends JpaRepository<DocumentModel, UUID> {

        Optional<DocumentModel> findByDocumentNumber(String documentNumber);

        /**
         * Busca todos los documentos vinculados a un lote específico.
         */
        List<DocumentModel> findByDisbursementBatchId(UUID batchId);

        /**
         * Busca documentos filtrando por el ID del pagador (payer) que está dentro del
         * Acuerdo,
         * y por su estado actual (ej. "APPROVED").
         */
        @Query("SELECT d FROM DocumentModel d WHERE d.agreement.payer = :payerId AND d.status = :status")
        List<DocumentModel> findReadyDocumentsByPayer(
                        @Param("payerId") UUID payerId,
                        @Param("status") String status);

        /**
         * Busca todos los documentos aprobados de un PAGADOR específico (a través de
         * sus acuerdos)
         * cuya fecha de desembolso programada sea igual o menor a la fecha límite.
         */
        @Query("SELECT d FROM DocumentModel d " +
                        "WHERE d.status = 'SELECTED' " +
                        "AND d.agreement.payer = :payerId " + // Navega al acuerdo y filtra por el UUID del pagador
                        "AND d.scheduledDisbursementDate <= :limitDate " +
                        "ORDER BY d.scheduledDisbursementDate ASC")
        List<DocumentModel> findReadyForDisbursement(
                        @Param("payerId") UUID payerId,
                        @Param("limitDate") LocalDate limitDate);

        @Query("SELECT COUNT(d) FROM DocumentModel d " +
                        "WHERE d.status = 'SELECTED' " +
                        "AND d.agreement.payer = :payerId " +
                        "AND d.scheduledDisbursementDate <= :limitDate")
        Integer countReadyForDisbursement(
                        @Param("payerId") UUID payerId,
                        @Param("limitDate") LocalDate limitDate);

}
