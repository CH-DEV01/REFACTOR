package com.davivienda.factoraje.service;

import java.math.BigDecimal;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.disclaimer.DisclaimerDTOResponse;
import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.repository.EntityRepository;

@Service
public class DisclaimerService {

    private static final Logger log = LoggerFactory.getLogger(DisclaimerService.class);
    private final EntityRepository entityRepository;

    public DisclaimerService(EntityRepository entityRepository) {
        this.entityRepository = entityRepository;
        log.info("DisclaimerService initialized");
    }

    public DisclaimerDTOResponse getDisclaimerBody(UUID entityId) {

        System.out.println(entityId);

        EntityModel entity = entityRepository.findById(entityId)
                .orElseThrow(() -> new RuntimeException("No se encontró la entidad con el ID: " + entityId));

        DisclaimerDTOResponse response = new DisclaimerDTOResponse();

        response.setEntityId(entity.getId());
        response.setInterestRate(entity.getInterestRate());
        response.setBenchmarkInterestRate(BigDecimal.valueOf(0.00));
        response.setPercentagePoints("12");

        return response;

    }

}
