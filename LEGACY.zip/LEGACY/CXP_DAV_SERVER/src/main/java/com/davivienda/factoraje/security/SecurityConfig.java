package com.davivienda.factoraje.security;

public class SecurityConfig {
    
}
