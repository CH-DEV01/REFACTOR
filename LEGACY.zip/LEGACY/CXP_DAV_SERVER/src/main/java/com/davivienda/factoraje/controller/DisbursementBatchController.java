package com.davivienda.factoraje.controller;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.batch.ConfirmBatchDTORequest;
import com.davivienda.factoraje.domain.dto.batch.CreateBatchDTORequest;
import com.davivienda.factoraje.domain.dto.batch.DisbursementBatchDTOResponse;
import com.davivienda.factoraje.domain.dto.batch.DocumentPreviewDTO;
import com.davivienda.factoraje.domain.dto.common.ApiResponse;
import com.davivienda.factoraje.domain.model.DisbursementBatchModel;
import com.davivienda.factoraje.domain.model.DocumentModel;
import com.davivienda.factoraje.service.DisbursementBatchService;
import com.davivienda.factoraje.service.ExcelGeneratorService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("api/batch")
public class DisbursementBatchController {

    private final DisbursementBatchService batchService;
    private final ExcelGeneratorService excelGeneratorService;
    private static final Logger log = LoggerFactory.getLogger(DisbursementBatchController.class);

    public DisbursementBatchController(DisbursementBatchService disbursementBatchService,
            ExcelGeneratorService excelGeneratorService) {

        this.batchService = disbursementBatchService;
        this.excelGeneratorService = excelGeneratorService;

    }

    @GetMapping("/preview/{payerId}")
    public ResponseEntity<ApiResponse<List<DocumentPreviewDTO>>> getPreview(@PathVariable UUID payerId) {
        log.info("Solicitando vista previa de lote para pagador: {}", payerId);

        List<DocumentModel> docs = batchService.getPreviewDocuments(payerId);

        List<DocumentPreviewDTO> dtoList = docs.stream().map(d -> new DocumentPreviewDTO(
                d.getDocument_id(),
                d.getDocumentNumber(),
                d.getSupplierName(),
                d.getAmountToFinance())).collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.success(dtoList, "Vista previa generada correctamente."));
    }

    @PostMapping(value = "/generate", produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    public ResponseEntity<byte[]> generateBatch(
            @Valid @RequestBody CreateBatchDTORequest requestDTO,
            @RequestParam UUID userId,
            HttpServletRequest request) throws Exception {

        log.info("Generando lote solicitado por usuario: {}", userId);

        String ipAddress = extractIpAddress(request);
        String userAgent = request.getHeader("User-Agent");

        // 1. Persistir el lote y cambiar estados en Base de Datos
        DisbursementBatchModel batch = batchService.createBatch(requestDTO, userId, ipAddress, userAgent);

        // 2. Generar el archivo binario Excel
        byte[] excelBytes = excelGeneratorService.generarExcelDeLote(batch);

        // 3. Configurar cabeceras de respuesta para forzar descarga
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(
                MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDispositionFormData("attachment", batch.getBatchNumber() + ".xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excelBytes);
    }

    @GetMapping("/history")
    public ResponseEntity<ApiResponse<List<DisbursementBatchDTOResponse>>> getBatchHistory() {
        List<DisbursementBatchModel> batches = batchService.getBatchHistory();

        List<DisbursementBatchDTOResponse> responseList = batches.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(ApiResponse.success(responseList, "Historial de lotes generado correctamente."));
    }

    @GetMapping("/{batchId}")
    public ResponseEntity<ApiResponse<DisbursementBatchDTOResponse>> getBatchDetails(@PathVariable UUID batchId) {
        DisbursementBatchModel batch = batchService.getBatchDetails(batchId);

        // Aquí pasamos true para que el mapeador incluya la lista de documentos en el
        // DTO
        DisbursementBatchDTOResponse responseDTO = mapToDTOWithDocuments(batch);

        return ResponseEntity.ok(ApiResponse.success(responseDTO, "Detalle de lote generado correctamente."));

    }

    @PutMapping("/{batchId}/confirm")
    public ResponseEntity<ApiResponse<DisbursementBatchDTOResponse>> confirmBatch(
            @PathVariable UUID batchId,
            @Valid @RequestBody ConfirmBatchDTORequest requestDTO,
            @RequestParam UUID userId,
            HttpServletRequest request) {

        log.info("Confirmando lote {} solicitado por usuario: {}", batchId, userId);

        String ipAddress = extractIpAddress(request);
        String userAgent = request.getHeader("User-Agent");

        DisbursementBatchModel batch = batchService.updateBatch(
                batchId, requestDTO, userId, ipAddress, userAgent);

        DisbursementBatchDTOResponse responseDTO = mapToDTO(batch);

        return ResponseEntity.ok(ApiResponse.success(responseDTO, "Bath de desembolsos confirmado correctamente."));

    }

    private String extractIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            return request.getRemoteAddr();
        }
        return ip.split(",")[0].trim();
    }

    private DisbursementBatchDTOResponse mapToDTO(DisbursementBatchModel batch) {
        DisbursementBatchDTOResponse dto = new DisbursementBatchDTOResponse();
        dto.setId(batch.getId());
        dto.setBatchNumber(batch.getBatchNumber());
        dto.setTotalAmount(batch.getTotalAmount());
        dto.setTotalCommission(batch.getTotalCommission());
        dto.setStatus(batch.getStatus());
        dto.setCreatedByUserName(batch.getCreatedBy() != null ? batch.getCreatedBy().getName() : "N/A");
        dto.setCreatedAt(batch.getCreatedAt() != null ? batch.getCreatedAt().toString() : null);
        dto.setExecutionDate(batch.getExecutionDate() != null ? batch.getExecutionDate().toString() : null);
        dto.setDocumentCount(batch.getDocuments() != null ? batch.getDocuments().size() : 0);
        return dto;
    }

    private DisbursementBatchDTOResponse mapToDTOWithDocuments(DisbursementBatchModel batch) {
        DisbursementBatchDTOResponse dto = mapToDTO(batch);

        if (batch.getDocuments() != null) {
            List<DocumentPreviewDTO> docDTOs = batch.getDocuments().stream().map(d -> new DocumentPreviewDTO(
                    d.getDocument_id(),
                    d.getDocumentNumber(),
                    d.getSupplierName(),
                    d.getAmountToFinance())).collect(Collectors.toList());

            dto.setDocuments(docDTOs);
        }

        return dto;
    }

    @GetMapping(value = "/{batchId}/download", produces = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    public ResponseEntity<byte[]> downloadExistingBatch(@PathVariable UUID batchId) throws Exception {

        // 1. Buscamos el lote (Asume que ya tienes este método o usa tu repository)
        DisbursementBatchModel batch = batchService.getBatchDetails(batchId);

        // 2. Volvemos a generar el archivo binario usando el servicio que creamos antes
        byte[] excelBytes = excelGeneratorService.generarExcelDeLote(batch);

        // 3. Retornamos el archivo
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(
                MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDispositionFormData("attachment", batch.getBatchNumber() + ".xlsx");

        return ResponseEntity.ok()
                .headers(headers)
                .body(excelBytes);
    }

}
