package com.davivienda.factoraje.domain.dto.disclaimer;

import java.math.BigDecimal;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DisclaimerDTOResponse {

    private UUID entityId;
    private BigDecimal interestRate;
    private BigDecimal benchmarkInterestRate;
    private String percentagePoints;
    
}
