package com.davivienda.factoraje.controller;

import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.common.ApiResponse;
import com.davivienda.factoraje.domain.dto.logDocument.LogDocumentDTOResponse;
import com.davivienda.factoraje.service.AuditLogService;

@RestController
@RequestMapping("/api/logs")
public class AuditLogController {

    private final AuditLogService auditLogService;
    private static final Logger log = LoggerFactory.getLogger(AuditLogController.class);

    public AuditLogController(AuditLogService auditLogService) {

        this.auditLogService = auditLogService;
        log.info("AuditLogController initialized");

    }

    @GetMapping("/{documentId}")
    public ResponseEntity<ApiResponse<List<LogDocumentDTOResponse>>> getLogDocument(
            @PathVariable UUID documentId) {

        // 1. Obtenemos la lista de DTOs desde el servicio
        List<LogDocumentDTOResponse> logs = auditLogService.getLogDocument(documentId);

        return ResponseEntity.ok(ApiResponse.success(logs, "Logs del documento obtenidos correctamente."));
    }
}
