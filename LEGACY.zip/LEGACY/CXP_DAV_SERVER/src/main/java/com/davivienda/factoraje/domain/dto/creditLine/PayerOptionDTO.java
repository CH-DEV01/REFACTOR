package com.davivienda.factoraje.domain.dto.creditLine;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PayerOptionDTO {
    private UUID id;
    private String name;
}