package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.model.EntityModel;

import jakarta.persistence.LockModeType;

@Repository
public interface EntityRepository extends JpaRepository<EntityModel, UUID> {
    Optional<EntityModel> findByCode(String code);

    @Query("SELECT e FROM EntityModel e WHERE e.entityType = :type")
    Optional<EntityModel> findByEntityType(@Param("type") Boolean type);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT e FROM EntityModel e WHERE e.id = :id")
    Optional<EntityModel> findByIdForUpdate(@Param("id") UUID id);
}
