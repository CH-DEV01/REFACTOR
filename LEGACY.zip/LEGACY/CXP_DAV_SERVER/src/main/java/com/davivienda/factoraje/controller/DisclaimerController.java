package com.davivienda.factoraje.controller;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.common.ApiResponse;
import com.davivienda.factoraje.domain.dto.disclaimer.DisclaimerDTORequest;
import com.davivienda.factoraje.domain.dto.disclaimer.DisclaimerDTOResponse;
import com.davivienda.factoraje.service.DisclaimerService;

@RestController
@RequestMapping("/api/disclaimers")
public class DisclaimerController {

    private final DisclaimerService disclaimerService;
    //private static final java.util.logging.Logger log = LoggerFactory.getLogger(DisclaimerController.class);

    public DisclaimerController(DisclaimerService disclaimerService) {
        this.disclaimerService = disclaimerService;
        //log.info("Disclaimer controller initialized");
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<DisclaimerDTOResponse>> getDisclaimerBody(@PathVariable UUID id) {

        // Mensaje corregido para reflejar una lectura, no una creación
       System.out.println(id);

       DisclaimerDTOResponse response = disclaimerService.getDisclaimerBody(id);

        return ResponseEntity.ok(ApiResponse.success(response,
                "Cuerpo del disclaimer obtenido correctamente."));

    }

}
