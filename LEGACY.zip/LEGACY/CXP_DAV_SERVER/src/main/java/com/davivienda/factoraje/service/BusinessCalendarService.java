package com.davivienda.factoraje.service;

import com.davivienda.factoraje.repository.HolidayRepository;
import lombok.RequiredArgsConstructor;
import java.time.LocalDate;
import java.time.DayOfWeek;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BusinessCalendarService {

    private final HolidayRepository holidayRepository;

    /**
     * Evalúa si una fecha específica es un día laborable para el banco.
     */
    @Cacheable(value = "calendarCache", key = "#fecha")
    public boolean esDiaHabil(LocalDate fecha) {
        // 1. Validar si es Fin de Semana (Sábado o Domingo)
        DayOfWeek diaSemana = fecha.getDayOfWeek();
        if (diaSemana == DayOfWeek.SATURDAY || diaSemana == DayOfWeek.SUNDAY) {
            return false; 
        }

        // 2. Validar si es un asueto registrado en la Base de Datos
        return !holidayRepository.existsByHolidayDate(fecha);
    }

    /**
     * Avanza en el calendario día por día hasta encontrar el siguiente día hábil disponible.
     * Es crucial usar un bucle (while) porque handlea asuetos consecutivos (ej. 5 y 6 de agosto).
     */
    public LocalDate obtenerSiguienteDiaHabil(LocalDate fechaInicial) {
        LocalDate fechaCandidata = fechaInicial;
        
        do {
            fechaCandidata = fechaCandidata.plusDays(1);
        } while (!esDiaHabil(fechaCandidata));
        
        return fechaCandidata;
    }
}
