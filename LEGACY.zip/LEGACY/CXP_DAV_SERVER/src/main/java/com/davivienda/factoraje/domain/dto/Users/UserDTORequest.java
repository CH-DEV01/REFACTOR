package com.davivienda.factoraje.domain.dto.Users;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTORequest {

    private String name;
    private String dui;
    private String email;
    private UUID entityId;
    private UUID roleId;
    
}
