package com.davivienda.factoraje.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.batch.ConfirmBatchDTORequest;
import com.davivienda.factoraje.domain.dto.batch.CreateBatchDTORequest;
import com.davivienda.factoraje.domain.model.AcceptanceAuditModel;
import com.davivienda.factoraje.domain.model.DisbursementBatchModel;
import com.davivienda.factoraje.domain.model.DocumentModel;
import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.domain.model.TermVersionModel;
import com.davivienda.factoraje.domain.model.UserModel;
import com.davivienda.factoraje.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.AcceptanceAuditRepository;
import com.davivienda.factoraje.repository.DisbursementBatchRepository;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.TermVersionRepository;

import jakarta.transaction.Transactional;

@Service
public class DisbursementBatchService {

    private final DisbursementBatchRepository batchRepository;
    private final UserService userService;
    private final DocumentService documentService;
    private final AuditLogService auditLogService;
    private final AcceptanceAuditRepository acceptanceAuditRepository;
    private final TermVersionRepository termVersionRepository;
    private final DocumentRepository documentRepository;
    private final EntityService entityService;
    private static final Logger log = LoggerFactory.getLogger(AgreementService.class);

    public DisbursementBatchService(
            DisbursementBatchRepository batchRepository,
            EntityService entityService,
            UserService userService,
            DocumentService documentService,
            AuditLogService auditLogService,
            AcceptanceAuditRepository acceptanceAuditRepository,
            TermVersionRepository termVersionRepository,
            DocumentRepository documentRepository) {

        this.batchRepository = batchRepository;
        this.userService = userService;
        this.documentService = documentService;
        this.auditLogService = auditLogService;
        this.acceptanceAuditRepository = acceptanceAuditRepository;
        this.termVersionRepository = termVersionRepository;
        this.documentRepository = documentRepository;
        this.entityService = entityService;
    }

    @Transactional
    public List<DocumentModel> getPreviewDocuments(UUID payerId) {
        return documentRepository.findReadyDocumentsByPayer(payerId, "SELECTED");
    }

    // CREATE
    @Transactional
    public DisbursementBatchModel createBatch(
            CreateBatchDTORequest requestDTO,
            UUID userId,
            String ipAddress,
            String userAgent) {

        // 1. Validaciones Base
        UserModel operator = userService.getUserById(userId);
        if (operator == null)
            throw new ResourceNotFoundException("Usuario no encontrado.");

        TermVersionModel termsVersion = termVersionRepository.findById(requestDTO.getTermVersionId())
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró la versión de términos solicitada."));

        EntityModel payer = entityService.getEntityById(requestDTO.getPayerId());
        if (payer == null)
            throw new ResourceNotFoundException("Pagador no encontrado.");

        // 2. Auditoría Padre
        AcceptanceAuditModel audit = new AcceptanceAuditModel();
        audit.setAcceptanceTimestamp(Instant.now());
        audit.setIpAddress(ipAddress);
        audit.setUserAgent(userAgent);
        audit.setUser(operator);
        audit.setVersion(termsVersion);
        final AcceptanceAuditModel savedAudit = acceptanceAuditRepository.save(audit);

        // 3. 🚀 EL CEREBRO FINANCIERO: Buscar automáticamente lo elegible
        LocalDate fechaHoy = LocalDate.now();
        LocalDate fechaManana = fechaHoy.plusDays(1);

        // Trae todo lo de ese pagador (de todos sus acuerdos) que deba pagarse <=
        // mañana
        List<DocumentModel> docsToInclude = documentRepository.findReadyForDisbursement(payer.getId(), fechaManana);

        if (docsToInclude.isEmpty()) {
            throw new IllegalStateException(
                    "El sistema no encontró documentos pendientes o elegibles para desembolsar mañana (" + fechaManana
                            + ") para la entidad: " + payer.getName());
        }

        // 4. Preparar la cabecera del Lote
        DisbursementBatchModel batch = new DisbursementBatchModel();
        batch.setBatchNumber("LOT-" + payer.getNit() + "-" + fechaManana.toString().replace("-", ""));
        batch.setStatus("PENDING");
        batch.setCreatedBy(operator);
        batch.setCreatedAt(Instant.now());

        BigDecimal totalAmount = BigDecimal.ZERO;
        BigDecimal totalCommission = BigDecimal.ZERO;

        // Guardamos el lote primero para tener su ID disponible
        DisbursementBatchModel savedBatch = batchRepository.save(batch);

        // 5. Procesar y amarrar los documentos
        for (DocumentModel doc : docsToInclude) {
            doc.setStatus("PROCESSING_DISBURSEMENT");
            doc.setDisbursementBatch(savedBatch); // Amarra al lote

            totalAmount = totalAmount
                    .add(doc.getAmountToFinance() != null ? doc.getAmountToFinance() : BigDecimal.ZERO);
            totalCommission = totalCommission.add(doc.getCommission() != null ? doc.getCommission() : BigDecimal.ZERO);

            // 6. Registro en Bitácora individual
            auditLogService.logAction(doc, userId, "BATCH-GENERATED", savedAudit);

            documentRepository.save(doc);
        }

        // 7. Actualizar totales y retornar
        savedBatch.setTotalAmount(totalAmount);
        savedBatch.setTotalCommission(totalCommission);
        savedBatch.setDocuments(docsToInclude);

        log.info("Lote automático [{}] generado por el usuario [{}]. Total facturas: {}. Monto a financiar: ${}",
                savedBatch.getBatchNumber(), operator.getName(), docsToInclude.size(), totalAmount);

        return batchRepository.save(savedBatch);
    }

    @Transactional
    public List<DisbursementBatchModel> getBatchHistory() {
        // Obtenemos los lotes ordenados del más reciente al más antiguo
        return batchRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
    }

    @Transactional
    public DisbursementBatchModel getBatchDetails(UUID batchId) {
        return batchRepository.findById(batchId)
                .orElseThrow(() -> new ResourceNotFoundException("Lote no encontrado con ID: " + batchId));
    }

    // UPDATE
    @Transactional
    public DisbursementBatchModel updateBatch(
            UUID batchId,
            ConfirmBatchDTORequest requestDTO,
            UUID userId,
            String ipAddress,
            String userAgent) {

        DisbursementBatchModel batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new ResourceNotFoundException("Recurso no encontrado"));

        if (!"PENDING".equals(batch.getStatus())) {
            throw new IllegalStateException("El lote ya fue procesado o cancelado.");
        }

        UserModel operator = userService.getUserById(userId);
        TermVersionModel termsVersion = termVersionRepository.findById(requestDTO.getTermVersionId())
                .orElseThrow(
                        () -> new ResourceNotFoundException("No se encontro el recurso solicitado."));

        // 1. Crear Auditoría Padre
        AcceptanceAuditModel audit = new AcceptanceAuditModel();
        audit.setAcceptanceTimestamp(Instant.now());
        audit.setIpAddress(ipAddress);
        audit.setUserAgent(userAgent);
        audit.setUser(operator);
        audit.setVersion(termsVersion);
        final AcceptanceAuditModel savedAudit = acceptanceAuditRepository.save(audit);

        List<UUID> exitos = requestDTO.getSuccessfulDocumentIds() != null ? requestDTO.getSuccessfulDocumentIds()
                : new ArrayList<>();
        int totalDocumentosEnLote = batch.getDocuments().size();

        BigDecimal finalExecutedAmount = BigDecimal.ZERO;
        BigDecimal finalExecutedCommission = BigDecimal.ZERO;

        // 2. Procesar documentos de forma individual
        for (DocumentModel doc : batch.getDocuments()) {
            if (exitos.contains(doc.getDocument_id())) {
                doc.setStatus("DISBURSED");
                finalExecutedAmount = finalExecutedAmount.add(doc.getAmountToFinance());
                finalExecutedCommission = finalExecutedCommission.add(doc.getCommission());

                auditLogService.logAction(doc, userId, "UPDATE-DISBURSED", savedAudit);
            } else {
                // Liberar los que fallaron
                doc.setStatus("SELECTED");
                doc.setDisbursementBatch(null);
                auditLogService.logAction(doc, userId, "DISBURSEMENT-FAILED", savedAudit);
            }
        }

        // 3. Estado Final del Lote
        if (exitos.isEmpty()) {
            batch.setStatus("FAILED");
        } else if (exitos.size() == totalDocumentosEnLote) {
            batch.setStatus("COMPLETED");
        } else {
            batch.setStatus("PARTIALLY_COMPLETED");
        }

        batch.setTotalAmount(finalExecutedAmount);
        batch.setTotalCommission(finalExecutedCommission);
        batch.setExecutionDate(Instant.now());

        return batchRepository.save(batch);
    }

}
