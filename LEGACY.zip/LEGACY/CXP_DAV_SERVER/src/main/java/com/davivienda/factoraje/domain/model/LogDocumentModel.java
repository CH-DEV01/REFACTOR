package com.davivienda.factoraje.domain.model;

import java.time.Instant;
import java.util.UUID;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "document_logs")
@NoArgsConstructor  
@AllArgsConstructor 
public class LogDocumentModel {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "id", columnDefinition = "UUID", updatable = false, nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_id", nullable = false)
    private DocumentModel document;

    @Column(name = "user_id", nullable = false)
    private UUID user_id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "action_id", nullable = false)
    private ActionCatalogModel actionCatalog;

    @Column(name = "fecha_hora_accion", nullable = false)
    private Instant date_time_action;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "acceptance_audit_id", nullable = false)
    private AcceptanceAuditModel acceptanceAudit;

    public LogDocumentModel(DocumentModel document, UUID userId, ActionCatalogModel action, AcceptanceAuditModel acceptanceAuditModel) {
        this.document = document;
        this.user_id = userId;
        this.actionCatalog = action;
        this.date_time_action = Instant.now();
        this.acceptanceAudit = acceptanceAuditModel;
    }

}
