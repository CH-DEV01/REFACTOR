package com.davivienda.factoraje.domain.dto.holiday;

import java.time.LocalDate;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HolidayResponseDTO {
    private UUID id;
    private LocalDate holidayDate;
    private String description;
}