package com.davivienda.factoraje.repository;

import java.time.LocalDate;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.model.HolidayModel;

@Repository
public interface HolidayRepository extends JpaRepository<HolidayModel, UUID> {
    
    boolean existsByHolidayDate(LocalDate holidayDate);
}