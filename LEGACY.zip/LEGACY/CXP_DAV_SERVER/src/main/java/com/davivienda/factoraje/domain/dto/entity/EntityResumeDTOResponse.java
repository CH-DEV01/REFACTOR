package com.davivienda.factoraje.domain.dto.entity;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntityResumeDTOResponse {

    private UUID id;
    private String niu;
    private String code;
    private String name;
    private String nit;
    private String accountBank;
    private String creditLineNumber;

}
