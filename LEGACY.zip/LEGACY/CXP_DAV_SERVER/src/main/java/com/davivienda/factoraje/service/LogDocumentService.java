package com.davivienda.factoraje.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.logDocument.LogDocumentDTORequest;
import com.davivienda.factoraje.domain.model.LogDocumentModel;
import com.davivienda.factoraje.repository.LogDocumentRepository;

import jakarta.transaction.Transactional;

@Service
public class LogDocumentService {

    private final LogDocumentRepository logDocumentRepository;

    public LogDocumentService(LogDocumentRepository logDocumentRepository){
        this.logDocumentRepository = logDocumentRepository;
    }

    // public void saveLogDocument(LogDocumentDTORequest request){

    //     LogDocumentModel logDocumentToSave = new LogDocumentModel(
    //         request.getDocumentId(),
    //         request.getUserId(),
    //         request.getAction()

    //     );

    //     logDocumentRepository.save(logDocumentToSave);

    // }
    
}
