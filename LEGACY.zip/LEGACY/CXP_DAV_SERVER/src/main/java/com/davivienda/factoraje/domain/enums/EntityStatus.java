package com.davivienda.factoraje.domain.enums;

public enum EntityStatus {

    ACTIVE,
    INACTIVE
    
}
