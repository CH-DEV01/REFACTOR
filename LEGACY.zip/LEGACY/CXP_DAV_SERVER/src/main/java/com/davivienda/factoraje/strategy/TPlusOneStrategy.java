package com.davivienda.factoraje.strategy;

import com.davivienda.factoraje.service.BusinessCalendarService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Component
@RequiredArgsConstructor
public class TPlusOneStrategy implements DisbursementStrategy {

    private final BusinessCalendarService calendarService;
    private static final LocalTime HORA_CORTE = LocalTime.of(12, 0);

    @Override
    public String getPolicyCode() { return "T_PLUS_1"; } // Coincide con la BD

    @Override
    public LocalDate calcular(LocalDateTime fechaSolicitud) {
        LocalDate fechaBase = fechaSolicitud.toLocalDate();
        if (!calendarService.esDiaHabil(fechaBase)) {
            LocalDate proximo = calendarService.obtenerSiguienteDiaHabil(fechaBase);
            return calendarService.obtenerSiguienteDiaHabil(proximo);
        }
        if (fechaSolicitud.toLocalTime().isBefore(HORA_CORTE)) {
            return calendarService.obtenerSiguienteDiaHabil(fechaBase);
        } else {
            LocalDate primerHábil = calendarService.obtenerSiguienteDiaHabil(fechaBase);
            return calendarService.obtenerSiguienteDiaHabil(primerHábil);
        }
    }
}