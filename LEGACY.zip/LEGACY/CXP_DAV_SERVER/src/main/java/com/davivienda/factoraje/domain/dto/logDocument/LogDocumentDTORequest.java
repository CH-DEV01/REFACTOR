package com.davivienda.factoraje.domain.dto.logDocument;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LogDocumentDTORequest {
    
    private UUID documentId;
    private UUID userId;
    private String action;
    
}
