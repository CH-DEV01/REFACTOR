package com.davivienda.factoraje.domain.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@Table(name = "disbursement_batches")
public class DisbursementBatchModel {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    // (Ej. "LOTE-20260601-01")
    @Column(name = "batch_number", nullable = false, unique = true)
    private String batchNumber;

    // El total de dinero que suma este lote
    @Column(name = "total_amount", nullable = false, precision = 18, scale = 2)
    private BigDecimal totalAmount;

    // El total de comisión cobrada en este lote
    @Column(name = "total_commission", nullable = false, precision = 18, scale = 2)
    private BigDecimal totalCommission;

    // PENDING, PROCESSING, COMPLETED, FAILED
    @Column(name = "status", nullable = false)
    private String status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by_user_id", nullable = false)
    private UserModel createdBy;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    // Cuándo se envió realmente el dinero
    @Column(name = "execution_date")
    private Instant executionDate;

    // Relación inversa: Un lote tiene muchos documentos
    @OneToMany(mappedBy = "disbursementBatch")
    private List<DocumentModel> documents;
}