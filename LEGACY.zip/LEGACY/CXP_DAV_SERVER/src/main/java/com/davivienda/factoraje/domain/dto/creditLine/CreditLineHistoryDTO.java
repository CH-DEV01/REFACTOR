package com.davivienda.factoraje.domain.dto.creditLine;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreditLineHistoryDTO {
    private UUID id;
    private String reference;
    private LocalDateTime date;
    private BigDecimal amount;
    private UUID operatorId;
    private String operator;
}