package com.davivienda.factoraje.strategy;

import com.davivienda.factoraje.service.BusinessCalendarService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;

@Component
@RequiredArgsConstructor
public class OnlyFridaysStrategy implements DisbursementStrategy {

    private final BusinessCalendarService calendarService;
    private static final LocalTime HORA_CORTE = LocalTime.of(12, 0);

    @Override
    public String getPolicyCode() { return "ONLY_FRIDAYS"; } // Coincide con la BD

    @Override
    public LocalDate calcular(LocalDateTime fechaSolicitud) {
        LocalDate fechaBase = fechaSolicitud.toLocalDate();
        LocalTime hora = fechaSolicitud.toLocalTime();
        DayOfWeek dia = fechaBase.getDayOfWeek();
        LocalDate viernesDestino;

        if ((dia == DayOfWeek.FRIDAY && hora.isAfter(HORA_CORTE)) || dia == DayOfWeek.SATURDAY || dia == DayOfWeek.SUNDAY) {
            viernesDestino = fechaBase.with(TemporalAdjusters.next(DayOfWeek.FRIDAY));
        } else {
            viernesDestino = fechaBase.with(TemporalAdjusters.nextOrSame(DayOfWeek.FRIDAY));
        }

        if (!calendarService.esDiaHabil(viernesDestino)) {
            return calendarService.obtenerSiguienteDiaHabil(viernesDestino);
        }
        return viernesDestino;
    }
}