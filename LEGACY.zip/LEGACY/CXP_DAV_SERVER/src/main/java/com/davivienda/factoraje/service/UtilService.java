package com.davivienda.factoraje.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.model.AgreementModel;
import com.davivienda.factoraje.domain.model.DocumentModel;
import com.davivienda.factoraje.repository.AgreementRepository;

@Service
public class UtilService {

    private final AgreementRepository agreementRepository;

    public UtilService(AgreementRepository agreementRepository){
        this.agreementRepository = agreementRepository;
    }

    public List<AgreementModel> findByPayerWithStatus(String payerId, String status) {
        if (payerId == null || status == null) {
            throw new IllegalArgumentException("El parámetro 'payerId' no puede ser nulo");
        }

        List<AgreementModel> agreements = agreementRepository.findAll().stream()
                .filter(agreement -> {
                    String identifier = agreement.getIdentifier();
                    return identifier != null &&
                            identifier.length() >= 36 &&
                            identifier.substring(0, 36).equals(payerId);
                })
                .collect(Collectors.toList());

        for (AgreementModel agreement : agreements) {
            List<DocumentModel> documents = new ArrayList<>();
            for (DocumentModel document : agreement.getDocuments()) {
                if (document.getStatus() != null && document.getStatus().equals(status)) {
                    documents.add(document);
                }
            }
            agreement.setDocuments(documents);
        }

        return agreements;
    }

}
