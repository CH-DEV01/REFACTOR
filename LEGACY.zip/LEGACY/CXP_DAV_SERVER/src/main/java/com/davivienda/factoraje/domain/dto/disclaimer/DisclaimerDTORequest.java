package com.davivienda.factoraje.domain.dto.disclaimer;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DisclaimerDTORequest {

    private UUID entityId;
    
}
