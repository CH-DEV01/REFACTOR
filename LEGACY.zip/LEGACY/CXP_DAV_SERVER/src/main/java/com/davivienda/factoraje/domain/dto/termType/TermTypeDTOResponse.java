package com.davivienda.factoraje.domain.dto.termType;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TermTypeDTOResponse {

    private UUID id;
    private String documentName;
    private String uniqueCode;
    
}