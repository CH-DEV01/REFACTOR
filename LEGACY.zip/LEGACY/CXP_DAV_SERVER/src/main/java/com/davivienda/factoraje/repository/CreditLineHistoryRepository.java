package com.davivienda.factoraje.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.model.CreditLineHistoryModel;
import com.davivienda.factoraje.domain.model.EntityModel;

@Repository
public interface CreditLineHistoryRepository extends JpaRepository<CreditLineHistoryModel, UUID> {

    List<CreditLineHistoryModel> findTop10ByPayerOrderByExecutionDateDesc(EntityModel payer);
    
}
