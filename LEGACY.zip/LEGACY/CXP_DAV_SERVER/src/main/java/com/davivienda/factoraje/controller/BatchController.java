package com.davivienda.factoraje.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.service.BatchExcelService;

@RestController
@RequestMapping("/api/batch")
public class BatchController {

    private final BatchExcelService batchExcelService;

    public BatchController(BatchExcelService batchExcelService) {
        this.batchExcelService = batchExcelService;
    }

    @GetMapping("/generate/{payerId}")
    public ResponseEntity<byte[]> generateBatchExcel(@PathVariable String payerId) {
        
        // 1. Llamamos al servicio que nos devuelve los bytes del Excel
        byte[] excelFile = batchExcelService.generateDisbursementExcel(payerId);

        // 2. Configuramos los cabezales (Headers) para forzar la descarga
        HttpHeaders headers = new HttpHeaders();
        
        // El Content-Type oficial para archivos .xlsx
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        
        // Le dice al navegador que es un "adjunto" (descarga) y sugiere un nombre
        headers.setContentDispositionFormData("attachment", "lote_desembolso.xlsx");
        
        // Prevenir que el navegador guarde el archivo en caché (seguridad financiera)
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        // 3. Retornamos la respuesta HTTP 200 (OK) con el archivo binario
        return new ResponseEntity<>(excelFile, headers, HttpStatus.OK);
    }
}