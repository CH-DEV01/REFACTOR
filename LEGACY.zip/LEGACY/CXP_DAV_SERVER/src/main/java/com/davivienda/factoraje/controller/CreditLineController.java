package com.davivienda.factoraje.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.davivienda.factoraje.domain.dto.common.ApiResponse;
import com.davivienda.factoraje.domain.dto.creditLine.CreditLineDetailsResponseDTO;
import com.davivienda.factoraje.domain.dto.creditLine.PayerOptionDTO;
import com.davivienda.factoraje.domain.dto.creditLine.RepaymentRequestDTO;
import com.davivienda.factoraje.domain.dto.creditLine.RepaymentResponseDTO;
import com.davivienda.factoraje.service.CreditLineService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/credit-lines")
@RequiredArgsConstructor
public class CreditLineController {

    private final CreditLineService creditLineService;

    // Endpoint para cargar las métricas y la tabla al cambiar de select en React
    @GetMapping("/{payerId}/details")
    public ResponseEntity<ApiResponse<CreditLineDetailsResponseDTO>> getDetails(
            @PathVariable UUID payerId) {

        CreditLineDetailsResponseDTO response = creditLineService.getCreditLineDetails(payerId);
        return ResponseEntity.ok(ApiResponse.success(response, "Detalles de línea obtenidos con éxito."));
    }

    // Endpoint para procesar el abono
    @PostMapping("/restore")
    public ResponseEntity<ApiResponse<RepaymentResponseDTO>> restoreLine(
            @Valid @RequestBody RepaymentRequestDTO request) {

        RepaymentResponseDTO response = creditLineService.restoreCreditLine(request);
        return ResponseEntity.ok(ApiResponse.success(response, "Línea de crédito restaurada correctamente."));
    }

    @GetMapping("/payers")
    public ResponseEntity<ApiResponse<List<PayerOptionDTO>>> getPayers() {
        List<PayerOptionDTO> response = creditLineService.getPayerOptions();
        return ResponseEntity.ok(ApiResponse.success(response, "Lista de pagadores obtenida con éxito."));
    }
}
