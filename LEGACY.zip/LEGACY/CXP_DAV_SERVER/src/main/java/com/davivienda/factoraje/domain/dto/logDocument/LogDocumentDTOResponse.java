package com.davivienda.factoraje.domain.dto.logDocument;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogDocumentDTOResponse {

    // Identificador de la acción: "CARGA", "SELECCION", "APROBACION"
    private String actionType;

    // Datos del usuario
    private String userName;
    private String userDui;
    private String entityName;

    // Datos del evento
    private String timestamp;
    private String termsVersion;
    private String userAgent;

}
