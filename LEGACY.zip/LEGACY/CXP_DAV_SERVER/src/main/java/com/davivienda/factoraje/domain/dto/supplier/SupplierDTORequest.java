package com.davivienda.factoraje.domain.dto.supplier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SupplierDTORequest {

    private String code;
    private String name;
    private String nit;
    private String niu;
    private String accountBank;
    
}
