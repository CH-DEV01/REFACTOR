package com.davivienda.factoraje.domain.dto.Users;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTOResponse {

    private UUID id;
    private String name;
    
}
