package com.davivienda.factoraje.service;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.logDocument.LogDocumentDTORequest;
import com.davivienda.factoraje.domain.dto.logDocument.LogDocumentDTOResponse;
import com.davivienda.factoraje.domain.model.AcceptanceAuditModel;
import com.davivienda.factoraje.domain.model.ActionCatalogModel;
import com.davivienda.factoraje.domain.model.DocumentModel;
import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.domain.model.LogDocumentModel;
import com.davivienda.factoraje.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.ActionCatalogRepository;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.LogDocumentRepository;

@Service
public class AuditLogService {

    private final LogDocumentRepository logDocumentRepository;
    private final ActionCatalogRepository actionCatalogRepository;
    private final DocumentRepository documentRepository;

    public AuditLogService(ActionCatalogRepository actionCatalogRepository,
            LogDocumentRepository logDocumentRepository, DocumentRepository documentRepository) {

        this.actionCatalogRepository = actionCatalogRepository;
        this.logDocumentRepository = logDocumentRepository;
        this.documentRepository = documentRepository;

    }

    // CREATE
    public void logAction(DocumentModel document, UUID userId, String actionName, AcceptanceAuditModel acceptanceAudit) {
        if (document == null || userId == null || actionName == null) {
            throw new IllegalArgumentException("Argumentos no pueden ser null");
        }

        // 1. Buscamos la acción (con un mensaje de error específico)
        ActionCatalogModel action = actionCatalogRepository.findByActionName(actionName)
                .orElseThrow(
                        () -> new ResourceNotFoundException("No se encontró la acción en el catálogo: " + actionName));

        // 2. Ya NO necesitamos buscar el documento porque ya lo recibimos como
        // parámetro.
        // Solo creamos el log directamente:
        LogDocumentModel log = new LogDocumentModel(document, userId, action, acceptanceAudit);

        logDocumentRepository.save(log);
    }

    // READ ONE LOG DOCUMENT
    public List<LogDocumentDTOResponse> getLogDocument(UUID documentId) {

        List<LogDocumentModel> logs = logDocumentRepository.obtenerBitacoraPorDocumento(documentId);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a")
                .withLocale(Locale.forLanguageTag("es-ES"))
                .withZone(ZoneId.systemDefault());

        return logs.stream().map(log -> {

            LogDocumentDTOResponse dto = new LogDocumentDTOResponse();

            dto.setActionType(log.getActionCatalog().getActionName());
            dto.setUserName(log.getAcceptanceAudit().getUser().getName());
            dto.setUserDui(log.getAcceptanceAudit().getUser().getDui());
            String fechaFormateada = formatter.format(log.getDate_time_action());
            dto.setTimestamp(fechaFormateada);
            dto.setTermsVersion(log.getAcceptanceAudit().getVersion().getVersionNumber());
            dto.setUserAgent(log.getAcceptanceAudit().getUserAgent());

            return dto;
        }).collect(Collectors.toList());
    }

    // public void saveLogDocuments(List<LogDocumentDTORequest> requests) {

    // if (requests == null || requests.isEmpty()) {
    // return;
    // }

    // ActionCatalogModel action =
    // actionCatalogRepository.findByActionName(requests[0].getAction())
    // .orElseThrow(() -> new ResourceNotFoundException("No se pudo localizar el
    // recurso: ID no existe"));

    // List<LogDocumentModel> logsToSave = requests.stream()
    // .map(req -> new LogDocumentModel(
    // req.getDocumentId(),
    // req.getUserId(),
    // req.getAction()))
    // .toList();
    // logDocumentRepository.saveAll(logsToSave);
    // }
}