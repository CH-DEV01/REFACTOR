package com.davivienda.factoraje.controller;

public class HolidayResponseDTO {

}
