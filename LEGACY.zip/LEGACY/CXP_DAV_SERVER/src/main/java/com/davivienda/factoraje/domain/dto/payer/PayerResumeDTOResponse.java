package com.davivienda.factoraje.domain.dto.payer;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PayerResumeDTOResponse {

    private UUID id;
    private String name;
    private Integer paymentPolicy;
    private String creditLineNumber;
    private String documentsToDisbursement;
    private Integer availableDocuments;
    private String paymentPolicyName;

}
