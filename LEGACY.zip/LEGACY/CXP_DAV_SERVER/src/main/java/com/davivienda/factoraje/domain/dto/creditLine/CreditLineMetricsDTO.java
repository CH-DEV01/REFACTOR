package com.davivienda.factoraje.domain.dto.creditLine;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreditLineMetricsDTO {
    private BigDecimal totalLimit;
    private BigDecimal currentConsumed;
    private BigDecimal availableLimit;
    private BigDecimal utilizationRate;
    private Integer averageMaturityDays;
    private String riskStatus;
    private BigDecimal lastRepaymentAmount;
    private LocalDateTime lastRepaymentDate;
}