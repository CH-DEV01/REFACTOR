package com.davivienda.factoraje.domain.dto.payer;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PayerDTORequest {

    private String code;
    private String name;
    private String nit;
    private String creditLineNumber;
    private Integer paymentPolicy;
    private BigDecimal interestRate;
    private BigDecimal commissionRate;
    private BigDecimal calculationBase;
    private String niu;
    private Boolean entityType;
    private Boolean disbursementMethod;
}
