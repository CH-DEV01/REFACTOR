package com.davivienda.factoraje.domain.dto.holiday;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HolidayRequestDTO {
    private LocalDate holidayDate;
    private String description;
}
