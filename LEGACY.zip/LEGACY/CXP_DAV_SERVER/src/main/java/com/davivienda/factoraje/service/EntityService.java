package com.davivienda.factoraje.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import com.davivienda.factoraje.domain.dto.disbursement.NextDisbursementResponseDTO;
import com.davivienda.factoraje.domain.dto.payer.PayerDTORequest;
import com.davivienda.factoraje.domain.dto.payer.PayerDTOResponse;
import com.davivienda.factoraje.domain.dto.payer.PayerResumeDTOResponse;
import com.davivienda.factoraje.domain.dto.supplier.SupplierDTORequest;
import com.davivienda.factoraje.domain.dto.supplier.SupplierDTOResponse;
import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.EntityRepository;

@Service
public class EntityService {

    private final EntityRepository entityRepository;
    private final UtilService utilService;
    private final DocumentRepository documentRepository;
    private static final Logger log = LoggerFactory.getLogger(EntityService.class);
    private final DisbursementMatcherService disbursementMatcherService;

    public EntityService(
        EntityRepository entityRepository, 
        DocumentRepository documentRepository,
        UtilService utilService,
        DisbursementMatcherService disbursementMatcherService
        ) {
        this.entityRepository = entityRepository;
        this.utilService = utilService;
        this.documentRepository = documentRepository;
        this.disbursementMatcherService = disbursementMatcherService;
        log.info("EntityService initialized");
    }

    public EntityModel createEntity(EntityModel entity) {
        // if (entity == null) {
        // log.warn("createEntity called with null entity");
        // throw new IllegalArgumentException("La entidad no puede ser nula");
        // }
        if (entity == null) {
            log.warn("createEntity called with null entity");
            throw new IllegalArgumentException("La entidad no puede ser nula");
        }
        log.debug("Saving entity with code {}", entity.getCode());
        return entityRepository.save(entity);
    }

    public NextDisbursementResponseDTO getNextDisbursementDate(UUID payerId) {

        EntityModel payer = entityRepository.findById(payerId)
                .orElseThrow(() -> new ResourceNotFoundException("Pagador no encontrado con ID: " + payerId));

        // 2. Extraemos su política (Si no tiene, aplicamos la de por defecto)
        String policyCode = "T_PLUS_1";
        String policyName = "T + 1 Hábil";

        if (payer.getDisbursementPolicy() != null) {
            policyCode = payer.getDisbursementPolicy().getCode();
            policyName = payer.getDisbursementPolicy().getName();
        }

        // 3. Llamar al Cerebro Financiero pasándole la hora actual exacta
        LocalDate nextDate = disbursementMatcherService.calcularFechaDesembolso(LocalDateTime.now(), policyCode);

        return new NextDisbursementResponseDTO(nextDate, policyCode, policyName);
    }

    // UPDATE
    public PayerDTOResponse update(UUID id, PayerDTORequest dto) {

        EntityModel entity = entityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar: ID no existe"));

        entity.setCode(dto.getCode());
        entity.setName(dto.getName());
        entity.setNit(dto.getNit());
        entity.setCreditLineNumber(dto.getCreditLineNumber());
        entity.setPaymentPolicy(dto.getPaymentPolicy());
        entity.setInterestRate(dto.getInterestRate());
        entity.setCommissionRate(dto.getCommissionRate());
        entity.setCalculationBase(dto.getCalculationBase());
        entity.setNiu(dto.getNiu());
        entity.setEntityType(dto.getEntityType());
        entity.setDisbursementMethod(dto.getDisbursementMethod());

        EntityModel entityUpdated = new EntityModel();
        entityUpdated = entityRepository.save(entity);

        PayerDTOResponse response = new PayerDTOResponse();
        response.setId(entityUpdated.getId());
        response.setName(entityUpdated.getName());

        return response;
    }

    public SupplierDTOResponse updateSupplier(UUID id, SupplierDTORequest dto) {

        EntityModel entity = entityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No se puede actualizar: ID no existe"));

        entity.setCode(dto.getCode());
        entity.setName(dto.getName());
        entity.setNit(dto.getNit());
        entity.setNiu(dto.getNiu());
        entity.setAccountBank(dto.getAccountBank());

        EntityModel entityUpdated = new EntityModel();
        entityUpdated = entityRepository.save(entity);

        SupplierDTOResponse response = new SupplierDTOResponse();

        response.setId(entityUpdated.getId());
        response.setName(entityUpdated.getName());

        return response;
    }

    public List<EntityModel> getEntities() {
        log.debug("Fetching all entities");
        return entityRepository.findAll();
    }

    public List<PayerResumeDTOResponse> getEntitiesResume() {

        // 1. Calculamos la fecha objetivo del lote (Mañana)
        LocalDate fechaManana = LocalDate.now().plusDays(1);

        // 2. Filtramos las entidades pagadoras
        List<EntityModel> entities = entityRepository.findAll().stream()
                .filter(e -> Boolean.TRUE.equals(e.getEntityType()))
                .collect(Collectors.toList());

        // 3. Mapeamos la respuesta
        return entities.stream().map(entity -> {

            PayerResumeDTOResponse resume = new PayerResumeDTOResponse();
            resume.setId(entity.getId());
            resume.setName(entity.getName());

            // Asumiendo que tu política ahora viene de la relación, ajusta si es necesario:
            String policyName = entity.getDisbursementPolicy() != null
                    ? entity.getDisbursementPolicy().getName()
                    : "No asignada";
            resume.setPaymentPolicyName(policyName);

            resume.setCreditLineNumber(entity.getCreditLineNumber());

            // Contamos directo en BD respetando la fecha programada
            Integer totalDocumentos = documentRepository.countReadyForDisbursement(entity.getId(), fechaManana);

            resume.setAvailableDocuments(totalDocumentos != null ? totalDocumentos : 0);

            return resume;

        }).collect(Collectors.toList());
    }

    public List<EntityModel> getEntitiesByType(boolean isEntityType) {
        log.debug("Filtering entities by type {}", isEntityType);
        return entityRepository.findAll().stream()
                .filter(e -> e.getEntityType() == isEntityType)
                .collect(Collectors.toList());
    }

    public EntityModel findByCode(String code) {
        // if (code == null || code.trim().isEmpty()) {
        // log.warn("findByCode called with empty code");
        // throw new IllegalArgumentException("El parámetro 'code' no puede ser vacío");
        // }
        // return entityRepository.findAll().stream()
        // .filter(e -> code.equals(e.getCode()))
        // .findFirst()
        // .orElse(null);

        if (code == null || code.trim().isEmpty()) {
            log.warn("findByCode called with empty code");
            throw new IllegalArgumentException("El parámetro 'code' no puede ser null");
        }

        // 2. Consulta a la base de datos (una sola vez)
        // Se asume que tu repositorio devuelve un Optional<EntityModel>,
        // lo cual es la mejor práctica para evitar NullPointerExceptions.
        java.util.Optional<EntityModel> entityOptional = entityRepository.findByCode(code);

        // 3. Retorno del resultado
        // Usamos orElse(null) para devolver la entidad si se encuentra,
        // o null si el Optional está vacío. Es una forma limpia y segura.
        return entityOptional.orElse(null);
    }

    public EntityModel getEntityById(UUID id) {
        // if (id == null) {
        // log.warn("getEntityById called with null id");
        // throw new IllegalArgumentException("El parámetro 'id' no puede ser nulo");
        // }
        // return entityRepository.findById(id)
        // .orElseThrow(() -> new ResourceNotFoundException("Entidad no encontrada con
        // id=" + id));

        if (id == null) {
            log.warn("getEntityById called with null id");
            throw new IllegalArgumentException("El parámetro 'id' no puede ser nulo");
        }
        return entityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Entidad no encontrada con id=" + id));
    }

    public EntityModel updateEntity(UUID id, EntityModel entity) {

        if (id == null) {
            log.warn("getEntityById called with null id");
            throw new IllegalArgumentException("El parámetro 'id' no puede ser nulo");
        }

        if (entity == null) {
            log.warn("updateEntity called with null entity model");
            throw new IllegalArgumentException("El cuerpo de la petición no puede ser nulo");
        }

        EntityModel existing = entityRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Entidad no encontrada"));

        existing.setCode(entity.getCode());
        existing.setName(entity.getName());
        existing.setNit(entity.getNit());
        existing.setAccountBank(entity.getAccountBank());
        existing.setEmail(entity.getEmail());

        log.debug("Updating entity {}", id);
        return entityRepository.save(existing);
    }

    public void deleteEntity(UUID id) {
        if (id == null) {
            log.warn("deleteEntity called with null id");
            throw new IllegalArgumentException("El parámetro 'id' no puede ser nulo");
        }
        if (!entityRepository.existsById(id)) {
            log.warn("Entity with id {} not found for deletion", id);
            throw new ResourceNotFoundException("Entidad no encontrada");
        }
        log.debug("Deleting entity {}", id);
        entityRepository.deleteById(id);
    }
}
