package com.davivienda.factoraje.domain.dto.creditLine;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepaymentRequestDTO {

    private UUID payerId;

    @NotNull(message = "El monto del abono no puede ser nulo.")
    @Positive(message = "El monto del abono debe ser un valor mayor a cero.")
    private BigDecimal amount;

    @NotBlank(message = "La referencia o número de comprobante es obligatoria.")
    private String reference;

    @NotBlank(message = "El tipo de redención (PARTIAL/FULL) es obligatorio.")
    private String type;

    private UUID userId;
}