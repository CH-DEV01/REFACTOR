package com.davivienda.factoraje.domain.dto.batch;

import java.util.List;
import java.util.UUID;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConfirmBatchDTORequest {

    @NotNull(message = "La lista de documentos procesados no puede ser nula.")
    private List<UUID> successfulDocumentIds;

    @NotNull(message = "La versión de términos aceptada es obligatoria.")
    private UUID termVersionId;

}
