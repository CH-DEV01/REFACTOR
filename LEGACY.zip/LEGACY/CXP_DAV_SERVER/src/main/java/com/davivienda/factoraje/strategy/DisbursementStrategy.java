package com.davivienda.factoraje.strategy;

import java.time.LocalDate;
import java.time.LocalDateTime;

public interface DisbursementStrategy {
    String getPolicyCode(); // Nos dirá a qué código de la BD pertenece esta clase
    LocalDate calcular(LocalDateTime fechaSolicitud);
}
