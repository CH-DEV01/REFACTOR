package com.davivienda.factoraje.service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.dto.holiday.HolidayRequestDTO;
import com.davivienda.factoraje.domain.dto.holiday.HolidayResponseDTO;
import com.davivienda.factoraje.domain.model.HolidayModel;
import com.davivienda.factoraje.repository.HolidayRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HolidayService {

    private final HolidayRepository holidayRepository;

    // Obtener todos los asuetos (ordenados por fecha)
    public List<HolidayResponseDTO> getAllHolidays() {
        return holidayRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // Crear un nuevo asueto (y limpiar la caché del calendario)
    @CacheEvict(value = "calendarCache", allEntries = true)
    public HolidayResponseDTO createHoliday(HolidayRequestDTO requestDTO) {
        // Validar si ya existe
        if (holidayRepository.existsByHolidayDate(requestDTO.getHolidayDate())) {
            throw new IllegalArgumentException("Ya existe un asueto registrado para esta fecha.");
        }

        HolidayModel holiday = new HolidayModel();
        holiday.setHolidayDate(requestDTO.getHolidayDate());
        holiday.setDescription(requestDTO.getDescription());

        HolidayModel savedHoliday = holidayRepository.save(holiday);
        return mapToDTO(savedHoliday);
    }

    // Actualizar un asueto existente
    @CacheEvict(value = "calendarCache", allEntries = true)
    public HolidayResponseDTO updateHoliday(UUID id, HolidayRequestDTO requestDTO) {
        HolidayModel holiday = holidayRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Asueto no encontrado."));

        // Validar si la nueva fecha choca con otra existente (y no es el mismo registro)
        if (!holiday.getHolidayDate().equals(requestDTO.getHolidayDate()) && 
            holidayRepository.existsByHolidayDate(requestDTO.getHolidayDate())) {
            throw new IllegalArgumentException("Ya existe otro asueto registrado para esta nueva fecha.");
        }

        holiday.setHolidayDate(requestDTO.getHolidayDate());
        holiday.setDescription(requestDTO.getDescription());

        HolidayModel updatedHoliday = holidayRepository.save(holiday);
        return mapToDTO(updatedHoliday);
    }

    // Eliminar un asueto
    @CacheEvict(value = "calendarCache", allEntries = true)
    public void deleteHoliday(UUID id) {
        if (!holidayRepository.existsById(id)) {
            throw new IllegalArgumentException("Asueto no encontrado.");
        }
        holidayRepository.deleteById(id);
    }

    // --- Método Helper para mapear Entity a DTO ---
    private HolidayResponseDTO mapToDTO(HolidayModel model) {
        HolidayResponseDTO dto = new HolidayResponseDTO();
        dto.setId(model.getId());
        dto.setHolidayDate(model.getHolidayDate());
        dto.setDescription(model.getDescription());
        return dto;
    }
}
