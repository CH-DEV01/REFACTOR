package com.davivienda.factoraje.domain.dto.creditLine;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepaymentResponseDTO {

    private BigDecimal newConsumedAmount;
    private BigDecimal newAvailableLimit;
    private BigDecimal newUtilizationRate;
}