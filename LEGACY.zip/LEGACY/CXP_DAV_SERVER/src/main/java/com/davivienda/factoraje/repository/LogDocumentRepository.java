package com.davivienda.factoraje.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.model.LogDocumentModel;

@Repository
public interface LogDocumentRepository extends JpaRepository<LogDocumentModel, UUID> {

    @Query("SELECT l FROM LogDocumentModel l WHERE l.document.document_id = :docId ORDER BY l.date_time_action ASC")
    List<LogDocumentModel> obtenerBitacoraPorDocumento(@Param("docId") UUID docId);
}