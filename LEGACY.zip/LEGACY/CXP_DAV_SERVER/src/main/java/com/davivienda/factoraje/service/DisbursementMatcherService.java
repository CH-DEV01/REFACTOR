package com.davivienda.factoraje.service;

import com.davivienda.factoraje.strategy.DisbursementStrategy;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DisbursementMatcherService {

    // Un mapa que asocia el 'code' de la BD con su respectiva clase de Java
    private final Map<String, DisbursementStrategy> strategies;

    // Spring inyecta automáticamente todas las clases que implementan la interfaz
    public DisbursementMatcherService(List<DisbursementStrategy> strategyList) {
        this.strategies = strategyList.stream()
                .collect(Collectors.toMap(DisbursementStrategy::getPolicyCode, s -> s));
    }

    /**
     * Calcula la fecha basándose dinámicamente en el código de política que viene de la BD.
     */
    public LocalDate calcularFechaDesembolso(LocalDateTime fechaSolicitud, String policyCode) {
        DisbursementStrategy strategy = strategies.get(policyCode);
        
        if (strategy == null) {
            throw new IllegalArgumentException("La metodología de desembolso '" + policyCode + "' no está implementada en el sistema de software.");
        }
        
        return strategy.calcular(fechaSolicitud);
    }
}