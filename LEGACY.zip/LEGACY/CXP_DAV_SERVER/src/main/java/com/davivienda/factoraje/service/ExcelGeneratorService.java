package com.davivienda.factoraje.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.model.DisbursementBatchModel;
import com.davivienda.factoraje.domain.model.DocumentModel;
import com.davivienda.factoraje.domain.model.EntityModel;
import com.davivienda.factoraje.repository.EntityRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor 
public class ExcelGeneratorService {

    private final EntityRepository supplierRepository; 

    public byte[] generarExcelDeLote(DisbursementBatchModel batch) throws IOException {
        try (Workbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Lote " + batch.getBatchNumber());

            CellStyle titleStyle = createTitleStyle(workbook);
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle currencyStyle = createCurrencyStyle(workbook);

            int rowNum = 0;

            // ==========================================
            // SECCIÓN 1: INFORMACIÓN GENERAL DEL LOTE
            // ==========================================
            Row rowTitle = sheet.createRow(rowNum++);
            Cell cellTitle = rowTitle.createCell(0);
            cellTitle.setCellValue("INFORMACIÓN GENERAL DEL LOTE");
            cellTitle.setCellStyle(titleStyle);

            crearFilaInfo(sheet, rowNum++, "ID Lote:", batch.getBatchNumber());
            crearFilaInfo(sheet, rowNum++, "Fecha de Generación:", batch.getCreatedAt() != null ? batch.getCreatedAt().toString() : "N/A");
            crearFilaInfo(sheet, rowNum++, "Total Documentos:", String.valueOf(batch.getDocuments().size()));
            
            rowNum++; // Fila vacía para separación

            // ==========================================
            // SECCIÓN 2: TABLA DE DOCUMENTOS
            // ==========================================
            Row headerRow = sheet.createRow(rowNum++);
            String[] columns = {
                "Fecha de Desembolso", 
                "Monto", 
                "Comisión", 
                "Intereses", 
                "Nombre del Proveedor", 
                "NIT", 
                "Cuenta Bancaria"
            };

            for (int i = 0; i < columns.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
                cell.setCellStyle(headerStyle);
            }

            // Iterar sobre los documentos del lote
            for (DocumentModel doc : batch.getDocuments()) {
                Row row = sheet.createRow(rowNum++);

                // --- 1. Extracción de datos relacionales ---
                
                // Obtenemos el UUID del proveedor guardado en el acuerdo
                UUID supplierId = doc.getAgreement().getSupplier();
                
                // Buscamos al proveedor en la base de datos (manejando el caso en que no exista)
                EntityModel supplier = supplierRepository.findById(supplierId).orElse(null);
                
                String nit = (supplier != null && supplier.getNit() != null) ? supplier.getNit() : "N/A";
                String bankAccount = (supplier != null && supplier.getAccountBank() != null) ? supplier.getAccountBank() : "N/A";
                
                // (Si los intereses están en el acuerdo, los sacarías con: doc.getAgreement().getInterests())
                BigDecimal interests = BigDecimal.ZERO; 

                // --- 2. Llenado de la fila ---
                
                row.createCell(0).setCellValue(doc.getDisbursementDate() != null ? doc.getDisbursementDate() : "Pendiente");

                Cell amountCell = row.createCell(1);
                amountCell.setCellValue(getSafeDouble(doc.getAmountToFinance()));
                amountCell.setCellStyle(currencyStyle);

                Cell commCell = row.createCell(2);
                commCell.setCellValue(getSafeDouble(doc.getCommission()));
                commCell.setCellStyle(currencyStyle);

                Cell interestCell = row.createCell(3);
                interestCell.setCellValue(getSafeDouble(doc.getInterest())); 
                interestCell.setCellStyle(currencyStyle);

                row.createCell(4).setCellValue(doc.getSupplierName());
                row.createCell(5).setCellValue(nit);
                row.createCell(6).setCellValue(bankAccount);
            }

            for (int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(outputStream);
            return outputStream.toByteArray();
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES (Se mantienen igual)
    // ==========================================

    private void crearFilaInfo(Sheet sheet, int rowNum, String etiqueta, String valor) {
        Row row = sheet.createRow(rowNum);
        Cell cellLabel = row.createCell(0);
        cellLabel.setCellValue(etiqueta);
        
        Workbook wb = sheet.getWorkbook();
        CellStyle boldStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        boldStyle.setFont(font);
        cellLabel.setCellStyle(boldStyle);

        row.createCell(1).setCellValue(valor);
    }

    private CellStyle createTitleStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 14);
        style.setFont(font);
        return style;
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.DARK_RED.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        return style;
    }

    private CellStyle createCurrencyStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        style.setDataFormat(format.getFormat("$#,##0.00")); 
        return style;
    }

    private double getSafeDouble(BigDecimal value) {
        return value != null ? value.doubleValue() : 0.0;
    }
}