package com.davivienda.factoraje.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.dto.holiday.HolidayRequestDTO;
import com.davivienda.factoraje.domain.dto.holiday.HolidayResponseDTO; 
import com.davivienda.factoraje.service.HolidayService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/holidays")
@RequiredArgsConstructor
public class HolidayController {

    private final HolidayService holidayService;

    @GetMapping
    public ResponseEntity<List<HolidayResponseDTO>> getAllHolidays() {
        return ResponseEntity.ok(holidayService.getAllHolidays());
    }

    @PostMapping
    public ResponseEntity<HolidayResponseDTO> createHoliday(@RequestBody HolidayRequestDTO requestDTO) {
        HolidayResponseDTO createdHoliday = holidayService.createHoliday(requestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdHoliday);
    }

    @PutMapping("/{id}")
    public ResponseEntity<HolidayResponseDTO> updateHoliday(
            @PathVariable UUID id, 
            @RequestBody HolidayRequestDTO requestDTO) {
        HolidayResponseDTO updatedHoliday = holidayService.updateHoliday(id, requestDTO);
        return ResponseEntity.ok(updatedHoliday);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHoliday(@PathVariable UUID id) {
        holidayService.deleteHoliday(id);
        return ResponseEntity.noContent().build();
    }
}
