package com.davivienda.factoraje.domain.dto.supplier;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SupplierDTOResponse {

    private UUID id;
    private String name;
    
}
