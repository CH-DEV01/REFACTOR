package com.davivienda.factoraje.domain.dto.payer;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PayerDTOResponse {
    
    private UUID id;
    private String name;

}
