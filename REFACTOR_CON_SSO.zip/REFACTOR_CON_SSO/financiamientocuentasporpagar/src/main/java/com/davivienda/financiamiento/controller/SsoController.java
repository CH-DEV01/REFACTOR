package com.davivienda.financiamiento.controller;

import com.davivienda.financiamiento.domain.dto.StartSessionRequestDTO;
import com.davivienda.financiamiento.domain.dto.StartSessionResponseDTO;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.view.RedirectView;

import java.util.Map;

@RestController
public class SsoController {

    private static final Logger log = LoggerFactory.getLogger(SsoController.class);

    @Autowired
    private RestTemplate restTemplate;

    // Token esperado — el que envía Pay Davivienda en el form POST (paso 7).
    // En producción este valor se busca en base de datos / cache, no hardcodeado.

    /**
     * Paso 8 — Endpoint de recepción SSO.
     *
     * Recibe el sessionToken de Pay vía POST application/x-www-form-urlencoded,
     * lo compara con el token esperado, invalida la sesión anterior para prevenir
     * session fixation (OWASP A07), genera un nuevo session token propio y
     * redirige al index.
     *
     * URL: POST /start-session?OpenAgent
     */
    @PostMapping("/start-session")
    @ResponseBody 
    public String startSession(
            @RequestParam("sessionToken") String sessionToken,
            HttpServletRequest request,
            HttpServletResponse httpResponse) {

        log.info("[start-session] Solicitud recibida - IP: {}, sessionToken recibido: {}",
                request.getRemoteAddr(), sessionToken != null ? "presente" : "ausente");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        StartSessionRequestDTO body = new StartSessionRequestDTO();
        body.setSessionToken(sessionToken);

        HttpEntity<StartSessionRequestDTO> requestEntity = new HttpEntity<>(body, headers);

        ResponseEntity<StartSessionResponseDTO> response = restTemplate.exchange(
                // "http://localhost:8080/api/sso/activateSession",
                "http://sv4148lap.daviviendasv.com:8181/APIFinanciamientoEmpresas/api/v1/sso/activateSession",
                // "https://dev-financiamientocuentasporpagar-api.davivienda.com.sv:8443/APIFinanciamientoEmpresas/api/sso/activateSession",
                // "https://dev-financiamientocuentasporpagar-api.davivienda.com.sv:8443/APIFinanciamientoEmpresas/api/sso/activateSession",
                HttpMethod.POST,
                requestEntity,
                StartSessionResponseDTO.class);

        // if (response.getBody() != null && response.getBody().getSuccess()) {
        // String jwt = response.getBody().getJwt();

        // }
        // return new
        // RedirectView("https://devpay.davivienda.com.sv/financiamientocuentasporpagar/");
        // return new RedirectView("/financiamientocuentasporpagar/");
        // return new RedirectView("/financiamientocuentasporpagar/");

        String jwt = response.getBody().getJwt();

        return "<html><body><script>" +
                "localStorage.setItem('jwt_token', '" + jwt + "');" +
                "window.location.href = '/financiamientocuentasporpagar/';" +
                "</script></body></html>";

    }

}
