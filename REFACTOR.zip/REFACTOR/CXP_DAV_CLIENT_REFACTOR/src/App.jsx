import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate, Outlet } from "react-router-dom";
import { AgreementProvider } from "./context/AgreementContext";
import { AuthProvider, useAuth, ROLES } from "./context/AuthContext";
import LoadingSpinner from "./components/LoadingSpinner";

// IMPORTACIONES
import Menu from "../src/pages/admin/Menu";
import AgreementManagement from "../src/pages/admin/AgreementManagement";
import PayerManagement from "../src/pages/admin/PayerManagement";
import UserManagement from "../src/pages/admin/UserManagement";
import ParamManagement from "./pages/admin/ParamManagement";
import PayerManagementAdmin from "./pages/admin/PayerManagementAdmin";
import UserManagement2 from "../src/pages/admin/UserManagement2";
import UploadFilePageAdmin from "./pages/admin/UploadFilePageAdmin";
import EntityManagement from "./pages/admin/EntityManagement";
import SupplierManagement from "./pages/admin/SupplierManagement";
import ViewDocument from "./pages/admin/ViewDocument";
import HolidayManagement from "./pages/admin/HolidayManagement";
import PayerCreditLineManager from "./pages/admin/PayerCreditLineManager";
import DocumentManagement from "./pages/admin/DocumentManagement";
import TermManagement from "./pages/admin/TermManagement";
import ControlTerminal from "./pages/operator/ControlTerminal";
import ApproveDocuments from "../src/pages/payer/ApproveDocumentsV2";
import UploadFilePage from "./pages/payer/UploadFilePage"; 
import ApproveDocumentsTwoModeAuth from "./pages/payer/ApproveDocumentsTwoModeAuth";
import PayerDocumentManagement from "./pages/payer/PayerDocumentManagement";
import SelectDocuments from "../src/pages/supplier/SelectDocuments";
import DocumentLog from "./pages/supplier/DocumentLog";
import SelectDocumentsTwoModeAuth from "./pages/supplier/SelectDocumentsTwoModeAuth";
import ResourceNotFound from "../src/pages/shared-pages/ResourceNotFound";
import Unauthorized from "../src/pages/shared-pages/Unauthorized";
import SelectAgreementToStart from "../src/pages/shared-pages/SelectAgreementToStart";
import Login from "../src/pages/auth/Login";
import Layout from "../src/components/layouts/MainLayout";

// ==========================================
// 1. DICCIONARIO DE COMPONENTES (Component Registry)
// Traduce el string del backend al Componente Real
// ==========================================
const COMPONENT_REGISTRY = {
  "Menu": Menu,
  "AgreementManagement": AgreementManagement,
  "PayerManagementAdmin": PayerManagementAdmin,
  "UserManagement2": UserManagement2,
  "ParamManagement": ParamManagement,
  "UploadFilePageAdmin": UploadFilePageAdmin,
  "DocumentManagement": DocumentManagement,
  "ViewDocument": ViewDocument,
  "TermManagement": TermManagement,
  "HolidayManagement": HolidayManagement,
  "PayerCreditLineManager": PayerCreditLineManager,
  "SupplierManagement": SupplierManagement,
  "ControlTerminal": ControlTerminal,
  "UploadFilePage": UploadFilePage,
  "PayerDocumentManagement": PayerDocumentManagement,
  "SelectDocuments": SelectDocuments,
  "DocumentLog": DocumentLog
};

const ProtectedRoute = ({ allowedRoles, requiredPermissions = [] }) => {
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (!user && !isLoading) {
      window.location.href = "https://devpay.davivienda.com.sv/";
    }
  }, [user, isLoading]);

  if (isLoading) return <LoadingSpinner />;
  if (!user) return null;

  const hasRole = allowedRoles.includes(user.role);
  const hasPermissions = requiredPermissions.length === 0 || 
                         requiredPermissions.every((p) => user.permissions?.includes(p));

  if (!hasRole || !hasPermissions) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet />;
};

const DynamicRedirect = () => {
  const { user, isLoading } = useAuth();
  if (isLoading) return <LoadingSpinner />;
  if (!user) return null; 
  if (user.defaultRoute) return <Navigate to={user.defaultRoute} replace />;
  return <Navigate to="/unauthorized" replace />;
};

const AppContent = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) return <LoadingSpinner />;

  // ==========================================
  // 2. RENDERIZADO DINÁMICO DE RUTAS
  // ==========================================
  const renderDynamicRoutes = () => {
    if (!user || !user.routes) return null;

    return user.routes.map((route, index) => {
      const Component = COMPONENT_REGISTRY[route.componentName];
      
      // Si el backend mandó un componente que no existe en el diccionario, lo ignoramos
      if (!Component) {
        console.warn(`Componente no encontrado en registro: ${route.componentName}`);
        return null; 
      }

      // Si es index (ruta por defecto del layout), usamos el prop 'index' de React Router
      if (route.isIndex) {
        return <Route key={index} index element={<Component />} />;
      }

      // Si es una ruta normal
      return <Route key={index} path={route.path} element={<Component />} />;
    });
  };

  return (
    <Routes>
      {/* Rutas Públicas y de Redirección */}
      <Route path="/" element={<DynamicRedirect />} />
      <Route path="/unauthorized" element={<Unauthorized />} />
      <Route path="/login" element={<Login />} />
      <Route path="*" element={<ResourceNotFound />} />

      {/* RUTA MAESTRA PROTEGIDA: Atrapa todos los roles configurados dinámicamente */}
      {user && user.role && (
        <Route element={<ProtectedRoute allowedRoles={[user.role, "ADMIN"]} />}>
          
          {/* Todas las subrutas dinámicas se inyectan dentro del Layout principal de su rol */}
          <Route path={user.defaultRoute.replace('/', '')} element={<Layout />}>
            {renderDynamicRoutes()}
          </Route>
          
        </Route>
      )}
      
      {/* Rutas estáticas específicas fuera del Layout dinámico (Ej: select-agreement del proveedor) */}
      <Route element={<ProtectedRoute allowedRoles={[ROLES.SUPPLIER]} />}>
         <Route path="select-agreement" element={<SelectAgreementToStart />} />
      </Route>

    </Routes>
  );
};

function App() {
  return (
    <BrowserRouter basename="/financiamientocuentasporpagar/">
      <AuthProvider>
        <AgreementProvider>
          <AppContent />
        </AgreementProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;