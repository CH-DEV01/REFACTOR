import api from "../api";

const getDisbursementPolicies = async () => {
  try {
    const response = await api.get('/v1/disbursement-policies');
    return response;
  } catch (error) {
    console.error("Error fetching disbursement policies:", error);
    throw error;
  }
}

const getPaymentPolicies = async () => {
  try {
    const response = await api.get('/v1/payment-policies');
    return response;
  } catch (error) {
    console.error("Error fetching payment policies:", error);
    throw error;
  }
}


export const policyService = {
    getDisbursementPolicies,
    getPaymentPolicies
}