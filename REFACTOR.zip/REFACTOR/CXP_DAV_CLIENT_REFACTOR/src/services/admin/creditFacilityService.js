import api from "../api";

// READ DETAILS
export const getPayerCreditLineDetails = async(payerId) => {
    try {

        const response = await api.get(`v1/credit-facilities/payer/${payerId}`);
        return response;

    } catch (error) {

        console.error('Error fetching credit facility details:', error);
        throw error;

    }
}

export const restoreCreditFacility = async(payload) => {
    try {

        const data = {
            "creditFacilityId": payload.creditFacilityId,
            "amount": payload.amount,
            "reference": payload.reference,
            "type": payload.type
        }

        const response = await api.post('v1/credit-facilities/restore', data);
        return response.data;

    } catch (error) {

        console.error('Error restoring credit facility:', error);

        if (error.response && error.response.data && error.response.data.message) {
            throw new Error(error.response.data.message);
        }

        throw error;

    }
}

export const getHistory = async(creditFacilityId) => {
    try {

        const response = await api.get(`v1/credit-facilities/history/${creditFacilityId}`);
        return response;

    } catch (error) {

        console.error('Error fetching credit facility history:', error);
        throw error;

    }
}

export const creditFacilityService = {
    getPayerCreditLineDetails,
    restoreCreditFacility,
    getHistory
};