import api from "../api";

// CREATE
export const createParameter = async (payload) => {
    try {

        const data = {
            "param_key": payload.param_key,
            "param_value": payload.param_value
        }

        const response = await api.post('/parameters', data);
        return response;

    } catch (error) {

        console.error('Error fetching Parameters:', error);
        throw error;

    }
}

// READ ALL
export const getParameters = async () => {
    try {

        const response = await api.get('/v1/parameters?size=1000');
        return response;
    } catch (error) {
        console.error('Error fetching Parameters:', error);
        throw error;
    }
}

// UPDATE
const updateParameter = async (id, payload) => {
    try {
        const response = await api.put(`/v1/parameters/${id}`, payload);
        return response.data;
    } catch (error) {
        console.error(`Error al actualizar el parámetro con ID ${id}:`, error);
        throw error;
    }
};

// DELETE
export const deleteParameter = async (id) => {
    try {

        const response = await api.delete(`/parameters/${id}`);

        return response;

    } catch (error) {

        console.error('Error updating Parameters', error);
        throw error;

    }
}

export const parametersService = {
    createParameter,
    getParameters,
    updateParameter,
    deleteParameter
};