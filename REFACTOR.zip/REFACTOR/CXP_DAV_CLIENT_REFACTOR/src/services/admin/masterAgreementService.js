import api from "../api";

const getMasterAgreements = async () => {
    try {
        const response = await api.get("/v1/master-agreements");
        return response;
    } catch (error) {
        console.error("Error fetching master agreements:", error);
        throw error;
    }
}

/**
 * Crea un nuevo convenio marco (Master Agreement).
 * 
 * @param {Object} requestData - Objeto que cumple con la estructura de MasterAgreementDTORequest.
 * @returns {Promise<Object>} Retorna response.data, que mapea a ApiResponse<MasterAgreementDTOResponse>.
 */
const createMasterAgreement = async (requestData) => {
  try {
    // Asegúrate de ajustar la ruta "/v1/master-agreements" según tu controlador base
    const response = await api.post("/v1/master-agreements", requestData);
    return response.data;
  } catch (error) {
    console.error("Error al crear el convenio marco:", error);
    throw error;
  }
};

/**
 * Actualiza un convenio marco existente.
 * 
 * @param {String} id - El UUID del convenio marco a actualizar.
 * @param {Object} requestData - Objeto con los datos actualizados (MasterAgreementDTORequest).
 * @returns {Promise<Object>} Retorna response.data, que mapea a ApiResponse<MasterAgreementDTOResponse>.
 */
const updateMasterAgreement = async (id, requestData) => {
  try {
    const response = await api.put(`/v1/master-agreements/${id}`, requestData);
    return response.data;
  } catch (error) {
    console.error(`Error al actualizar el convenio marco con ID ${id}:`, error);
    throw error;
  }
};

export const masterAgreementService = {
    getMasterAgreements,
    createMasterAgreement,
    updateMasterAgreement
}