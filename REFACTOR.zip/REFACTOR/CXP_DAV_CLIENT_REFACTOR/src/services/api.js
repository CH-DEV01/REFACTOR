import axios from "axios";
// import { API_URL_PRODUCTION } from "../constants/apiConstants";
import { API_URL_DEVELOP } from "../constants/apiConstants";

const api = axios.create({
    baseURL: API_URL_DEVELOP,
    withCredentials: true
});

// Interceptor de Peticiones
api.interceptors.request.use(
    (config) => {
        // 1. Extraer el token del localStorage (asegúrate de que el nombre de la llave coincida con el tuyo)
        const token = localStorage.getItem("jwt_token"); 

        // 2. Si existe el token, inyectarlo en el header 'Authorization'
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        
        return config;
    },
    (error) => {
        // Manejo de errores antes de que se envíe la petición
        return Promise.reject(error);
    }
);

export default api;