import api from "../api";

/**
 * Envía el archivo Excel al backend y retorna el Blob del PDF.
 * @param {File} file - Archivo Excel seleccionado
 * @param {string} masterAgreementId - UUID del convenio marco seleccionado
 */
const uploadBatch = async (file, payerId) => {
  try {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("payerId", payerId);

    const response = await api.post("/v1/batches/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
      responseType: "blob", // VITAL: Permite recibir la respuesta en binario (PDF)
    });

    return response;
  } catch (error) {
    console.error("Error uploading document batch:", error);
    throw error;
  }
};

export const RegisterDocumentBatchService = {
  uploadBatch,
};