import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import api from "../services/api"; // Asegúrate de que este 'api' inyecte el JWT en los headers
import { API_URL_DEVELOP_AUTH } from "../constants/apiConstants";

// Puedes mantener las constantes para verificaciones específicas de UI, 
// aunque la navegación principal ahora la dicte el backend.
export const ROLES = {
  MANAGER: "MANAGER",
  SUPPLIER: "SUPPLIER",
  AUTHORIZING_TWO_MODE_AUTH: "AUTHORIZING_TWO_MODE_AUTH",
  OPERATOR: "OPERATOR",
  PAYER: "PAYER",
};

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Al cargar la app, verificamos si hay un token y traemos el perfil
  useEffect(() => {
    const initAuth = async () => {
      const token = localStorage.getItem('jwt_token'); // O sessionStorage
      if (token) {
        await fetchUserProfile(token);
      } else {
        setIsLoading(false);
      }
    };
    initAuth();
  }, []);

  const fetchUserProfile = async (token) => {
    setIsLoading(true);
    try {
      // Llamada al nuevo endpoint que creamos en Spring Boot
      const response = await api.get('/v1/auth/me', {
        headers: { Authorization: `Bearer ${token}` }
      });

      // Asumiendo que tu ApiResponse de Spring devuelve { data: { dui, role, defaultRoute, menus... } }
      const profile = response.data.data; 
      setUser(profile);
      
    } catch (error) {
      console.error("Error validando sesión:", error);
      setUser(null);
      localStorage.removeItem('jwt_token');
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (payload) => {
    setIsLoading(true);
    try {
      const response = await axios.post('/api/v1/auth/sso-login', payload, {
        baseURL: 'http://localhost:8080',
        // baseURL: 'https://devpay.davivienda.com.sv/financiamientocuentasporpagar'
      });

      // Extraemos el JWT del response de Spring Boot
      const jwt = response.data.data; 
      localStorage.setItem('jwt_token', jwt);

      // Una vez tenemos el token, traemos el perfil completo (ruta, menús, etc)
      await fetchUserProfile(jwt);
      return response;

    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      // Opcional: si tienes un endpoint de logout en el backend para invalidar el token
      await api.post('/api/v1/auth/logout'); 
    } catch (err) {
      console.error('Error al cerrar sesión:', err);
    } finally {
      setUser(null);
      localStorage.removeItem('jwt_token');
      sessionStorage.clear();
      setIsLoading(false);
      window.location.href = 'https://devpay.davivienda.com.sv/';
    }
  };

  const hasPermission = (permission) => {
    return user?.permissions?.includes(permission);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        hasPermission,
        isLoading
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);