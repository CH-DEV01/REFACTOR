// ==========================================
// 1. IMPORTS
// ==========================================

import React, { useState, useMemo, useEffect } from "react";
import { FaHandshake, FaSearch, FaPlus } from "react-icons/fa";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import Swal from "sweetalert2";

// Servicios (Ajusta las rutas según la estructura de tu proyecto)
import { entityService } from "../../services/admin/entityService.js";
import { masterAgreementService } from "../../services/admin/masterAgreementService.js";
import { policyService } from "../../services/admin/policyService.js";

// Componentes propios (Ajusta las rutas)
import Table from "../../components/Table";
import HeaderCard from "../../components/HeaderCard";
import Modal from "../../components/Modal";

// ==========================================
// 2. ESQUEMA DE VALIDACIÓN (Zod)
// ==========================================

const masterAgreementSchema = z.object({
    status: z.string().min(1, "El estado es requerido"),
    agreementType: z.string().min(1, "El tipo de convenio es requerido"),
    payerId: z.string().uuid("Seleccione un pagador válido"),
    supplierId: z.string().uuid("Seleccione un proveedor válido"),
    paymentPolicyId: z.string().uuid("Seleccione una política de pago"),
    disbursementPolicyId: z.string().uuid("Seleccione una política de desembolso"),
});

// ==========================================
// 3. CONSTANTES Y FUNCIONES AUXILIARES
// ==========================================

const columns = [
    {
        header: "Pagador",
        accessor: "PayerName",
        render: (val) => <span className="font-semibold text-slate-700 text-xs">{val}</span>
    },
    {
        header: "Proveedor",
        accessor: "supplierName",
        render: (val) => <span className="text-xs">{val}</span>
    },
    {
        header: "Politica de pago",
        accessor: "paymentPolicyDays",
        render: (val) => <span className="text-xs">{val}</span>
    },
    {
        header: "Politica de desembolso",
        accessor: "disbursementPolicyName",
        render: (val) => <span className="text-xs">{val}</span>
    },
    {
        header: "Tipo Convenio",
        accessor: "agreementType",
        render: (val) => <span className="text-xs">{val}</span>
    },
    {
        header: "Estado",
        accessor: "status",
        render: (val) => (
            <span className={`px-2 py-1 rounded-full text-[10px] font-semibold tracking-wide ${val === 'ACTIVE' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                {val}
            </span>
        )
    },
];

// ==========================================
// 4. COMPONENTE PRINCIPAL
// ==========================================

const MasterAgreementManagement = () => {
    const [agreements, setAgreements] = useState([]);
    
    // Catálogos para los menús desplegables
    const [payers, setPayers] = useState([]);
    const [suppliers, setSuppliers] = useState([]);
    const [paymentPolicies, setPaymentPolicies] = useState([]); 
    const [disbursementPolicies, setDisbursementPolicies] = useState([]); 
    
    // Estados para la tabla y modal
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingParam, setEditingParam] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 5;

    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
    } = useForm({
        resolver: zodResolver(masterAgreementSchema),
        defaultValues: {
            status: "ACTIVE",
            agreementType: "STANDARD",
            payerId: "",
            supplierId: "",
            paymentPolicyId: "",
            disbursementPolicyId: "",
        },
    });

    const fetchAgreements = async () => {
        try {
            const response = await masterAgreementService.getMasterAgreements();
            const data = response.data?.data?.content || response.data?.data || response.data || [];
            setAgreements(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error("Error fetching master agreements:", error);
            setAgreements([]);
        }
    };

    useEffect(() => {
        fetchAgreements();
    }, []);

    // ------------------------------------------
    // CARGA DE CATÁLOGOS CON LAS CORRECCIONES
    // ------------------------------------------
    useEffect(() => {
        const fetchCatalogs = async () => {
            try {
                // Obtener entidades (pagadores y proveedores)
                const resPayers = await entityService.getPayers();
                const resSuppliers = await entityService.getSuppliers();
                
                setPayers(resPayers.data?.data?.content || []);
                setSuppliers(resSuppliers.data?.data?.content || []);

                // Obtener políticas de pago y desembolso
                const resPayment = await policyService.getPaymentPolicies();
                const resDisbursement = await policyService.getDisbursementPolicies();
                
                // Mapeo correcto basándonos en tu respuesta JSON (.data directo, no .content)
                setPaymentPolicies(resPayment.data?.data || []);
                setDisbursementPolicies(resDisbursement.data?.data || []);
                
            } catch (error) {
                console.error("Error al cargar los catálogos", error);
            }
        };
        fetchCatalogs();
    }, []);

    const filteredData = useMemo(() => {
        let data = Array.isArray(agreements) ? [...agreements] : [];
        if (searchTerm) {
            const lowSearch = searchTerm.toLowerCase();
            data = data.filter(
                (item) =>
                    (item.PayerName?.toLowerCase() || "").includes(lowSearch) ||
                    (item.supplierName?.toLowerCase() || "").includes(lowSearch)
            );
        }
        return data;
    }, [searchTerm, agreements]);

    const totalPages = Math.ceil(filteredData.length / ITEMS_PER_PAGE) || 1;

    const paginatedData = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        const endIndex = startIndex + ITEMS_PER_PAGE;
        return filteredData.slice(startIndex, endIndex);
    }, [filteredData, currentPage]);

    // ------------------------------------------
    // MANEJADORES DE EVENTOS
    // ------------------------------------------

    const onSubmit = async (formData) => {
        Swal.fire({
            title: "Procesando...",
            text: "Guardando la información, por favor espere.",
            allowOutsideClick: false,
            didOpen: () => Swal.showLoading(),
        });

        try {
            const requestPayload = {
                status: formData.status,
                agreementType: formData.agreementType,
                payerId: formData.payerId,
                supplierId: formData.supplierId,
                paymentPolicyId: formData.paymentPolicyId,
                disbursementPolicyId: formData.disbursementPolicyId,
            };

            if (editingParam) {
                await masterAgreementService.updateMasterAgreement(editingParam.id, requestPayload)
            } else {
                await masterAgreementService.createMasterAgreement(requestPayload);
            }

            Swal.fire({
                icon: "success",
                title: "¡Éxito!",
                text: editingParam ? "Convenio actualizado correctamente." : "Convenio registrado correctamente.",
                timer: 2000,
                showConfirmButton: false,
            });

            fetchAgreements();
            handleCloseModal();
        } catch (error) {
            const errorMsg = error.response?.data?.message || "No se pudo guardar el convenio. Intenta de nuevo.";
            Swal.fire({ icon: "error", title: "Error", text: errorMsg });
        }
    };

    const handleCreate = () => {
        setEditingParam(null);
        reset({
            status: "ACTIVE", 
            agreementType: "STANDARD",
            payerId: "", 
            supplierId: "", 
            paymentPolicyId: "", 
            disbursementPolicyId: "",
        });
        setIsModalOpen(true);
    };

    const handleEdit = (param) => {
        setEditingParam(param);
        
        reset({
            status: param.status || "ACTIVE",
            agreementType: param.agreementType || "STANDARD",
            payerId: param.payerId || "",
            supplierId: param.supplierId || "",
            paymentPolicyId: param.paymentPolicyId || "",
            disbursementPolicyId: param.disbursementPolicyId || "",
        });
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingParam(null);
        reset();
    };

    const handleDelete = () => { Swal.fire("Info", "Funcionalidad de eliminación no implementada aún.", "info"); };

    return (
        <div className="w-full min-h-screen">
            <HeaderCard
                title={"Gestion de Convenios Marco"}
                buttonText={"convenio"}
                onButtonClick={handleCreate}
                description={"Administre los acuerdos comerciales entre pagadores y proveedores."}
                icon={<FaHandshake />}
            />

            <div className="border-b border-gray-200 mb-4"></div>

            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="relative w-full md:w-1/3 shadow-sm rounded-full">
                    <input
                        type="text"
                        placeholder="Buscar por pagador o proveedor..."
                        value={searchTerm}
                        onChange={(e) => {
                            setSearchTerm(e.target.value);
                            setCurrentPage(1);
                        }}
                        className="placeholder:text-xs placeholder:font-montserrat w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-full bg-gray-50 hover:bg-gray-100 focus:bg-white focus:outline-none focus:ring-2 focus:ring-red-300 focus:border-red-400 text-sm transition-colors duration-300"
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2">
                        <FaSearch className="text-gray-400" />
                    </div>
                </div>
            </div>

            <div className="mt-6">
                <Table
                    columns={columns}
                    data={paginatedData}
                    onEdit={handleEdit}
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                />
            </div>

            <Modal
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                title={editingParam ? "Modificar convenio marco" : "Registrar nuevo convenio marco"}
                footer={
                    <>
                        <button
                            onClick={handleCloseModal}
                            className="py-2 px-4 rounded-lg text-xs font-medium bg-white text-gray-700 border border-gray-300 hover:bg-gray-100 hover:cursor-pointer transition-colors"
                        >
                            Cancelar
                        </button>
                        <button
                            onClick={handleSubmit(onSubmit)}
                            className="py-2 px-4 rounded-lg text-xs font-medium bg-red-600 text-white hover:bg-red-700 shadow-md hover:cursor-pointer transition-colors"
                        >
                            {editingParam ? "Guardar cambios" : "Registrar Convenio"}
                        </button>
                    </>
                }
            >
                <form className="grid grid-cols-2 gap-4">
                    {/* ESTADO (Siempre editable) */}
                    <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-semibold text-gray-600 mb-1">Estado <span className="text-red-500">*</span></label>
                        <select 
                            {...register("status")} 
                            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 border-gray-300 focus:ring-red-300 text-sm font-montserrat bg-white"
                        >
                            <option value="ACTIVE">Activo</option>
                            <option value="INACTIVE">Inactivo</option>
                        </select>
                    </div>

                    {/* TIPO CONVENIO (Bloqueado en edición) */}
                    <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-semibold text-gray-600 mb-1">Tipo de Convenio {(!editingParam) && <span className="text-red-500">*</span>}</label>
                        <select 
                            {...register("agreementType")} 
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 text-sm font-montserrat 
                                ${errors.agreementType ? "border-red-500 focus:ring-red-300" : "border-gray-300 focus:ring-red-300"}
                                ${editingParam ? "bg-gray-100 text-gray-500 cursor-not-allowed pointer-events-none" : "bg-white"}`}
                        >
                            <option value="STANDARD">Estándar</option>
                            <option value="SPECIAL">Especial</option>
                        </select>
                    </div>

                    {/* PAGADOR (Bloqueado en edición) */}
                    <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-semibold text-gray-600 mb-1">Pagador {(!editingParam) && <span className="text-red-500">*</span>}</label>
                        <select 
                            {...register("payerId")} 
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 text-sm font-montserrat 
                                ${errors.payerId ? "border-red-500 focus:ring-red-300" : "border-gray-300 focus:ring-red-300"}
                                ${editingParam ? "bg-gray-100 text-gray-500 cursor-not-allowed pointer-events-none" : "bg-white"}`}
                        >
                            <option value="">Seleccione un pagador</option>
                            {payers.map((payer) => (
                                <option key={payer.id} value={payer.id}>
                                    {payer.name}
                                </option>
                            ))}
                        </select>
                        {errors.payerId && <p className="text-red-500 text-[10px] mt-1">{errors.payerId.message}</p>}
                    </div>

                    {/* PROVEEDOR (Bloqueado en edición) */}
                    <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-semibold text-gray-600 mb-1">Proveedor {(!editingParam) && <span className="text-red-500">*</span>}</label>
                        <select 
                            {...register("supplierId")} 
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 text-sm font-montserrat 
                                ${errors.supplierId ? "border-red-500 focus:ring-red-300" : "border-gray-300 focus:ring-red-300"}
                                ${editingParam ? "bg-gray-100 text-gray-500 cursor-not-allowed pointer-events-none" : "bg-white"}`}
                        >
                            <option value="">Seleccione un proveedor</option>
                            {suppliers.map((supplier) => (
                                <option key={supplier.id} value={supplier.id}>
                                    {supplier.name}
                                </option>
                            ))}
                        </select>
                        {errors.supplierId && <p className="text-red-500 text-[10px] mt-1">{errors.supplierId.message}</p>}
                    </div>

                    {/* === CAMPOS SIEMPRE EDITABLES === */}

                    {/* POLÍTICA DE PAGO (Usando description en lugar de name) */}
                    <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-semibold text-gray-600 mb-1">Política de Pago <span className="text-red-500">*</span></label>
                        <select 
                            {...register("paymentPolicyId")} 
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 text-sm font-montserrat bg-white
                                ${errors.paymentPolicyId ? "border-red-500 focus:ring-red-300" : "border-gray-300 focus:ring-blue-300"}`}
                        >
                            <option value="">Seleccione política de pago</option>
                            {paymentPolicies.map((policy) => (
                                <option key={policy.id} value={policy.id}>
                                    {policy.description}
                                </option>
                            ))}
                        </select>
                        {errors.paymentPolicyId && <p className="text-red-500 text-[10px] mt-1">{errors.paymentPolicyId.message}</p>}
                    </div>

                    {/* POLÍTICA DE DESEMBOLSO (Usando name) */}
                    <div className="col-span-2 md:col-span-1">
                        <label className="block text-xs font-semibold text-gray-600 mb-1">Política de Desembolso <span className="text-red-500">*</span></label>
                        <select 
                            {...register("disbursementPolicyId")} 
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 text-sm font-montserrat bg-white
                                ${errors.disbursementPolicyId ? "border-red-500 focus:ring-red-300" : "border-gray-300 focus:ring-blue-300"}`}
                        >
                            <option value="">Seleccione pol. de desembolso</option>
                            {disbursementPolicies.map((policy) => (
                                <option key={policy.id} value={policy.id}>
                                    {policy.name}
                                </option>
                            ))}
                        </select>
                        {errors.disbursementPolicyId && <p className="text-red-500 text-[10px] mt-1">{errors.disbursementPolicyId.message}</p>}
                    </div>
                </form>
            </Modal>
        </div>
    );
};

export default MasterAgreementManagement;