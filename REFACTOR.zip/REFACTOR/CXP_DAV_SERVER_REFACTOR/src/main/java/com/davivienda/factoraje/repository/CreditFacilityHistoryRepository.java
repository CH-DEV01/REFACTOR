package com.davivienda.factoraje.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.entities.CreditFacilityHistoryModel;

@Repository 
public interface CreditFacilityHistoryRepository extends JpaRepository<CreditFacilityHistoryModel, UUID> {

    List<CreditFacilityHistoryModel> findByCreditFacilityIdOrderByCreatedAtDesc(UUID creditFacilityId);
    
}
