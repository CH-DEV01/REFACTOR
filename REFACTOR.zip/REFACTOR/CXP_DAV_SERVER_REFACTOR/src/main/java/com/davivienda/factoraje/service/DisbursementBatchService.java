package com.davivienda.factoraje.service;

import com.davivienda.factoraje.dto.disbursement_batch.DisbursementBatchDTORequest;
import com.davivienda.factoraje.dto.disbursement_batch.DisbursementeBatchDTOResponse;

public interface DisbursementBatchService {

    // Create
    DisbursementeBatchDTOResponse createDisbursementBatch(DisbursementBatchDTORequest request);
    
}
