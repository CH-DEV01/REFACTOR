package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.entities.ProductPricingTermModel;

@Repository 
public interface ProductPricingTermRepository extends JpaRepository<ProductPricingTermModel, UUID>{
    
    Boolean existsByCreditFacilityId(UUID creditFacilityId);

    Optional<ProductPricingTermModel> findByCreditFacilityId(UUID creditFacilityId);

}
