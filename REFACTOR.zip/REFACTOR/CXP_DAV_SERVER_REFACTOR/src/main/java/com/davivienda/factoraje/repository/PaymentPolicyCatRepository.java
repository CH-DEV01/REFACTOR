package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.davivienda.factoraje.domain.catalogs.PaymentPolicyCat;

public interface PaymentPolicyCatRepository extends JpaRepository<PaymentPolicyCat, UUID> {

    @Query("SELECT ma.paymentPolicy FROM MasterAgreementModel ma WHERE ma.id = :agreementId")
    Optional<PaymentPolicyCat> findPaymentPolicyByAgreementId(@Param("agreementId") UUID agreementId);

    Optional<PaymentPolicyCat> findByCode(String code);

}
