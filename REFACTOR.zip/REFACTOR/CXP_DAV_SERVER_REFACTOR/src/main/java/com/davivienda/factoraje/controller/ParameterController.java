package com.davivienda.factoraje.controller;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.dto.parameter.ParameterDTORequest;
import com.davivienda.factoraje.dto.parameter.ParameterDTOResponse;
import com.davivienda.factoraje.service.ParameterService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/parameters")
public class ParameterController {

    private final ParameterService parameterService;

    public ParameterController(ParameterService parameterService) {
        this.parameterService = parameterService;
        log.info("Initializing parameterController");
    }

    // READ ALL
    @GetMapping
    public ResponseEntity<ApiResponse<Page<ParameterDTOResponse>>> readAll(
            @PageableDefault(page = 0, size = 10) Pageable pageable) {

        log.info("Reading all parameters");

        Page<ParameterDTOResponse> response = parameterService.readAllParameters(pageable);

        return ResponseEntity.ok(ApiResponse.success(response, "Parameters successfully recovered."));
    }

    // UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ParameterDTOResponse>> update(
            @PathVariable UUID id,
            @Valid @RequestBody ParameterDTORequest request) {

        log.info("Iniciando la actualización de la entidad con ID: {}", id);
        ParameterDTOResponse response = parameterService.updateParameter(id, request);

        return ResponseEntity.ok(ApiResponse.success(response, "Parameter updated successfully."));
    }

}
