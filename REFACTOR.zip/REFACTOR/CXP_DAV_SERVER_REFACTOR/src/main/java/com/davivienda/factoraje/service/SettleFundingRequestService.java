package com.davivienda.factoraje.service;

public interface SettleFundingRequestService {
    
}
