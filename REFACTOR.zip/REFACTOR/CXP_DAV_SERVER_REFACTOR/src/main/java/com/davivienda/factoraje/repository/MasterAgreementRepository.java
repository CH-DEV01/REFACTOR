package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.entities.MasterAgreementModel;
import com.davivienda.factoraje.domain.enums.AgreementTypeEnum;

@Repository
public interface MasterAgreementRepository extends JpaRepository<MasterAgreementModel, UUID> {

        // SELECT count(1) FROM master_agreements WHERE payer_id = ? AND supplier_id = ?
        // AND agreement_type = ?
        boolean existsByPayerIdAndSupplierIdAndAgreementType(
                        UUID payerId,
                        UUID supplierId,
                        AgreementTypeEnum agreementType // O el Enum que uses
        );

        Optional<MasterAgreementModel> findByPayerId(UUID payerId);

        @Query("SELECT ma.supplier.niu FROM MasterAgreementModel ma WHERE ma.id = :agreementId")
        Optional<String> findSupplierNiuByAgreementId(@Param("agreementId") UUID agreementId);

        @Query("SELECT COUNT(ma) > 0 FROM MasterAgreementModel ma, UserModel u " +
                        "WHERE ma.id = :agreementId " +
                        "AND u.id = :userId " +
                        "AND ma.payer.id = u.entity.id")
        boolean isUserBelongingToPayer(@Param("agreementId") UUID agreementId, @Param("userId") UUID userId);

        Optional<MasterAgreementModel> findByPayerIdAndSupplierId(UUID payerId, UUID supplierId);

}
