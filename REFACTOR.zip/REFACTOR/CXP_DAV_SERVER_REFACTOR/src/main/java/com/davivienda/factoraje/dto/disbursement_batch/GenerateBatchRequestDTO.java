package com.davivienda.factoraje.dto.disbursement_batch;

import java.util.UUID;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record GenerateBatchRequestDTO(
    @NotNull(message = "El ID del usuario creador es obligatorio")
    UUID createdById,
    
    @NotBlank(message = "El nombre del archivo original es obligatorio")
    String originalFileName,

    @NotNull(message = "El ID del pagador (Payer) es obligatorio")
    UUID payerId
) {}
