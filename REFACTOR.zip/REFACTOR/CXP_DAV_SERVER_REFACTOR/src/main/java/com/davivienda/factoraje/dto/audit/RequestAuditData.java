package com.davivienda.factoraje.dto.audit;

import java.time.LocalDateTime;

public record RequestAuditData(
    String ipAddress,
    String userAgent,
    String httpMethod,
    String requestUri,  
    LocalDateTime timestamp
) {}
