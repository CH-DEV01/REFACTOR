package com.davivienda.factoraje.dto.financing_transaction;

import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.UUID;

import com.davivienda.factoraje.domain.enums.FinancingTransactionStatusEnum;

public record FinancingTransactionDTORequest(

    BigDecimal interestAmount,
    BigDecimal commissionRate,
    BigDecimal amountToFinance,
    BigDecimal amountToBeDisbursed,
    BigDecimal flatAmount,
    BigDecimal discountRate,
    BigDecimal ivaAmount,
    BigDecimal financingPercentage,
    ZonedDateTime scheduledDisbursementDate,
    FinancingTransactionStatusEnum status,
    UUID documentId,
    UUID financingRequestId

) {
    
}
