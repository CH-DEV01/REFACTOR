package com.davivienda.factoraje.service.impl;

import java.util.UUID;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.entities.SystemParameterModel;
import com.davivienda.factoraje.dto.parameter.ParameterDTORequest;
import com.davivienda.factoraje.dto.parameter.ParameterDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.ParameterRepository;
import com.davivienda.factoraje.service.ParameterService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ParameterServiceImpl implements ParameterService {

    private final ParameterRepository parameterRepository;

    public ParameterServiceImpl(ParameterRepository parameterRepository) {
        this.parameterRepository = parameterRepository;
        log.info("ParameterService initialized");
    }

    private void validateUniquenessForUpdate(ParameterDTORequest parameter, UUID currentId) {

        if (parameterRepository.existsByKeyAndIdNot(parameter.key(), currentId)) {
            log.warn("Operation rejected: Another parameter with the provided key already exists.");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: Another parameter with the provided key already exists.");
        }

        if (parameterRepository.existsByValueAndIdNot(parameter.value(), currentId)) {
            log.warn("Operation rejected: Another parameter with the provided value already exists.");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: Another parameter with the provided value already exists.");
        }

    }

    // READ
    @Override
    @Transactional(readOnly = true)
    public ParameterDTOResponse readParameter(String key) {

        log.info("Reading parameter with key: {}", key);

        return parameterRepository.findByKey(key)
                .map(ParameterDTOResponse::fromEntity)
                .orElseThrow(() -> new ResourceNotFoundException("Parameter not found"));

    }

    // READ ALL
    @Override
    @Transactional(readOnly = true)
    public Page<ParameterDTOResponse> readAllParameters(Pageable pageable) {
        log.info("Reading all parameters");
        return parameterRepository.findAll(pageable)
                .map(ParameterDTOResponse::fromEntity);
    }

    // UPDATE
    @Override
    @Transactional
    public ParameterDTOResponse updateParameter(UUID id, ParameterDTORequest request) {

        log.info("Starting update for parameter with ID: {}", id);

        SystemParameterModel parameter = parameterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Cannot update; entity with ID not found: {}" + id));

        validateUniquenessForUpdate(request, id);

        parameter.setKey(request.key());
        parameter.setValue(request.value());

        try{

            SystemParameterModel parameterUpdated = parameterRepository.saveAndFlush(parameter);
            log.info("Parameter with ID: {} successfully updated", id);
            return ParameterDTOResponse.fromEntity(parameterUpdated);

        }catch(DataIntegrityViolationException e){

            log.error("Integrity violation when attempting to update the entity.", e);
            throw new ResourceAlreadyExistsException("Integrity violation when attempting to update the entity.");

        }

    }

}
