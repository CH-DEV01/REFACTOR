package com.davivienda.factoraje.controller;

import java.net.URI;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.dto.entity.EntityDTORequest;
import com.davivienda.factoraje.dto.entity.EntityDTOResponse;
import com.davivienda.factoraje.service.EntityService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/entities")
public class EntityController {

    private final EntityService entityService;

    public EntityController(EntityService entityService) {
        this.entityService = entityService;
        log.info("Entity controller initialized");
    }

    // CREATE
    @PostMapping
    public ResponseEntity<ApiResponse<EntityDTOResponse>> create(@Valid @RequestBody EntityDTORequest request) {

        log.info("Initiating the creation of a new entity");

        EntityDTOResponse response = entityService.createEntity(request);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(response.id())
                .toUri();

        return ResponseEntity.created(location).body(ApiResponse.success(response, "Entity successfully created"));

    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse<Page<EntityDTOResponse>>> getEntities(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "ASC") String sortDir) {

        Pageable pageable = createPageRequest(page, size, sortBy, sortDir);
        Page<EntityDTOResponse> entities = entityService.getEntities(pageable);

        return ResponseEntity.ok(ApiResponse.success(entities, "Catálogo de entidades obtenido exitosamente"));
    }

    @GetMapping("/payers")
    public ResponseEntity<ApiResponse<Page<EntityDTOResponse>>> getPayers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "ASC") String sortDir) {

        Pageable pageable = createPageRequest(page, size, sortBy, sortDir);
        Page<EntityDTOResponse> payers = entityService.getPayers(pageable);

        return ResponseEntity.ok(ApiResponse.success(payers, "Catálogo de pagadores obtenido exitosamente"));
    }

    @GetMapping("/suppliers")
    public ResponseEntity<ApiResponse<Page<EntityDTOResponse>>> getSuppliers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "ASC") String sortDir) {

        Pageable pageable = createPageRequest(page, size, sortBy, sortDir);
        Page<EntityDTOResponse> suppliers = entityService.getSuppliers(pageable);

        return ResponseEntity.ok(ApiResponse.success(suppliers, "Catálogo de proveedores obtenido exitosamente"));
    }

    private Pageable createPageRequest(int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();
        return PageRequest.of(page, size, sort);
    }

}
