package com.davivienda.factoraje.dto.financing_request;

import java.math.BigDecimal;
import java.util.UUID;

import com.davivienda.factoraje.domain.entities.FinancingRequestModel;
import com.davivienda.factoraje.domain.enums.FinancingRequestStatusEnum;

public record FinancingDTOResponse(
        UUID id,
        String requestNumber,
        BigDecimal totalAmountToFinance,
        BigDecimal totalFlatAmount,
        BigDecimal totalAmountToBeDisbursed,
        FinancingRequestStatusEnum status,
        UUID supplierId,
        UUID requestedById) {

    public static FinancingDTOResponse fromEntity(FinancingRequestModel model) {
        return new FinancingDTOResponse(
            model.getId(),
            model.getRequestNumber(),
            model.getTotalAmountToFinance(),
            model.getTotalFlatAmount(),
            model.getTotalAmountToBeDisbursed(),
            model.getStatus(),
            model.getSupplier().getId(),
            model.getRequestedBy().getId());
    }

}
