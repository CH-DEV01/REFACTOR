package com.davivienda.factoraje.dto.upload_batch;

import java.math.BigDecimal;
import java.time.LocalDate;
import com.davivienda.factoraje.domain.enums.InvoiceTypeEnum;
import com.davivienda.factoraje.domain.enums.IssuanceMethodEnum;

public record InvoiceRecordDTO(
    int rowIndex,
    LocalDate issueDate,
    BigDecimal nominalAmount,
    String documentNumber,
    String generationCode,
    String receivedStamp,
    String controlNumber,
    String issuanceMethod,
    String invoiceType,
    String supplierNiu,
    String supplierNit,
    String supplierName,
    String paymentPolicy,
    String disbursementDay,
    String operatorDui,
    String operatorEmail,
    String operatorFirstName,
    String operatorMiddleName,
    String operatorFirstLastName,
    String operatorSecondLastName
) {}
    


