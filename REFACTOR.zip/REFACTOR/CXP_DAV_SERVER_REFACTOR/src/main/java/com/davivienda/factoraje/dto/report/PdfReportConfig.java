package com.davivienda.factoraje.dto.report;

import java.util.List;
import java.util.Map;

public record PdfReportConfig(
        String title,
        Map<String, String> metadata, // Información tipo llave-valor debajo del título
        String[] tableHeaders,        // Nombres de las columnas
        float[] columnWidths,         // Proporciones de ancho de las columnas
        List<String[]> tableData      // Los datos mapeados a texto puro
) {}