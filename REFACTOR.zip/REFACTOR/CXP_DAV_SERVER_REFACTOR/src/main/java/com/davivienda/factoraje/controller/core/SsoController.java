// package com.davivienda.factoraje.controller.core;

// import com.davivienda.factoraje.service.ParameterService;
// import com.davivienda.factoraje.service.SsoService;
// import com.davivienda.factoraje.domain.dto.sso.McsSSODTOResponse;
// import com.davivienda.factoraje.domain.dto.sso.SessionTokenDTORequest;
// import com.davivienda.factoraje.dto.handoff.HandoffDTORequest;
// import com.davivienda.factoraje.dto.handoff.HandoffDTOResponse;

// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.*;
// import jakarta.servlet.http.Cookie;
// import jakarta.servlet.http.HttpServletResponse;
// import lombok.extern.slf4j.Slf4j;

// import java.io.IOException;

// @RestController
// @RequestMapping("/api/sso")
// @Slf4j 
// public class SsoController {

//     private final SsoService ssoService;
//     private final ParameterService parameterService;

//     public SsoController(SsoService ssoService, ParameterService parameterService) {
//         this.ssoService = ssoService;
//         this.parameterService = parameterService;
//         log.info("SsoController initialized");
//     }

//     @PostMapping("/handoff")
//     public ResponseEntity<HandoffDTOResponse> handoff(
//             @RequestHeader("Authorization") String bearerTokenRequest,
//             @RequestBody HandoffDTORequest request) {

//         log.info("Endpoint /handoff activated");
//         log.info("Bearer Token received: {}", bearerTokenRequest);

//         HandoffDTOResponse response = ssoService.processHandoff(request.getApp(), request.getOtc(), bearerTokenRequest);

//         log.info("response to return: {}", response);
//         return ResponseEntity.ok(response);
 
//     }

    
//     @PostMapping("/activateSession")
//     public ResponseEntity<McsSSODTOResponse> activateSession(
//         @RequestBody SessionTokenDTORequest request) {
        
//         log.info("Endpoint /activateSession activated");
//         log.info("sessionToken received: {}", request.getSessionToken());

//         try {
//             String jwt = ssoService.activateSession(request.getSessionToken());
//             log.info("JWT generado correctamente: {}", jwt);
            
//             McsSSODTOResponse response = new McsSSODTOResponse();
//             response.setJwt(jwt);
//             response.setMessage("Sesión activada correctamente");
//             response.setSuccess(true);

//             return ResponseEntity.ok(response);

//         } catch (RuntimeException e) {
        
//             log.error("Error al activar sesión del usuario: {}", e.getMessage());
            
//             McsSSODTOResponse errorResponse = new McsSSODTOResponse();
//             errorResponse.setJwt(null);
//             errorResponse.setMessage("Error al activar la sesión"); // O puedes usar e.getMessage()
//             errorResponse.setSuccess(false);
            
//             return ResponseEntity.ok(errorResponse);
//         }
//     }

// }
