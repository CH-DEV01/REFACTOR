package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.entities.CreditFacilityModel;

@Repository 
public interface CreditFacilityRepository extends JpaRepository<CreditFacilityModel, UUID> {

    Optional<CreditFacilityModel> findByPayerId(UUID payerId);
    
}
