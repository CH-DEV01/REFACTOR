package com.davivienda.factoraje.dto.financing_request;

import java.math.BigDecimal;
import java.util.UUID;

import com.davivienda.factoraje.domain.enums.FinancingRequestStatusEnum;

public record FinancingDTORequest(
    String requestNumber,
    BigDecimal totalAmountToFinance,
    BigDecimal totalFlatAmount,
    BigDecimal totalAmountToBeDisbursed,
    FinancingRequestStatusEnum status,
    UUID supplierId,
    UUID requestedById
) {
    
}
