package com.davivienda.factoraje.service.impl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.catalogs.EntityTypeCat;
import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.dto.entity.EntityDTORequest;
import com.davivienda.factoraje.dto.entity.EntityDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.EntityTypeCatRepository;
import com.davivienda.factoraje.service.EntityService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EntityServiceImpl implements EntityService {

    private final EntityRepository entityRepository;
    private final EntityTypeCatRepository entityTypeCatRepository;

    private static final String PAYER_TYPE_CODE = "COD_001";
    private static final String SUPPLIER_TYPE_CODE = "COD_002";

    public EntityServiceImpl(
            EntityRepository entityRepository,
            EntityTypeCatRepository entityTypeCatRepository) {
        this.entityRepository = entityRepository;
        this.entityTypeCatRepository = entityTypeCatRepository;
        log.info("EntityService initialized");
    }

    private void validateUniqueness(EntityDTORequest entity) {
        if (entityRepository.existsByNiu(entity.niu())) {
            log.warn("Operation rejected: An entity with the provided NIU already exists.");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: An entity with the provided NIU already exists.");
        }

        if (entityRepository.existsByNit(entity.nit())) {
            log.warn("Operation rejected: An entity with the provided NIT already exists.");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: An entity with the provided NIT already exists.");
        }

        if (entityRepository.existsByName(entity.nit())) {
            log.warn("Operación rechazada: Ya existe una entidad con el nombre proporcionado");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: An entity with the provided name already exists.");
        }
    }

    private String generateMnemonicCode(String name) {

        if (name == null || name.trim().isEmpty()) {
            return "GEN-" + java.util.UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        }

        // Paso 1: Normalizar texto para separar y eliminar acentos
        String normalized = java.text.Normalizer.normalize(name, java.text.Normalizer.Form.NFD);

        String cleanString = normalized
                .replaceAll("[^\\p{ASCII}]", "")
                .replaceAll("[^a-zA-Z0-9 ]", "")
                .replaceAll("\\s+", "")
                .toUpperCase();

        if (cleanString.isEmpty()) {
            return "ENT-" + java.util.UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        }

        // Paso 2: Construir el código combinando el nombre con un sufijo único
        // Tomamos hasta los primeros 6 caracteres del nombre limpio
        int prefixLength = Math.min(cleanString.length(), 6);
        String prefix = cleanString.substring(0, prefixLength);

        // Generamos un sufijo aleatorio de 4 caracteres
        String uniqueSuffix = java.util.UUID.randomUUID().toString().substring(0, 4).toUpperCase();

        // Retornamos el prefijo + sufijo. Ej: Si el nombre es "Cooperativa", será
        // "COOPER" + "A1B2"
        return prefix + uniqueSuffix;
    }

    @Override
    @Transactional
    public EntityDTOResponse createEntity(EntityDTORequest request) {

        log.info("Starting the creation of a new entity");

        validateUniqueness(request);

        log.info("Searching for entity type with identifier: {}", request.entityTypeId());

        EntityTypeCat entityType = entityTypeCatRepository.findById(request.entityTypeId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Entity type not found with ID: " + request.entityTypeId()));

        String mnemonicCode = generateMnemonicCode(request.name());
        log.info("Generated mnemonic code: {}", mnemonicCode);

        EntityModel entityModel = EntityModel.builder()
                .niu(request.niu())
                .nit(request.nit())
                .name(request.name())
                .entityType(entityType)
                .code(mnemonicCode)
                .status(GeneralStatusEnum.ACTIVE)
                .build();

        try {
            EntityModel savedEntity = entityRepository.save(entityModel);
            log.info("Entity created successfully with ID: {}", savedEntity.getId());
            return EntityDTOResponse.fromEntity(savedEntity);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the entity. Possible race condition.", e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the entity. Possible race condition.");
        }

    }

    @Override
    @Transactional(readOnly = true)
    public Page<EntityDTOResponse> getPayers(Pageable pageable) {
        log.info("Obteniendo catálogo de entidades de tipo Pagador");
        return entityRepository.findAllByEntityTypeCode(PAYER_TYPE_CODE, pageable)
                .map(EntityDTOResponse::fromEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EntityDTOResponse> getSuppliers(Pageable pageable) {
        log.info("Obteniendo catálogo de entidades de tipo Proveedor");
        return entityRepository.findAllByEntityTypeCode(SUPPLIER_TYPE_CODE, pageable)
                .map(EntityDTOResponse::fromEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EntityDTOResponse> getEntities(Pageable pageable) {
        log.info("Obteniendo catálogo de entidades");
        return entityRepository.findAll(pageable)
                .map(EntityDTOResponse::fromEntity);
    }

}
