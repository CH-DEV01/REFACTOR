package com.davivienda.factoraje.domain.enums;

public enum BatchTypeEnum {

    UPLOAD("UPL"), // Lotes de carga (Documentos / DTEs)
    FUNDING_REQUEST("FND"), // Lotes de solicitud de financiamiento
    DISBURSEMENT("DSB"); // Lotes de confirmación de desembolsos

    private final String prefix;

    BatchTypeEnum(String prefix) {
        this.prefix = prefix;
    }

    public String getPrefix() {
        return prefix;
    }
}
