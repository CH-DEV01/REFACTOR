package com.davivienda.factoraje.service;

import java.util.List;
import java.util.UUID;

import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.dto.funding_request.CalculateDTOResponse;

public interface FundingRequestService {


    CalculateDTOResponse checkCost(UUID masterAgreementId, UUID requestedById, List<DocumentModel> documents);

    CalculateDTOResponse submitFundingRequest(
            UUID masterAgreementId,
            UUID requestedById,
            UUID supplierId,
            List<UUID> documentIds,
            UUID termVersionId, // NUEVO: Requerido por AcceptanceAuditModel
            String userAgent // NUEVO: Requerido por AcceptanceAuditModel
    );
    
    
}
