package com.davivienda.factoraje.service;

import com.davivienda.factoraje.dto.financing_request.FinancingDTORequest;
import com.davivienda.factoraje.dto.financing_request.FinancingDTOResponse;

public interface FinancingRequestService {

    // CREATE
    FinancingDTOResponse createFinancingRequest(FinancingDTORequest request);
    
}
