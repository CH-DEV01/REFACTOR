package com.davivienda.factoraje.service.impl;

import java.util.UUID;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.catalogs.DisbursementPolicyCat;
import com.davivienda.factoraje.domain.catalogs.PaymentPolicyCat;
import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.entities.MasterAgreementModel;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.dto.master_agreement.MasterAgreementDTORequest;
import com.davivienda.factoraje.dto.master_agreement.MasterAgreementDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.DisbursementPolicyCatRepository;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.MasterAgreementRepository;
import com.davivienda.factoraje.repository.PaymentPolicyCatRepository;
import com.davivienda.factoraje.service.MasterAgreementService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MasterAgreementServiceImpl implements MasterAgreementService {

        private final MasterAgreementRepository masterAgreementRepository;
        private final DisbursementPolicyCatRepository disbursementPolicyCatRepository;
        private final PaymentPolicyCatRepository paymentPolicyCatRepository;
        private final EntityRepository entityRepository;

        public MasterAgreementServiceImpl(
                        MasterAgreementRepository masterAgreementRepository,
                        PaymentPolicyCatRepository paymentPolicyCatRepository,
                        DisbursementPolicyCatRepository disbursementPolicyCatRepository,
                        EntityRepository entityRepository) {
                this.masterAgreementRepository = masterAgreementRepository;
                this.paymentPolicyCatRepository = paymentPolicyCatRepository;
                this.disbursementPolicyCatRepository = disbursementPolicyCatRepository;
                this.entityRepository = entityRepository;
                log.info("MasterAgreement service initialized");
        }

        private void validateUniqueness(MasterAgreementDTORequest request) {
                log.debug("Validating uniqueness for payerId: {}, supplierId: {}, agreementType: {}",
                                request.payerId(), request.supplierId(), request.agreementType().name());

                // 1. Llamamos al método que acabamos de crear en el repositorio
                boolean exists = masterAgreementRepository.existsByPayerIdAndSupplierIdAndAgreementType(
                                request.payerId(),
                                request.supplierId(),
                                request.agreementType());

                // 2. Si ya existe, lanzamos la excepción de negocio
                if (exists) {
                        log.warn("Business rule violation: Attempt to duplicate master agreement.");
                        throw new ResourceAlreadyExistsException("Master agreement already exists.");
                }
        }

        @Override
        @Transactional
        public MasterAgreementDTOResponse createMasterAgreement(MasterAgreementDTORequest request) {

                log.info("Initiating the creation of the master agreement");

                validateUniqueness(request);

                PaymentPolicyCat paymentPolicy = paymentPolicyCatRepository.findById(request.paymentPolicyId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Payment policy not found with ID: " + request.paymentPolicyId()));

                DisbursementPolicyCat disbursementPolicy = disbursementPolicyCatRepository
                                .findById(request.disbursementPolicyId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Disbursement policy not found with ID: " + request.paymentPolicyId()));

                EntityModel supplier = entityRepository.findById(request.supplierId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Supplier not found with ID: " + request.supplierId()));

                EntityModel payer = entityRepository.findById(request.supplierId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Payer not found with ID: " + request.payerId()));

                MasterAgreementModel masterAgreementModel = MasterAgreementModel.builder()
                                .agreementType(request.agreementType())
                                .disbursementPolicy(disbursementPolicy)
                                .paymentPolicy(paymentPolicy)
                                .supplier(supplier)
                                .payer(payer)
                                .status(GeneralStatusEnum.ACTIVE)
                                .build();

                try {
                        MasterAgreementModel savedMasterAgreement = masterAgreementRepository
                                        .save(masterAgreementModel);
                        log.info("Master agreement created successfully with ID: {}", savedMasterAgreement.getId());
                        return MasterAgreementDTOResponse.fromEntity(savedMasterAgreement);

                } catch (DataIntegrityViolationException e) {
                        // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
                        // carrera)
                        log.error("Integrity violation when attempting to save the master agreement. Possible race condition.",
                                        e);
                        throw new ResourceAlreadyExistsException(
                                        "Integrity violation when attempting to save the master agreement. Possible race condition.");
                }

        }

        @Override
        @Transactional(readOnly = true)
        public Page<MasterAgreementDTOResponse> getPaginatedAgreements(int page, int size) {

                // Ordenamos por algún campo base. Si tienes un "createdAt" en tu modelo, úsalo
                // en lugar de "id"
                Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());

                Page<MasterAgreementModel> agreementPage = masterAgreementRepository.findAll(pageable);

                // Mapeo automático usando tu método estático
                return agreementPage.map(MasterAgreementDTOResponse::fromEntity);
        }

        @Override
        @Transactional
        public MasterAgreementDTOResponse updateMasterAgreement(UUID masterAgreementId, MasterAgreementDTORequest request) {

                log.info("Initiating the update of the master agreement with ID: {}", masterAgreementId);

                // 1. Buscamos el registro existente
                MasterAgreementModel existingAgreement = masterAgreementRepository.findById(masterAgreementId)
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Master agreement not found with ID: " + masterAgreementId));

                PaymentPolicyCat paymentPolicy = paymentPolicyCatRepository.findById(request.paymentPolicyId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Payment policy not found with ID: " + request.paymentPolicyId()));

                DisbursementPolicyCat disbursementPolicy = disbursementPolicyCatRepository
                                .findById(request.disbursementPolicyId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Disbursement policy not found with ID: "
                                                                + request.disbursementPolicyId()));

                existingAgreement.setPaymentPolicy(paymentPolicy);
                existingAgreement.setDisbursementPolicy(disbursementPolicy);
                existingAgreement.setStatus(request.status());

                // 5. Guardamos y retornamos
                try {
                        MasterAgreementModel updatedAgreement = masterAgreementRepository.save(existingAgreement);
                        log.info("Master agreement updated successfully with ID: {}", updatedAgreement.getId());

                        return MasterAgreementDTOResponse.fromEntity(updatedAgreement);

                } catch (DataIntegrityViolationException e) {
                        log.error("Integrity violation when attempting to update the master agreement. Possible race condition.",
                                        e);
                        throw new ResourceAlreadyExistsException(
                                        "Integrity violation when attempting to update the master agreement.");
                }
        }

}
