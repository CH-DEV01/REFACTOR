package com.davivienda.factoraje.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.catalogs.ActionDocumentCat;

@Repository 
public interface ActionDocumentCatRepository extends JpaRepository<ActionDocumentCat, UUID> {
    
}
