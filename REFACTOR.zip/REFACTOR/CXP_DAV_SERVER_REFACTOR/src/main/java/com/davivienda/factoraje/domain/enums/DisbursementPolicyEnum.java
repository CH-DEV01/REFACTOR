package com.davivienda.factoraje.domain.enums;

public enum DisbursementPolicyEnum {

    T_PLUS_1,
    ONLY_FRIDAYS
    
}
