package com.davivienda.factoraje.service;

import java.util.UUID;

import org.springframework.data.domain.Page;

import com.davivienda.factoraje.dto.master_agreement.MasterAgreementDTORequest;
import com.davivienda.factoraje.dto.master_agreement.MasterAgreementDTOResponse;

public interface MasterAgreementService {
    
    // CREATE
    MasterAgreementDTOResponse createMasterAgreement(MasterAgreementDTORequest request);

    // READ ALL
    Page<MasterAgreementDTOResponse> getPaginatedAgreements(int page, int size);

    // UPDATE
    MasterAgreementDTOResponse updateMasterAgreement(UUID id, MasterAgreementDTORequest request);
    
}
