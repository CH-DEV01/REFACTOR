package com.davivienda.factoraje.dto.document;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import com.davivienda.factoraje.domain.enums.DocumentStatusEnum;
import com.davivienda.factoraje.domain.enums.InvoiceTypeEnum;
import com.davivienda.factoraje.domain.enums.IssuanceMethodEnum;

public record DocumentDTORequest(

    String documentNumber,
    LocalDate issueDate,
    BigDecimal nominalAmount,
    String generationCode,
    String receivedStamp,
    String controlNumber,
    IssuanceMethodEnum issuanceMethod,
    InvoiceTypeEnum invoiceType,
    DocumentStatusEnum status,
    UUID masterAgreementId,
    UUID uploadBatchId
) {

}
