package com.davivienda.factoraje.controller.core;

import java.net.URI;
import java.util.UUID;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.davivienda.factoraje.domain.catalogs.TermVersionCat;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.domain.enums.TermTypeUniqueCodeEnum;
import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTORequest;
import com.davivienda.factoraje.dto.upload_batch.BatchProcessResult;
import com.davivienda.factoraje.infrastructure.exception.InvalidFileException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.TermVersionCatRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.RegisterDocumentBatchService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/batches")
@Validated
public class RegisterDocumentBatchController {

        private final RegisterDocumentBatchService registerDocumentBatchService;
        private final TermVersionCatRepository termVersionCatRepository;
        private final UserRepository userRepository;

        public RegisterDocumentBatchController(
                        RegisterDocumentBatchService registerDocumentBatchService,
                        TermVersionCatRepository termVersionCatRepository,
                        UserRepository userRepository) {
                this.registerDocumentBatchService = registerDocumentBatchService;
                this.termVersionCatRepository = termVersionCatRepository;
                this.userRepository = userRepository;
        }

        @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_PDF_VALUE)
        public ResponseEntity<byte[]> uploadBatch(
                        @RequestParam("file") @NotNull(message = "El archivo es obligatorio.") MultipartFile file,
                        @RequestParam("payerId") @NotNull(message = "El ID del pagador es obligatorio.") UUID payerId,
                        HttpServletRequest request) {

                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                String dui = authentication.getName();

                UserModel currentUser = userRepository.findByDui(dui)
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Usuario autenticado no encontrado en base de datos."));
                UUID userId = currentUser.getId();

                log.info("Initiating upload process for payerId: {} by userId: {}", payerId,
                                userId);

                // 1. Validar archivo (Dispara InvalidFileException si falla)
                validateFile(file);

                // 2. Extraer datos de auditoría
                String userAgent = request.getHeader("User-Agent");
                if (userAgent == null || userAgent.isBlank()) {
                        userAgent = "Unknown-Agent";
                }

                // Identificar la version con estado ACTIVE y que pertenezca al pagador
                TermVersionCat activePayerTerm = termVersionCatRepository
                                .findFirstByStatusAndTermType_UniqueCodeOrderByCreatedAtDesc(GeneralStatusEnum.ACTIVE,
                                                TermTypeUniqueCodeEnum.PAYER_TERM_TYPE.name())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "No hay términos y condiciones activos para el pagador."));

                AcceptanceAuditDTORequest auditRequest = new AcceptanceAuditDTORequest(userAgent, userId,
                                activePayerTerm.getId());

                // 3. Procesar archivo y recibir el Wrapper
                BatchProcessResult result = registerDocumentBatchService.processFile(file, auditRequest,
                                payerId, userId);

                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_PDF);

                // Establecemos la cabecera dinámica que leerá React
                headers.add("X-Batch-Status", result.isSuccess() ? "SUCCESS" : "REJECTED");

                // Le damos un nombre u otro dependiendo del resultado
                String fileName = result.isSuccess() ? "Comprobante_Carga.pdf" : "Reporte_Inconsistencias.pdf";
                headers.setContentDispositionFormData("attachment", fileName);

                // Si fue exitoso, retornamos HTTP 200 (OK)
                if (result.isSuccess()) {
                        return ResponseEntity.ok()
                                        .headers(headers)
                                        .body(result.pdfContent());
                }
                // Si falló por errores, retornamos HTTP 400 (Bad Request) pero con el PDF
                // adjunto
                else {
                        return ResponseEntity.badRequest()
                                        .headers(headers)
                                        .body(result.pdfContent());
                }
        }

        /**
         * Helper privado para validar que el archivo exista y tenga el formato
         * correcto.
         */
        private void validateFile(MultipartFile file) {
                // Valida si el archivo viene vacío (0 bytes) o nulo
                if (file == null || file.isEmpty()) {
                        throw new InvalidFileException("Es obligatorio adjuntar un archivo Excel no vacío.");
                }

                // Valida la extensión
                String originalFilename = file.getOriginalFilename();
                if (originalFilename == null ||
                                (!originalFilename.toLowerCase().endsWith(".xlsx")
                                                && !originalFilename.toLowerCase().endsWith(".xls"))) {
                        throw new InvalidFileException(
                                        "Formato de archivo no permitido. Debe adjuntar un archivo Excel (.xlsx o .xls).");
                }
        }
}