package com.davivienda.factoraje.service;

import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;

import com.davivienda.factoraje.dto.upload_batch.InvoiceRecordDTO;

public interface ExcelParserService {

    public List<InvoiceRecordDTO> parseInvoices(Workbook workbook) throws IOException;
    
}
