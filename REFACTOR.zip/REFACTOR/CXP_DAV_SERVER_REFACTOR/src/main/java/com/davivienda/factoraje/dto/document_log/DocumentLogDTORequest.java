package com.davivienda.factoraje.dto.document_log;

import java.util.UUID;
import com.davivienda.factoraje.domain.enums.DocumentStatusEnum;

public record DocumentLogDTORequest(

    UUID documentId,
    UUID userId,
    DocumentStatusEnum status,
    UUID acceptanceAuditId
) {
    
}
