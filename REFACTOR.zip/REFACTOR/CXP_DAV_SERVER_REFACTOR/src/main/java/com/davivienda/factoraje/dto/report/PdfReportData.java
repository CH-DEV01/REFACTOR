package com.davivienda.factoraje.dto.report;

import java.util.List;
import java.util.Map;

public record PdfReportData(
    String title,
    Map<String, String> summaryMetadata, // Pares Clave-Valor (Ej: "Total procesados": "150")
    String listTitle,                    // Título de la sección (Ej: "Detalle de Facturas")
    List<String> listItems,              // Para listas simples / unicolumna (Ej: Errores)
    List<String> tableHeaders,           // Encabezados de columnas (Ej: ["Fila", "N° Doc", "Monto"])
    List<List<String>> tableRows         // Filas estructuradas para reportes multicolumna
) {
    // Constructor de conveniencia para mantener compatibilidad con reportes simples unicolumna
    public PdfReportData(String title, Map<String, String> summaryMetadata, String listTitle, List<String> listItems) {
        this(title, summaryMetadata, listTitle, listItems, null, null);
    }
}