package com.davivienda.factoraje.service.impl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.catalogs.RoleCat;
import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.dto.user.UserDTORequest;
import com.davivienda.factoraje.dto.user.UserDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.RoleCatRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final EntityRepository entityRepository;
    private final RoleCatRepository roleCatRepository;

    public UserServiceImpl(
            UserRepository userRepository,
            EntityRepository entityRepository,
            RoleCatRepository roleCatRepository) {
        this.userRepository = userRepository;
        this.entityRepository = entityRepository;
        this.roleCatRepository = roleCatRepository;
        log.info("UserService initialized");
    }

    private void validateUniqueness(UserDTORequest entity) {

        if (userRepository.existsByDui(entity.dui())) {
            log.warn("Operation rejected: An entity with the provided DUI already exists.");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: An entity with the provided DUI already exists.");
        }

        if (userRepository.existsByEmail(entity.email())) {
            log.warn("Operation rejected: An entity with the provided E-mail already exists.");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: An entity with the provided E-mail already exists.");
        }
    }

    @Override
    @Transactional
    public UserDTOResponse createUser(UserDTORequest request) {

        log.info("Starting the creation of a new user");

        validateUniqueness(request);

        log.info("Searching for entity with identifier: {}", request.entityId());

        EntityModel entity = entityRepository.findById(request.entityId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Entity not found with ID: " + request.entityId()));

        RoleCat role = roleCatRepository.findById(request.roleId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Role not found with ID: " + request.roleId()));

        UserModel user = UserModel.builder()
                .dui(request.dui())
                .entity(entity)
                .role(role)
                .status(GeneralStatusEnum.ACTIVE)
                .email(request.email())
                .firstName(request.firstName())
                .lastName(request.lastName())
                .build();

        try {
            UserModel savedUser = userRepository.save(user);
            log.info("User created successfully with ID: {}", savedUser.getId());
            return UserDTOResponse.fromEntity(savedUser);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the entity. Possible race condition.", e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the entity. Possible race condition.");
        }

    }

    @Override
    @Transactional(readOnly = true)
    public Page<UserDTOResponse> getUsers(Pageable pageable) {
        log.info("Obteniendo usuarios del sistema");
        return userRepository.findAll(pageable).map(UserDTOResponse::fromEntity);
    }

}
