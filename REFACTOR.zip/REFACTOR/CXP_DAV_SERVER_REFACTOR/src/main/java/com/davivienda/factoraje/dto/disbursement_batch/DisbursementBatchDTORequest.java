package com.davivienda.factoraje.dto.disbursement_batch;

import java.math.BigDecimal;

import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.DisbursementBatchStatusEnum;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;

public record DisbursementBatchDTORequest(

    String batchNumber,
    String outputFileName,
    Integer transactionCount,
    BigDecimal totalAmount,
    BigDecimal totalCommission,
    BigDecimal totalInterest,
    DisbursementBatchStatusEnum status,
    UserModel createdBy

) {
    
}
