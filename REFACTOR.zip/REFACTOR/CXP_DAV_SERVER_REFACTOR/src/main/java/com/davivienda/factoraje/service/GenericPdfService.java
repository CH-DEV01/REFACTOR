package com.davivienda.factoraje.service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.dto.report.PdfReportConfig;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GenericPdfService {

    public byte[] generateTableReport(PdfReportConfig config) {
        Document document = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // 1. Título
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            document.add(new Paragraph(config.title(), titleFont));

            // 2. Metadatos (Ej. Total, Archivo, Fechas)
            Font metadataFont = FontFactory.getFont(FontFactory.HELVETICA, 11);
            if (config.metadata() != null) {
                for (Map.Entry<String, String> entry : config.metadata().entrySet()) {
                    document.add(new Paragraph(entry.getKey() + ": " + entry.getValue(), metadataFont));
                }
            }
            document.add(new Paragraph(" ")); // Espacio separador

            // 3. Configuración de la Tabla
            PdfPTable table = new PdfPTable(config.tableHeaders().length);
            table.setWidthPercentage(100);
            if (config.columnWidths() != null && config.columnWidths().length == config.tableHeaders().length) {
                table.setWidths(config.columnWidths());
            }

            // 4. Pintar Encabezados
            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE);
            for (String header : config.tableHeaders()) {
                PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
                cell.setBackgroundColor(Color.DARK_GRAY);
                cell.setPadding(5);
                table.addCell(cell);
            }

            // 5. Pintar Filas de Datos
            Font rowFont = FontFactory.getFont(FontFactory.HELVETICA, 9);
            for (String[] rowData : config.tableData()) {
                for (String text : rowData) {
                    table.addCell(new Phrase(text != null ? text : "", rowFont));
                }
            }

            document.add(table);

        } catch (Exception e) {
            log.error("Error al generar el reporte PDF genérico: {}", config.title(), e);
            throw new RuntimeException("Error interno al generar el documento PDF", e);
        } finally {
            document.close();
        }

        return out.toByteArray();
    }
}