package com.davivienda.factoraje.dto.master_agreement;

import java.util.UUID;

import com.davivienda.factoraje.domain.enums.AgreementTypeEnum;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;


public record MasterAgreementDTORequest(

    DateRangeDTO validityPeriod,
    AgreementTypeEnum agreementType,
    UUID payerId,
    UUID supplierId,
    UUID paymentPolicyId,
    UUID disbursementPolicyId,
    GeneralStatusEnum status

){

}