package com.davivienda.factoraje.dto.funding_request;

import java.util.List;
import java.util.UUID;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record SubmitFundingDTORequest(
        @NotNull(message = "El ID del Convenio Marco es obligatorio.") 
        UUID masterAgreementId,
        
        @NotNull(message = "El ID del usuario solicitante es obligatorio.") 
        UUID requestedById,

        @NotNull(message = "El ID del proveedor es obligatorio.") 
        UUID supplierId,
        
        @NotEmpty(message = "Debe incluir al menos un ID de documento para financiar.") 
        List<UUID> documentIds,

        @NotNull(message = "El ID de la versión de los términos y condiciones es obligatorio.") 
        UUID termVersionId
) {}