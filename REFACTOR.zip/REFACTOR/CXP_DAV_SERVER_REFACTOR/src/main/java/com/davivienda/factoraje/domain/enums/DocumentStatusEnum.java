package com.davivienda.factoraje.domain.enums;

public enum DocumentStatusEnum {

    APPROVED,
    REQUESTED_FOR_FINANCING,
    REQUESTED_FOR_DISBURSEMENT,
    DISBURSED,
    IN_QUARANTINE

}
