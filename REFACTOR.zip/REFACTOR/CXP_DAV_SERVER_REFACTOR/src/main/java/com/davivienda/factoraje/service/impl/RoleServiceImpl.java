package com.davivienda.factoraje.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.dto.role.RoleDTOResponse;
import com.davivienda.factoraje.repository.RoleCatRepository;
import com.davivienda.factoraje.service.RoleService;

@Service 
public class RoleServiceImpl implements RoleService {

    private final RoleCatRepository roleCatRepository;

    public RoleServiceImpl(

            RoleCatRepository roleCatRepository

    ) {

        this.roleCatRepository = roleCatRepository;

    }

    @Override
    @Transactional(readOnly = true)
    public List<RoleDTOResponse> getRoles() {
        return roleCatRepository.findAll().stream()
                .map(RoleDTOResponse::fromEntity)
                .toList();
    }

}
