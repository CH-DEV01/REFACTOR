package com.davivienda.factoraje.service;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.davivienda.factoraje.dto.parameter.ParameterDTORequest;
import com.davivienda.factoraje.dto.parameter.ParameterDTOResponse;

public interface ParameterService {

    // READ
    ParameterDTOResponse readParameter(String key);

    // READ ALL
    Page<ParameterDTOResponse> readAllParameters(Pageable pageable);

    // UPDATE
    ParameterDTOResponse updateParameter(UUID id, ParameterDTORequest request);
    
}
