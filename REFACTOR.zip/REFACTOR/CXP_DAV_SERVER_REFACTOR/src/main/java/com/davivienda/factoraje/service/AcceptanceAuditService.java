package com.davivienda.factoraje.service;

import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTORequest;
import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTOResponse;

public interface AcceptanceAuditService {

    //CREATE 
    // TODO: Validar que el usuario es quien dice ser
    AcceptanceAuditDTOResponse createAcceptanceAudit(AcceptanceAuditDTORequest request);
    
}
