package com.davivienda.factoraje.dto.user;

import java.util.UUID;

public record UserDTORequest(

    String dui,
    UUID entityId,
    UUID roleId,
    String firstName,
    String lastName,
    String email

) {
    
}
