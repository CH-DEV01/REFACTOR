package com.davivienda.factoraje.controller;

import java.net.URI;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.dto.master_agreement.MasterAgreementDTORequest;
import com.davivienda.factoraje.dto.master_agreement.MasterAgreementDTOResponse;
import com.davivienda.factoraje.service.MasterAgreementService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/master-agreements")
public class MasterAgreementController {

    private final MasterAgreementService masterAgreementService;

    public MasterAgreementController(MasterAgreementService masterAgreementService) {
        this.masterAgreementService = masterAgreementService;
        log.info("MasterAgreementController initialized");

    }

    // CREATE
    @PostMapping
    public ResponseEntity<ApiResponse<MasterAgreementDTOResponse>> create(
            @Valid @RequestBody MasterAgreementDTORequest request) {

        log.info("Initiating the creation of a new master agreement");

        MasterAgreementDTOResponse response = masterAgreementService.createMasterAgreement(request);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(response.id())
                .toUri();

        return ResponseEntity.created(location)
                .body(ApiResponse.success(response, "Master agreement successfully created"));

    }

    @GetMapping
    public ResponseEntity<ApiResponse<Page<MasterAgreementDTOResponse>>> getPaginatedAgreements(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<MasterAgreementDTOResponse> paginatedResult = masterAgreementService.getPaginatedAgreements(page, size);

        return ResponseEntity.ok(ApiResponse.success(paginatedResult, "Convenios obtenidos exitosamente"));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<MasterAgreementDTOResponse>> updateMasterAgreement(
            @PathVariable UUID id,
            @Valid @RequestBody MasterAgreementDTORequest request) {

        log.info("Recibida petición para actualizar el convenio marco con ID: {}", id);

        MasterAgreementDTOResponse response = masterAgreementService.updateMasterAgreement(id, request);

        return ResponseEntity.ok(ApiResponse.success(
                response,
                "Convenio marco actualizado exitosamente."));
    }

}
