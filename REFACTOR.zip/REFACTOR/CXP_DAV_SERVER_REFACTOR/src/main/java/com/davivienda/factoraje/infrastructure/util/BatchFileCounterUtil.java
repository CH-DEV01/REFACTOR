package com.davivienda.factoraje.infrastructure.util;

import java.io.InputStream;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.web.multipart.MultipartFile;

public class BatchFileCounterUtil {

    private BatchFileCounterUtil() {}

    /**
     * Cuenta los registros de datos en una hoja específica de un archivo .xlsx.
     * 
     * @param file El archivo subido por el cliente.
     * @param sheetName El nombre exacto de la pestaña a leer (Ej. "Facturas").
     * @param hasHeader Indica si la primera fila es encabezado (para restarla del total).
     * @return El número de registros reales (sin contar el encabezado).
     */
    public static int countExcelRecords(MultipartFile file, String sheetName, boolean hasHeader) {
        if (file == null || file.isEmpty() || sheetName == null || sheetName.isBlank()) {
            return 0;
        }

        try (InputStream inputStream = file.getInputStream();
             Workbook workbook = WorkbookFactory.create(inputStream)) {

            // Buscamos la hoja por su nombre exacto
            Sheet sheet = workbook.getSheet(sheetName);

            // FAIL-FAST: Si el cliente subió un Excel pero le borró o cambió el nombre a la hoja
            if (sheet == null) {
                // Lo ideal a nivel Enterprise es lanzar una excepción de negocio que el GlobalExceptionHandler
                // convierta en un mensaje amigable (HTTP 400 Bad Request) para el Frontend.
                throw new IllegalArgumentException(
                    String.format("El archivo no tiene el formato correcto. Debe contener una pestaña llamada '%s'.", sheetName)
                );
            }

            // Contamos las filas con contenido físico
            int totalRows = sheet.getPhysicalNumberOfRows();

            if (totalRows == 0) {
                return 0;
            }

            // Restamos el encabezado si existe
            int dataRecords = hasHeader ? totalRows - 1 : totalRows;

            return Math.max(dataRecords, 0);

        } catch (IllegalArgumentException e) {
            throw e; // Relanzamos la excepción de negocio para que la atrape el controlador
        } catch (Exception e) {
            // Error técnico (Ej. archivo corrupto o encriptado con contraseña)
            throw new RuntimeException("Error al leer el archivo Excel: " + e.getMessage());
        }
    }
}
