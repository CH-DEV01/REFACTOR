package com.davivienda.factoraje.infrastructure.file_parser.excel;

import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class GenericExcelParser {

    /**
     * @param <T>             El tipo de Record a construir.
     * @param workbook        El archivo de Excel procesado por Apache POI.
     * @param sheetName       El nombre exacto de la pestaña a leer (si es null, lee la primera).
     * @param requiredHeaders Nombres de las columnas que no pueden faltar en el Excel.
     * @param rowMapper       La expresión lambda que construirá el Record.
     * @return Un objeto Result que contiene registros exitosos y errores acumulados.
     */
    public <T> ExcelParseResult<T> parse(Workbook workbook, String sheetName, List<String> requiredHeaders,
            ExcelRowMapper<T> rowMapper) {

        Sheet sheet = sheetName != null ? workbook.getSheet(sheetName) : workbook.getSheetAt(0);
        if (sheet == null) {
            throw new IllegalArgumentException("The specified spreadsheet was not found.");
        }

        DataFormatter formatter = new DataFormatter();
        FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

        Row headerRow = sheet.getRow(0);
        if (headerRow == null) {
            throw new IllegalArgumentException("The Excel file is empty or does not contain headers.");
        }

        Map<String, Integer> headerIndexMap = buildHeaderIndexMap(headerRow, formatter);
        validateHeaders(headerIndexMap, requiredHeaders);

        List<T> successfulRecords = new ArrayList<>();
        List<BatchValidationError> errors = new ArrayList<>();

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);

            if (row == null || isRowEmpty(row))
                continue;

            ExcelRowAccessor accessor = new ExcelRowAccessor(row, headerIndexMap, formatter, evaluator);

            try {
                // Intentamos mapear la fila
                T dto = rowMapper.mapRow(accessor, i + 1);
                successfulRecords.add(dto);
            } catch (IllegalArgumentException e) {
                // Capturamos el error específico del Accessor y lo acumulamos
                errors.add(new BatchValidationError(i + 1, "N/A", e.getMessage()));
            } catch (Exception e) {
                // Capturamos cualquier otro error inesperado en esa fila
                errors.add(new BatchValidationError(i + 1, "N/A", "Unexpected error processing row: " + e.getMessage()));
            }
        }

        return new ExcelParseResult<>(successfulRecords, errors);
    }

    private Map<String, Integer> buildHeaderIndexMap(Row headerRow, DataFormatter formatter) {
        Map<String, Integer> map = new HashMap<>();
        for (Cell cell : headerRow) {
            String headerName = formatter.formatCellValue(cell).trim().toLowerCase();
            if (!headerName.isBlank()) {
                map.put(headerName, cell.getColumnIndex());
            }
        }
        return map;
    }

    private void validateHeaders(Map<String, Integer> headerIndexMap, List<String> requiredHeaders) {
        if (requiredHeaders == null)
            return;

        for (String req : requiredHeaders) {
            if (!headerIndexMap.containsKey(req.toLowerCase())) {
                throw new IllegalArgumentException("File rejected: Structural column missing -> " + req);
            }
        }
    }

    private boolean isRowEmpty(Row row) {
        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            if (cell != null && cell.getCellType() != CellType.BLANK) {
                return false;
            }
        }
        return true;
    }
}
