package com.davivienda.factoraje.infrastructure.file_parser.excel;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;

public class ExcelRowAccessor {
    
    private final Row row;
    private final Map<String, Integer> headerIndexMap;
    private final DataFormatter formatter;
    private final FormulaEvaluator evaluator;

    public ExcelRowAccessor(Row row, Map<String, Integer> headerIndexMap, DataFormatter formatter, FormulaEvaluator evaluator) {
        this.row = row;
        this.headerIndexMap = headerIndexMap;
        this.formatter = formatter;
        this.evaluator = evaluator;
    }

    public String getString(String columnName) {
        Integer cellIndex = headerIndexMap.get(columnName.toLowerCase());
        if (cellIndex == null) return null;
        
        Cell cell = row.getCell(cellIndex);
        if (cell == null || cell.getCellType() == CellType.BLANK) return null;
        
        // DataFormatter es seguro para textos, extrae exactamente lo que el usuario ve en pantalla
        String value = formatter.formatCellValue(cell, evaluator);
        return value != null ? value.trim() : null;
    }

    /**
     * Mapeo estricto para valores financieros.
     * Rechaza cualquier celda que no esté formateada nativamente como Número o Contabilidad.
     */
    public BigDecimal getBigDecimal(String columnName) {
        Integer cellIndex = headerIndexMap.get(columnName.toLowerCase());
        if (cellIndex == null) return BigDecimal.ZERO;

        Cell cell = row.getCell(cellIndex);
        if (cell == null || cell.getCellType() == CellType.BLANK) return BigDecimal.ZERO;

        // VALIDACIÓN ESTRICTA: Solo acepta tipo NUMERIC (o fórmulas que devuelvan NUMERIC)
        if (cell.getCellType() == CellType.NUMERIC || 
           (cell.getCellType() == CellType.FORMULA && evaluator.evaluateFormulaCell(cell) == CellType.NUMERIC)) {
            
            return BigDecimal.valueOf(cell.getNumericCellValue()).setScale(2, RoundingMode.HALF_UP);
        }

        // Si llega aquí, el usuario intentó meter texto, símbolos manuales o un formato general sucio
        throw new IllegalArgumentException(
            String.format("La celda no tiene el formato correcto en la columna '%s', fila %d. Se requiere que aplique el formato de celda 'Número' o 'Contabilidad' en Excel.", 
            columnName, row.getRowNum() + 1)
        );
    }

    /**
     * Mapeo estricto para fechas.
     * Rechaza cualquier celda que no esté formateada nativamente como Fecha en Excel.
     */
    public LocalDate getLocalDate(String columnName) {
        Integer cellIndex = headerIndexMap.get(columnName.toLowerCase());
        if (cellIndex == null) return null;

        Cell cell = row.getCell(cellIndex);
        if (cell == null || cell.getCellType() == CellType.BLANK) return null;

        // VALIDACIÓN ESTRICTA: Solo acepta NUMERIC + Formato de Fecha de Excel
        if (cell.getCellType() == CellType.NUMERIC || 
           (cell.getCellType() == CellType.FORMULA && evaluator.evaluateFormulaCell(cell) == CellType.NUMERIC)) {
            
            if (DateUtil.isCellDateFormatted(cell)) {
                return cell.getLocalDateTimeCellValue().toLocalDate();
            }
        }

        // Si llega aquí, el usuario digitó la fecha como texto plano (Ej. "15/08/2023" en una celda general)
        throw new IllegalArgumentException(
            String.format("La celda no tiene el formato correcto en la columna '%s', fila %d. Se requiere que aplique el formato de celda 'Fecha' en Excel y no texto plano.", 
            columnName, row.getRowNum() + 1)
        );
    }
}