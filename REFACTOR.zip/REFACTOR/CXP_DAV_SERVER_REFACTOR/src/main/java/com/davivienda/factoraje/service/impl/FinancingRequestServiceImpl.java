package com.davivienda.factoraje.service.impl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.entities.FinancingRequestModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.FinancingRequestStatusEnum;
import com.davivienda.factoraje.dto.financing_request.FinancingDTORequest;
import com.davivienda.factoraje.dto.financing_request.FinancingDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.FinancingRequestRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.FinancingRequestService;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FinancingRequestServiceImpl implements FinancingRequestService {

    private final FinancingRequestRepository financingRequestRepository;
    private final UserRepository userRepository;
    private final EntityRepository entityRepository;

    public FinancingRequestServiceImpl(
            FinancingRequestRepository financingRequestRepository,
            UserRepository userRepository,
            EntityRepository entityRepository) {
        this.financingRequestRepository = financingRequestRepository;
        this.userRepository = userRepository;
        this.entityRepository = entityRepository;
        log.info("FinancingRequestService initialized");
    }

    private void validateUniqueness(String requestNumber) {
        log.info("Validating uniqueness for requestNumber: {}", requestNumber);

        // 1. Llamamos al método que acabamos de crear en el repositorio
        boolean exists = financingRequestRepository.existsByRequestNumber(requestNumber);

        // 2. Si ya existe, lanzamos la excepción de negocio
        if (exists) {
            log.warn("Business rule violation: Attempt to duplicate request number.");
            throw new ResourceAlreadyExistsException("Request number already exists.");
        }
    }

    @Override
    @Transactional
    public FinancingDTOResponse createFinancingRequest(FinancingDTORequest request) {

        validateUniqueness(request.requestNumber());

        EntityModel supplier = entityRepository.findById(request.supplierId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Supplier not found with ID: " + request.supplierId()));

        UserModel requestedBy = userRepository.findById(request.requestedById())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + request.requestedById()));

        FinancingRequestModel financingRequest = FinancingRequestModel.builder()
                .requestNumber(request.requestNumber())
                .totalAmountToFinance(request.totalAmountToFinance())
                .totalAmountToBeDisbursed(request.totalAmountToBeDisbursed())
                .totalAmountToFinance(request.totalAmountToFinance())
                .requestedBy(requestedBy)
                .supplier(supplier)
                .status(FinancingRequestStatusEnum.SUBMITTED)
                .build();

        try {
            FinancingRequestModel savedFinancingRequest = financingRequestRepository.save(financingRequest);
            log.info("Financing request created successfully with ID: {}", savedFinancingRequest.getId());
            return FinancingDTOResponse.fromEntity(savedFinancingRequest);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the financing request. Possible race condition.", e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the financing request. Possible race condition.");
        }

    }

}
