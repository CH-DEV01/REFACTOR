package com.davivienda.factoraje.infrastructure.util;

import com.davivienda.factoraje.dto.audit.RequestAuditData;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.LocalDateTime;

public final class RequestAudit {

    private RequestAudit() {
        throw new UnsupportedOperationException("This is a utility class and should not be instantiated.");
    }

    /**
     * Captura todos los metadatos de la petición HTTP actual.
     */
    public static RequestAuditData getCurrentRequestData() {
        HttpServletRequest request = getCurrentHttpRequest();
        if (request == null) {
            return null;
        }

        return new RequestAuditData(
            getClientIpAddress(request),
            request.getHeader("User-Agent"),
            request.getMethod(),
            request.getRequestURI(),
            LocalDateTime.now()
        );
    }

    /**
     * Lógica experta para extraer la IP real, evadiendo proxies y balanceadores.
     */
    public static String getClientIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        // Si el request pasó por múltiples proxies, X-Forwarded-For tendrá varias IPs separadas por coma.
        // La primera es siempre la IP original del cliente.
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }

        return ip;
    }

    /**
     * Helper para obtener el request HTTP desde cualquier parte del código (Servicio, Controller, etc.)
     */
    private static HttpServletRequest getCurrentHttpRequest() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        return attributes != null ? attributes.getRequest() : null;
    }
}