package com.davivienda.factoraje.dto.disbursement_batch;

import java.math.BigDecimal;
import java.util.UUID;

import com.davivienda.factoraje.domain.entities.DisbursementBatchModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.DisbursementBatchStatusEnum;

public record DisbursementeBatchDTOResponse(

        UUID id,
        String batchNumber,
        String outputFileName,
        Integer transactionCount,
        BigDecimal totalAmount,
        BigDecimal totalCommission,
        BigDecimal totalInterest,
        DisbursementBatchStatusEnum status,
        UserModel createdBy

) {

    public static DisbursementeBatchDTOResponse fromEntity(DisbursementBatchModel model) {
        return new DisbursementeBatchDTOResponse(
                model.getId(),
                model.getBatchNumber(),
                model.getOutputFileName(),
                model.getTransactionCount(),
                model.getTotalAmount(),
                model.getTotalCommission(),
                model.getTotalInterest(),
                model.getStatus(),
                model.getCreatedBy()
                );
    }

}
