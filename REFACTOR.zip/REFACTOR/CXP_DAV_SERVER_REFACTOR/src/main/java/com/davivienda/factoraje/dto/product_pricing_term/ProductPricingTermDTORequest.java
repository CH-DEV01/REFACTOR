package com.davivienda.factoraje.dto.product_pricing_term;

import java.math.BigDecimal;
import java.util.UUID;

import com.davivienda.factoraje.domain.enums.CalculationBaseEnum;

public record ProductPricingTermDTORequest(
    
    BigDecimal interestRate,
    BigDecimal commissionRate,
    CalculationBaseEnum calculationBase,
    UUID creditFacilityId

){}
