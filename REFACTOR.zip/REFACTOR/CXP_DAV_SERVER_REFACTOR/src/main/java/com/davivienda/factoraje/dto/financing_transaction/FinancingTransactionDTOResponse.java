package com.davivienda.factoraje.dto.financing_transaction;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.UUID;

import com.davivienda.factoraje.domain.entities.FinancingTransactionModel;

public record FinancingTransactionDTOResponse(

        UUID id,
        BigDecimal interestAmount,
        BigDecimal commissionAmount,
        BigDecimal amountToFinance,
        BigDecimal amountToBeDisbursed,
        BigDecimal flatAmount,
        BigDecimal discountRate,
        BigDecimal ivaAmount,
        BigDecimal financingPercentage,
        LocalDate scheduledDisbursementDate,
        UUID documentId,
        UUID financingRequestId

) {

    public static FinancingTransactionDTOResponse fromEntity(FinancingTransactionModel model) {
        return new FinancingTransactionDTOResponse(
            model.getId(),
            model.getInterestAmount(),
            model.getCommissionAmount(),
            model.getAmountToFinance(),
            model.getAmountToBeDisbursed(),
            model.getFlatAmount(),
            model.getDiscountRate(),
            model.getIvaAmount(),
            model.getFinancingPercentage(),
            model.getScheduledDisbursementDate(),
            model.getDocument().getId(),
            model.getFinancingRequest().getId()
        );
    }

}
