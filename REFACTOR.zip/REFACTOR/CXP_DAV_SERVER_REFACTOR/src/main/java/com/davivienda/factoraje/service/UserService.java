package com.davivienda.factoraje.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.davivienda.factoraje.dto.user.UserDTORequest;
import com.davivienda.factoraje.dto.user.UserDTOResponse;

public interface UserService {

    Page<UserDTOResponse> getUsers(Pageable pageable);

    UserDTOResponse createUser(UserDTORequest request);

}
