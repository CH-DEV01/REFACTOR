package com.davivienda.factoraje.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.catalogs.DisbursementPolicyCat;
import com.davivienda.factoraje.domain.catalogs.PaymentPolicyCat;
import com.davivienda.factoraje.domain.catalogs.TermVersionCat;
import com.davivienda.factoraje.domain.entities.AcceptanceAuditModel;
import com.davivienda.factoraje.domain.entities.CreditFacilityModel;
import com.davivienda.factoraje.domain.entities.DocumentLogModel;
import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.entities.FinancingRequestModel;
import com.davivienda.factoraje.domain.entities.FinancingTransactionModel;
import com.davivienda.factoraje.domain.entities.MasterAgreementModel;
import com.davivienda.factoraje.domain.entities.ProductPricingTermModel;
import com.davivienda.factoraje.domain.entities.SystemParameterModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.DisbursementPolicyEnum;
import com.davivienda.factoraje.domain.enums.DocumentStatusEnum;
import com.davivienda.factoraje.domain.enums.FinancingRequestStatusEnum;
import com.davivienda.factoraje.dto.funding_request.CalculateDTOResponse;
import com.davivienda.factoraje.dto.funding_request.DetailDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.DocumentNotAvailableException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.AcceptanceAuditRepository;
import com.davivienda.factoraje.repository.BankHolidayCatRepository;
import com.davivienda.factoraje.repository.CreditFacilityRepository;
import com.davivienda.factoraje.repository.DocumentLogRepository;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.FinancingRequestRepository;
import com.davivienda.factoraje.repository.FinancingTransactionRepository;
import com.davivienda.factoraje.repository.MasterAgreementRepository;
import com.davivienda.factoraje.repository.ParameterRepository;
import com.davivienda.factoraje.repository.PaymentPolicyCatRepository;
import com.davivienda.factoraje.repository.ProductPricingTermRepository;
import com.davivienda.factoraje.repository.TermVersionCatRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.AcceptanceAuditService;
import com.davivienda.factoraje.service.DocumentLogService;
import com.davivienda.factoraje.service.FinancingRequestService;
import com.davivienda.factoraje.service.FundingRequestService;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FundingRequestServiceImpl implements FundingRequestService {

    private final DocumentRepository documentRepository;
    private final EntityRepository entityRepository;
    private final UserRepository userRepository;
    private final MasterAgreementRepository masterAgreementRepository;
    private final CreditFacilityRepository creditFacilityRepository;
    private final ProductPricingTermRepository productPricingTermRepository;
    private final FinancingTransactionRepository financingTransactionRepository;
    private final TermVersionCatRepository termVersionCatRepository;
    private final FinancingRequestRepository financingRequestRepository;
    private final AcceptanceAuditRepository acceptanceAuditRepository;
    private final DocumentLogRepository documentLogRepository;
    private final BankHolidayCatRepository bankHolidayCatRepository;
    private final ParameterRepository parameterRepository;

    public FundingRequestServiceImpl(

            DocumentRepository documentRepository,
            EntityRepository entityRepository,
            UserRepository userRepository,
            MasterAgreementRepository masterAgreementRepository,
            CreditFacilityRepository creditFacilityRepository,
            ProductPricingTermRepository productPricingTermRepository,
            PaymentPolicyCatRepository paymentPolicyCatRepository,
            AcceptanceAuditService acceptanceAuditService,
            DocumentLogService documentLogService,
            FinancingTransactionRepository financingTransactionRepository,
            FinancingRequestService financingRequestService,
            TermVersionCatRepository termVersionCatRepository,
            FinancingRequestRepository financingRequestRepository,
            AcceptanceAuditRepository acceptanceAuditRepository,
            DocumentLogRepository documentLogRepository,
            BankHolidayCatRepository bankHolidayCatRepository,
            ParameterRepository parameterRepository

    ) {
        this.documentRepository = documentRepository;
        this.documentLogRepository = documentLogRepository;
        this.entityRepository = entityRepository;
        this.userRepository = userRepository;
        this.masterAgreementRepository = masterAgreementRepository;
        this.creditFacilityRepository = creditFacilityRepository;
        this.productPricingTermRepository = productPricingTermRepository;
        this.financingTransactionRepository = financingTransactionRepository;
        this.termVersionCatRepository = termVersionCatRepository;
        this.financingRequestRepository = financingRequestRepository;
        this.acceptanceAuditRepository = acceptanceAuditRepository;
        this.bankHolidayCatRepository = bankHolidayCatRepository;
        this.parameterRepository = parameterRepository;
        log.info("FundingRequestService initialized");

    }

    /**
     * Motor central de cálculo financiero.
     * Se puede utilizar tanto para simular (checkCost) como para persistir
     * (submit).
     */
    private CalculationResult performFinancialCalculation(UUID masterAgreementId, List<DocumentModel> documents) {

        MasterAgreementModel masterAgreement = masterAgreementRepository.findById(masterAgreementId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Master agreement not found with ID: " + masterAgreementId));

        PaymentPolicyCat paymentPolicy = masterAgreement.getPaymentPolicy();
        DisbursementPolicyCat disbursementPolicyCat = masterAgreement.getDisbursementPolicy();

        CreditFacilityModel creditFacility = creditFacilityRepository.findByPayerId(masterAgreementId)
                .orElseThrow(() -> new ResourceNotFoundException("Credit facility not found"));

        ProductPricingTermModel productPricing = productPricingTermRepository
                .findByCreditFacilityId(creditFacility.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Product pricing not found"));

        BigDecimal interestRate = productPricing.getInterestRate();
        BigDecimal commissionRate = productPricing.getCommissionRate();
        int base = productPricing.getCalculationBase().getDays();
        Integer paymentPolicyDays = paymentPolicy.getDaysCount();
        SystemParameterModel ivaParameter = parameterRepository.findByKey("IVA_RATE")
                    .orElse(null);

        BigDecimal ivaRate = getIvaRateFromParameter(ivaParameter);

        DisbursementPolicyEnum policyEnum = DisbursementPolicyEnum.valueOf(disbursementPolicyCat.getCode());
        LocalDate disbursementDate = calculateDisbursementDate(LocalDate.now(), policyEnum);

        List<DocumentMathResult> details = new java.util.ArrayList<>();
        BigDecimal totalAmountToFinance = BigDecimal.ZERO;
        BigDecimal totalAmount = BigDecimal.ZERO;
        BigDecimal totalInterests = BigDecimal.ZERO;
        BigDecimal totalCommissions = BigDecimal.ZERO;
        BigDecimal totalAmountToDisburse = BigDecimal.ZERO;

        for (DocumentModel document : documents) {

            LocalDate issueDate = document.getIssueDate();
            LocalDate dueDate = issueDate.plusDays(paymentPolicyDays);

            Integer diffDays = (int) ChronoUnit.DAYS.between(disbursementDate, dueDate);
            if (diffDays <= 0) {
                log.warn("El documento {} ya venció o vence el mismo día del desembolso.", document.getId());
                diffDays = 0;
            }

            BigDecimal nominalAmount = document.getNominalAmount();

            BigDecimal discountFactor = calculateDiscountFactor(interestRate, base, diffDays);

            BigDecimal amountToFinance = nominalAmount.multiply(discountFactor).setScale(4, RoundingMode.HALF_UP);
            BigDecimal interest = nominalAmount.subtract(amountToFinance);

            // Separamos la comisión pura del IVA (Asumiendo IVA 13%)
            BigDecimal pureCommission = nominalAmount.multiply(commissionRate).setScale(4, RoundingMode.HALF_UP);
            BigDecimal ivaAmount = pureCommission.multiply(ivaRate).setScale(4, RoundingMode.HALF_UP);
            BigDecimal totalCommissionWithIva = pureCommission.add(ivaAmount);

            BigDecimal disburse = nominalAmount.subtract(interest).subtract(totalCommissionWithIva);

            // Guardamos el detalle extendido
            details.add(new DocumentMathResult(
                    document, issueDate, dueDate, diffDays, nominalAmount, amountToFinance,
                    interest, pureCommission, ivaAmount, discountFactor,
                    BigDecimal.ONE.subtract(discountFactor), // financingPercentage
                    disburse));

            // Acumulamos totales
            totalAmountToFinance = totalAmountToFinance.add(amountToFinance);
            totalAmount = totalAmount.add(nominalAmount);
            totalInterests = totalInterests.add(interest);
            totalCommissions = totalCommissions.add(totalCommissionWithIva);
            totalAmountToDisburse = totalAmountToDisburse.add(disburse);
        }

        return new CalculationResult(
                details, totalAmount, totalAmountToFinance, totalInterests, totalCommissions, totalAmountToDisburse,
                disbursementDate);
    }

    @Transactional
    @Override
    public CalculateDTOResponse submitFundingRequest(
            UUID masterAgreementId,
            UUID requestedById,
            UUID supplierId,
            List<UUID> documentIds,
            UUID termVersionId,
            String userAgent 
    ) {

        if (documentIds == null || documentIds.isEmpty()) {
            throw new IllegalArgumentException("La lista de documentos a financiar no puede estar vacía.");
        }

        UserModel requestedBy = userRepository.findById(requestedById)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el Usuario con ID: " + requestedById));
        EntityModel supplier = entityRepository.findById(supplierId)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el Proveedor con ID: " + supplierId));
        TermVersionCat termVersion = termVersionCatRepository.findById(termVersionId) // Asume que inyectaste este repo
                .orElseThrow(
                        () -> new ResourceNotFoundException("No se encontró la versión de Términos y Condiciones con ID: " + termVersionId));

        // 2. Extraer documentos y Fail-Fast
        List<DocumentModel> realDocuments = documentRepository.findAllById(documentIds);
        if (realDocuments.size() != documentIds.size()) {
            throw new ResourceNotFoundException("Uno o más documentos solicitados no existen en la BD.");
        }

        for (DocumentModel doc : realDocuments) {
            if (!doc.getStatus().equals(DocumentStatusEnum.APPROVED)) {
                log.error("Intento de fondeo duplicado. El documento {} está en estado {}.",
                        doc.getDocumentNumber(), doc.getStatus());

                throw new DocumentNotAvailableException("El documento ya fue solicitado o no está disponible para financiamiento.");
            }
        }

        // 3. Cálculos
        CalculationResult result = performFinancialCalculation(masterAgreementId, realDocuments);

        // 4. Crear Cabecera (FinancingRequestModel)
        FinancingRequestModel requestModel = new FinancingRequestModel();
        requestModel.setRequestNumber("REQ-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        requestModel.setTotalAmountToFinance(result.totalAmountToFinance());
        requestModel.setTotalAmountToBeDisbursed(result.totalAmountToDisburse());
        requestModel.setTotalFlatAmount(result.totalAmount());
        requestModel.setStatus(FinancingRequestStatusEnum.SUBMITTED);
        requestModel.setSupplier(supplier);
        requestModel.setRequestedBy(requestedBy);

        financingRequestRepository.save(requestModel);

        // 5. Crear el Registro de Auditoría de Aceptación (AcceptanceAuditModel)
        // Se guarda inmediatamente para poder asignarlo a los logs de los documentos
        AcceptanceAuditModel audit = new AcceptanceAuditModel();
        audit.setUserAgent(userAgent);
        audit.setUser(requestedBy);
        audit.setTermVersion(termVersion);

        acceptanceAuditRepository.save(audit);

        // 6. Procesar Transacciones, Logs y Documentos
        List<FinancingTransactionModel> transactions = new ArrayList<>();
        List<DocumentLogModel> documentLogs = new ArrayList<>();
        CalculateDTOResponse response = new CalculateDTOResponse();

        for (DocumentMathResult docMath : result.details()) {
            DocumentModel document = docMath.document();

            // 6.1 Crear modelo transaccional
            FinancingTransactionModel transaction = new FinancingTransactionModel();
            transaction.setFinancingRequest(requestModel);
            transaction.setDocument(document);
            transaction.setInterestAmount(docMath.interest());
            transaction.setCommissionAmount(docMath.commission());
            transaction.setAmountToFinance(docMath.amountToFinance());
            transaction.setFlatAmount(docMath.nominalAmount());
            transaction.setAmountToBeDisbursed(docMath.disburse());
            transaction.setDiscountRate(docMath.discountRate());
            transaction.setIvaAmount(docMath.ivaAmount());
            transaction.setFinancingPercentage(docMath.financingPercentage());
            transaction.setScheduledDisbursementDate(result.disbursementDate());

            transactions.add(transaction);

            // 6.2 Actualizar documento
            document.setStatus(DocumentStatusEnum.REQUESTED_FOR_FINANCING);

            // 6.3 Crear el Log del documento (DocumentLogModel)
            DocumentLogModel log = new DocumentLogModel();
            log.setDocument(document);
            log.setUser(requestedBy);
            log.setStatus(DocumentStatusEnum.REQUESTED_FOR_FINANCING); // Usando tu DocumentStatusEnum
            log.setAcceptanceAudit(audit);

            documentLogs.add(log);

            // 6.4 Respuesta DTO
            DetailDTOResponse detail = new DetailDTOResponse();
            detail.setDocumentNumber(document.getDocumentNumber());
            detail.setIssueDate(docMath.issueDate());
            detail.setDueDate(docMath.dueDate());
            detail.setFinancingDays(docMath.diffDays());
            detail.setAmount(docMath.nominalAmount());
            detail.setAmountToFinance(docMath.amountToFinance());
            detail.setInterests(docMath.interest());
            detail.setCommissions(docMath.commission());
            detail.setAmountToBeDisbursed(docMath.disburse());
            response.getDetail().add(detail);
        }

        // 7. Guardar en lote (Batch Saving)
        financingTransactionRepository.saveAll(transactions);
        documentRepository.saveAll(realDocuments);
        documentLogRepository.saveAll(documentLogs); // Guardamos todos los logs de un solo golpe

        // 8. Llenar totales en DTO de respuesta
        response.setAmountToFinance(result.totalAmountToFinance());
        response.setAmountToBeDisbursed(result.totalAmountToDisburse());
        response.setDisbursementDate(result.disbursementDate());

        response.setAmount(result.totalAmount());
        response.setInterests(result.totalInterests());
        response.setCommissions(result.totalCommissions());

        return response;
    }

    @Transactional
    @Override
    public CalculateDTOResponse checkCost(UUID masterAgreementId, UUID requestedById,
            List<DocumentModel> inputDocuments) {

        if (inputDocuments == null || inputDocuments.isEmpty()) {
            throw new IllegalArgumentException("La lista de documentos no puede ser nula o estar vacía");
        }

        log.info("Iniciando simulación de cálculo para {} documento(s).", inputDocuments.size());

        // 1. Obtener las entidades completas de la BD para asegurar que tenemos los
        // datos reales
        List<DocumentModel> realDocuments = inputDocuments.stream()
                .map(doc -> documentRepository.findById(doc.getId())
                        .orElseThrow(() -> new ResourceNotFoundException("Document not found with ID: " + doc.getId())))
                .toList();

        // 2. Ejecutar el motor de cálculo
        CalculationResult result = performFinancialCalculation(masterAgreementId, realDocuments);

        // 3. Mapear el resultado interno al DTO de respuesta HTTP
        CalculateDTOResponse response = new CalculateDTOResponse();

        for (DocumentMathResult docMath : result.details()) {
            DetailDTOResponse detail = new DetailDTOResponse();
            detail.setDocumentNumber(docMath.document().getDocumentNumber());
            detail.setIssueDate(docMath.issueDate());
            detail.setDueDate(docMath.dueDate());
            detail.setFinancingDays(docMath.diffDays());
            detail.setAmount(docMath.nominalAmount());
            detail.setAmountToFinance(docMath.amountToFinance());
            detail.setInterests(docMath.interest());
            detail.setCommissions(docMath.commission());
            detail.setAmountToBeDisbursed(docMath.disburse());

            response.getDetail().add(detail);
        }

        response.setAmountToFinance(result.totalAmountToFinance().setScale(2, RoundingMode.HALF_UP));
        response.setInterests(result.totalInterests().setScale(2, RoundingMode.HALF_UP));
        response.setCommissions(result.totalCommissions().setScale(2, RoundingMode.HALF_UP));
        response.setAmountToBeDisbursed(result.totalAmountToDisburse().setScale(2, RoundingMode.HALF_UP));
        response.setAmount(result.totalAmount().setScale(2, RoundingMode.HALF_UP));
        response.setDisbursementDate(result.disbursementDate);

        return response;
    }

    /**
     * Calcula el factor de descuento (porcentaje a aplicar sobre el valor nominal)
     * Fórmula: 1 / (1 + (Tasa / Base) * Días)
     */
    private BigDecimal calculateDiscountFactor(BigDecimal interestRate, int baseDays, int diffDays) {
        if (baseDays == 0) {
            log.error("División por cero evitada: la base no puede ser cero.");
            throw new IllegalArgumentException("La base para el cálculo no puede ser cero.");
        }

        if (diffDays <= 0) {
            return BigDecimal.ONE; // Si no hay días de financiamiento, el factor es 100% (sin descuento)
        }

        BigDecimal base = BigDecimal.valueOf(baseDays);
        BigDecimal days = BigDecimal.valueOf(diffDays);

        // 1. dailyRate = interestRate / base
        BigDecimal dailyRate = interestRate.divide(base, 10, RoundingMode.HALF_UP);

        // 2. daysFactor = dailyRate * days
        BigDecimal daysFactor = dailyRate.multiply(days);

        // 3. divisor = 1 + daysFactor
        BigDecimal divisor = BigDecimal.ONE.add(daysFactor);

        if (divisor.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }

        // 4. percentage = 1 / divisor
        return BigDecimal.ONE.divide(divisor, 10, RoundingMode.HALF_UP);
    }

    /**
     * Calcula la próxima fecha de desembolso según la política configurada.
     * 
     * @param startingDate Fecha base para el cálculo (usualmente LocalDate.now() o
     *                     T).
     * @param policyCode   Código de la política (ej. "VIERNES", "T_PLUS_1").
     * @return La fecha exacta en la que se debe realizar el desembolso.
     */
    public LocalDate calculateDisbursementDate(LocalDate startingDate, DisbursementPolicyEnum disbursementPolicy) {

        if (startingDate == null || disbursementPolicy == null) {
            throw new IllegalArgumentException("La fecha base y el código de política no pueden ser nulos.");
        }

        // 1. Obtener la fecha calculada inicial según la política
        LocalDate calculatedDate = switch (disbursementPolicy) {
            case ONLY_FRIDAYS -> startingDate.with(TemporalAdjusters.next(DayOfWeek.FRIDAY));
            case T_PLUS_1 -> {
                LocalDate tPlusOne = startingDate.plusDays(1);
                DayOfWeek day = tPlusOne.getDayOfWeek();
                if (day == DayOfWeek.FRIDAY || day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY) {
                    yield tPlusOne.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
                }
                yield tPlusOne;
            }
            default -> throw new IllegalArgumentException(
                    "Política de desembolso no soportada o desconocida: " + disbursementPolicy);
        };

        // 2. Obtener los feriados activos de la BD
        List<LocalDate> activeHolidays = bankHolidayCatRepository.findActiveHolidayDates();

        // 3. Ajustar al siguiente día hábil disponible
        return adjustToNextBusinessDay(calculatedDate, activeHolidays);
    }

    /**
     * Valida si una fecha es fin de semana o feriado. Si lo es, suma 1 día y vuelve a evaluar.
     */
    private LocalDate adjustToNextBusinessDay(LocalDate date, List<LocalDate> holidays) {
        LocalDate adjustedDate = date;
        
        while (isWeekend(adjustedDate) || holidays.contains(adjustedDate)) {
            adjustedDate = adjustedDate.plusDays(1);
        }
        
        return adjustedDate;
    }

    /**
     * Verifica si una fecha cae en sábado o domingo.
     */
    private boolean isWeekend(LocalDate date) {
        DayOfWeek day = date.getDayOfWeek();
        return day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY;
    }

    // Record para transportar el resultado matemático de todo el lote
    public record CalculationResult(
            List<DocumentMathResult> details,
            BigDecimal totalAmount,
            BigDecimal totalAmountToFinance,
            BigDecimal totalInterests,
            BigDecimal totalCommissions,
            BigDecimal totalAmountToDisburse,
            LocalDate disbursementDate) {
    }

    public record DocumentMathResult(
            DocumentModel document,
            LocalDate issueDate,
            LocalDate dueDate,
            Integer diffDays,
            BigDecimal nominalAmount, // Se mapeará a flatAmount
            BigDecimal amountToFinance,
            BigDecimal interest,
            BigDecimal commission,
            BigDecimal ivaAmount, // NUEVO
            BigDecimal discountRate, // NUEVO
            BigDecimal financingPercentage, // NUEVO
            BigDecimal disburse) {
    }

    private BigDecimal getIvaRateFromParameter(SystemParameterModel parameterModel) {
        if (parameterModel == null || parameterModel.getValue() == null) {
            log.warn("El parámetro del IVA es nulo. Usando valor por defecto 0.13");
            return new BigDecimal("0.13");
        }

        try {
            // Quitamos espacios en blanco por si alguien los dejó en la base de datos
            String cleanValue = parameterModel.getValue().trim();
            return new BigDecimal(cleanValue);
        } catch (NumberFormatException e) {
            log.error("El valor '{}' en la base de datos no es un número válido. Usando valor por defecto 0.13", parameterModel.getValue());
            return new BigDecimal("0.13");
        }
    }

}
