package com.davivienda.factoraje.dto.entity;

import java.util.UUID;

public record EntityDTORequest(

    String niu,
    String nit,
    String name,
    UUID entityTypeId

){}
