package com.davivienda.factoraje.dto.handoff;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HandoffDTORequest {
    private String app;
    private String otc;
}
