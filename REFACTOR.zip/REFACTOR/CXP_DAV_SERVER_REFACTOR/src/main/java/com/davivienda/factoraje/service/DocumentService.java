package com.davivienda.factoraje.service;

import com.davivienda.factoraje.dto.document.DocumentDTORequest;
import com.davivienda.factoraje.dto.document.DocumentDTOResponse;

public interface DocumentService {
    
    //CREATE
    public DocumentDTOResponse createDocument(DocumentDTORequest request);
    
}
