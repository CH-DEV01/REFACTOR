package com.davivienda.factoraje.dto.auth;

import java.util.List;

public record UserProfileResponseDTO(
    String dui,
    String firstName,
    String lastName,
    String email,
    String role,
    String defaultRoute,
    List<String> permissions,
    List<MenuDTO> menus,
    List<RouteDTO> routes
) {}
