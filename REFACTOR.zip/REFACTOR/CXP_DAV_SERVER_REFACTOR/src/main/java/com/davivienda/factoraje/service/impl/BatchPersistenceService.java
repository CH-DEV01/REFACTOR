package com.davivienda.factoraje.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.catalogs.DisbursementPolicyCat;
import com.davivienda.factoraje.domain.catalogs.EntityTypeCat;
import com.davivienda.factoraje.domain.catalogs.PaymentPolicyCat;
import com.davivienda.factoraje.domain.catalogs.RoleCat;
import com.davivienda.factoraje.domain.entities.CreditFacilityModel;
import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.entities.MasterAgreementModel;
import com.davivienda.factoraje.domain.entities.UploadBatchModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.BatchTypeEnum;
import com.davivienda.factoraje.domain.enums.DocumentStatusEnum;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.domain.enums.InvoiceTypeEnum;
import com.davivienda.factoraje.domain.enums.IssuanceMethodEnum;
import com.davivienda.factoraje.domain.enums.UploadBatchStatusEnum;
import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTORequest;
import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTOResponse;
import com.davivienda.factoraje.dto.entity.EntityDTORequest;
import com.davivienda.factoraje.dto.entity.EntityDTOResponse;
import com.davivienda.factoraje.dto.upload_batch.InvoiceRecordDTO;
import com.davivienda.factoraje.dto.upload_batch.UploadBatchDTORequest;
import com.davivienda.factoraje.dto.upload_batch.UploadBatchDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.infrastructure.util.BatchNumberGeneratorUtil;
import com.davivienda.factoraje.infrastructure.util.FileNamingUtil;
import com.davivienda.factoraje.repository.CreditFacilityRepository;
import com.davivienda.factoraje.repository.DisbursementPolicyCatRepository;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.EntityTypeCatRepository;
import com.davivienda.factoraje.repository.MasterAgreementRepository;
import com.davivienda.factoraje.repository.PaymentPolicyCatRepository;
import com.davivienda.factoraje.repository.RoleCatRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.AcceptanceAuditService;
import com.davivienda.factoraje.service.DocumentLogService;
import com.davivienda.factoraje.service.EntityService;
import com.davivienda.factoraje.service.UploadBatchService;

import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class BatchPersistenceService {

    private final EntityRepository entityRepository;
    private final EntityTypeCatRepository entityTypeCatRepository;
    private final MasterAgreementRepository masterAgreementRepository;
    private final PaymentPolicyCatRepository paymentPolicyRepository;
    private final DisbursementPolicyCatRepository disbursementPolicyRepository;
    private final CreditFacilityRepository creditFacilityRepository;
    private final AcceptanceAuditService acceptanceAuditService;
    private final UploadBatchService uploadBatchService;
    private final DocumentRepository documentRepository;
    private final DocumentLogService documentLogService;
    private final EntityManager entityManager;
    private final UserRepository userRepository;
    private final RoleCatRepository roleCatRepository;
    private final EntityService entityService; // Para crear la entidad mediante el servicio

    /**
     * Resolución y creación de entidades con transacción independiente.
     */
    @Transactional
    public MasterAgreementModel resolveOrCreateSupplierAndAgreement(EntityModel payer, InvoiceRecordDTO recordInfo) {
        log.info("Verificando existencia del proveedor con NIU: {}", recordInfo.supplierNiu());

        EntityModel supplier = entityRepository.findByNiu(recordInfo.supplierNiu()).orElse(null);

        if (supplier == null) {
            log.info("Proveedor no encontrado. Creando nuevo proveedor...");
            EntityTypeCat supplierType = entityTypeCatRepository.findByCode("COD_002")
                .orElseThrow(() -> new RuntimeException("Catálogo de tipos de entidad incompleto (SUPPLIER - COD_002)."));

            EntityDTORequest request = new EntityDTORequest(
                recordInfo.supplierNiu(),
                recordInfo.supplierNit(),
                recordInfo.supplierName(),
                supplierType.getId()
            );
            
            // Creamos mediante el servicio y recuperamos la entidad real
            EntityDTOResponse response = entityService.createEntity(request);
            supplier = entityRepository.findById(response.id()) // o response.getId() según tu DTO
                .orElseThrow(() -> new RuntimeException("Fallo al recuperar la entidad del proveedor recién creado."));

            // Crear operario vinculado al proveedor
            createUserForSupplier(recordInfo, supplier);
        }

        MasterAgreementModel agreement = masterAgreementRepository.findByPayerIdAndSupplierId(payer.getId(), supplier.getId()).orElse(null);

        if (agreement == null) {
            log.info("Convenio no encontrado. Creando nuevo convenio marco...");
            
            PaymentPolicyCat paymentPolicy = paymentPolicyRepository.findByCode(recordInfo.paymentPolicy())
                .orElseThrow(() -> new RuntimeException("Política de pago no válida: " + recordInfo.paymentPolicy()));

            DisbursementPolicyCat disbursementPolicy = disbursementPolicyRepository.findByCode(recordInfo.disbursementDay())
                .orElseThrow(() -> new RuntimeException("Política de desembolso no válida: " + recordInfo.disbursementDay()));

            agreement = MasterAgreementModel.builder()
                .payer(payer)
                .supplier(supplier)
                .paymentPolicy(paymentPolicy)
                .disbursementPolicy(disbursementPolicy)
                .agreementType(com.davivienda.factoraje.domain.enums.AgreementTypeEnum.STANDARD) // Asume el tipo correspondiente
                .status(GeneralStatusEnum.ACTIVE)
                .build();

            agreement = masterAgreementRepository.save(agreement);
        }

        return agreement;
    }

    /**
     * Guarda el lote y los documentos validados evaluando el crédito GLOBAL del pagador.
     */
    @Transactional
    public UUID saveParsedBatchToDatabase(
            String originalFilename,
            List<InvoiceRecordDTO> parsedInvoices,
            Map<String, MasterAgreementModel> resolvedAgreements,
            UUID uploadedAndApprovedBy,
            AcceptanceAuditDTORequest auditRequest,
            UUID payerId) { 
            
        log.info("Phase II-A: Creando auditoría y lote principal");

        AcceptanceAuditDTOResponse savedAudit = acceptanceAuditService.createAcceptanceAudit(auditRequest);
        UUID acceptanceAuditId = savedAudit.id();

        String batchNumber = BatchNumberGeneratorUtil.generateBatchNumber(BatchTypeEnum.UPLOAD);
        String fileName = FileNamingUtil.generateBatchFileName(batchNumber, originalFilename);

        UploadBatchDTORequest uploadBatchDTORequest = new UploadBatchDTORequest(
                batchNumber, fileName, parsedInvoices.size(), UploadBatchStatusEnum.COMPLETED, uploadedAndApprovedBy);

        UploadBatchDTOResponse savedUploadBatch = uploadBatchService.createUploadBatch(uploadBatchDTORequest);
        UploadBatchModel batchProxy = entityManager.getReference(UploadBatchModel.class, savedUploadBatch.id());

        log.info("Phase II-B: Validando Facilidad de Crédito GLOBAL a nivel de Pagador");

        // 1. Sumamos TODAS las facturas del archivo, sin importar el proveedor
        java.math.BigDecimal totalBatchAmount = parsedInvoices.stream()
                .map(InvoiceRecordDTO::nominalAmount)
                .filter(java.util.Objects::nonNull)
                .reduce(java.math.BigDecimal.ZERO, java.math.BigDecimal::add);

        // 2. Buscamos la línea de crédito directamente en el Pagador
        CreditFacilityModel globalCreditFacility = creditFacilityRepository
                .findByPayerId(payerId) 
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró una línea de crédito activa asignada a este Pagador."));

        java.math.BigDecimal hardLimit = globalCreditFacility.getFacilityLimitAmount();
        java.math.BigDecimal thresholdPercentage = globalCreditFacility.getWarningThresholdPercentage() != null 
                ? globalCreditFacility.getWarningThresholdPercentage() 
                : java.math.BigDecimal.ONE; // Si no hay umbral, asumimos el 100% (1.0)
                
        java.math.BigDecimal thresholdLimit = hardLimit.multiply(thresholdPercentage); 
        java.math.BigDecimal currentUsedAmount = globalCreditFacility.getAmountInUse() != null
                ? globalCreditFacility.getAmountInUse() : java.math.BigDecimal.ZERO;

        java.math.BigDecimal newTotalUsed = currentUsedAmount.add(totalBatchAmount);

        // 3. Validación Global
        if (newTotalUsed.compareTo(thresholdLimit) > 0) {
            java.math.BigDecimal availableThresholdAmount = thresholdLimit.subtract(currentUsedAmount);
            log.error("Límite superado para el Pagador {}: Nuevo ({}) vs Límite ({})", payerId, newTotalUsed, thresholdLimit);
            throw new IllegalArgumentException(
                    String.format("Carga rechazada: El archivo totaliza $%s y supera el límite de crédito disponible del Pagador ($%s).",
                            totalBatchAmount, availableThresholdAmount.max(java.math.BigDecimal.ZERO)));
        }

        // 4. Actualizamos el cupo global del pagador
        globalCreditFacility.setAmountInUse(newTotalUsed);
        creditFacilityRepository.save(globalCreditFacility);

        log.info("Phase II-C: Iniciando guardado masivo en base de datos.");

        final int CHUNK_SIZE = 1000;
        List<DocumentModel> batchToSave = new ArrayList<>(CHUNK_SIZE);

        for (int i = 0; i < parsedInvoices.size(); i++) {
            InvoiceRecordDTO dto = parsedInvoices.get(i);
            
            // Asignamos el convenio específico que le corresponde a ESTA factura
            MasterAgreementModel masterAgreement = resolvedAgreements.get(dto.supplierNiu());
            Integer paymentDays = masterAgreement.getPaymentPolicy().getDaysCount();

            DocumentModel document = DocumentModel.builder()
                    .documentNumber(dto.documentNumber())
                    .issueDate(dto.issueDate())
                    .nominalAmount(dto.nominalAmount())
                    .generationCode(dto.generationCode())
                    .receivedStamp(dto.receivedStamp())
                    .controlNumber(dto.controlNumber())
                    .invoiceType(InvoiceTypeEnum.fromString(dto.invoiceType()))
                    .issuanceMethod(IssuanceMethodEnum.fromString(dto.issuanceMethod()))
                    .status(DocumentStatusEnum.APPROVED)
                    .masterAgreement(masterAgreement) // Relacionado al convenio exacto
                    .uploadBatch(batchProxy) // Todos comparten el mismo UploadBatch
                    .dueDate(dto.issueDate().plusDays(paymentDays != null ? paymentDays : 0))
                    .build();

            batchToSave.add(document);

            if ((i + 1) % CHUNK_SIZE == 0 || i == parsedInvoices.size() - 1) {
                documentRepository.saveAll(batchToSave);
                documentRepository.flush();

                documentLogService.createLogsForBatch(
                        batchToSave, DocumentStatusEnum.APPROVED, uploadedAndApprovedBy, acceptanceAuditId);

                entityManager.clear();
                batchToSave.clear();
            }
        }

        log.info("Lote {} multi-proveedor procesado y descontado del cupo global con éxito.", batchNumber);
        return savedUploadBatch.id();
    }

    /**
     * Crea un usuario operario asociado a un proveedor si no existe previamente.
     */
    private void createUserForSupplier(InvoiceRecordDTO recordInfo, EntityModel supplier) {
        log.info("Verificando existencia del usuario operario con DUI: {}", recordInfo.operatorDui());

        boolean userExists = userRepository.existsByDui(recordInfo.operatorDui());

        if (!userExists) {
            log.info("Creando nuevo usuario operario...");

            RoleCat operatorRole = roleCatRepository.findByName("SUPPLIER-OPERATOR")
                .orElseThrow(() -> new RuntimeException("El rol para el operario no está configurado en el catálogo."));

            String firstName = recordInfo.operatorFirstName() != null ? recordInfo.operatorFirstName() : "";
            if (recordInfo.operatorMiddleName() != null && !recordInfo.operatorMiddleName().trim().isEmpty()) {
                firstName += " " + recordInfo.operatorMiddleName().trim();
            }

            String lastName = recordInfo.operatorFirstLastName() != null ? recordInfo.operatorFirstLastName() : "";
            if (recordInfo.operatorSecondLastName() != null && !recordInfo.operatorSecondLastName().trim().isEmpty()) {
                lastName += " " + recordInfo.operatorSecondLastName().trim();
            }

            UserModel newOperator = UserModel.builder()
                    .dui(recordInfo.operatorDui())
                    .email(recordInfo.operatorEmail())
                    .firstName(firstName.trim())
                    .lastName(lastName.trim())
                    .status(GeneralStatusEnum.ACTIVE)
                    .entity(supplier) 
                    .role(operatorRole)
                    .build();

            userRepository.save(newOperator);
            log.info("Usuario operario creado exitosamente con ID: {}", newOperator.getId());
            
        } else {
            log.info("El usuario con DUI {} ya existe. Se omitirá su creación.", recordInfo.operatorDui());
        }
    }
}