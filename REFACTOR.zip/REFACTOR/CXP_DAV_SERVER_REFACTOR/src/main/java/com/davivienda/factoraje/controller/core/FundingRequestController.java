package com.davivienda.factoraje.controller.core;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.dto.funding_request.CalculateDTORequest;
import com.davivienda.factoraje.dto.funding_request.CalculateDTOResponse;
import com.davivienda.factoraje.dto.funding_request.SubmitFundingDTORequest;
import com.davivienda.factoraje.service.FundingRequestService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/funding-requests")
public class FundingRequestController {

    private final FundingRequestService fundingRequestService;

    @PostMapping("/calculate")
    public ResponseEntity<ApiResponse<CalculateDTOResponse>> calculateCost(
            @Valid @RequestBody CalculateDTORequest request) {

        // Mapeamos los UUID del DTO a instancias ligeras de DocumentModel
        // ya que el servicio se encarga de ir a buscar el resto de datos a la BD
        List<DocumentModel> documents = request.documentIds().stream()
                .map(id -> {
                    DocumentModel doc = new DocumentModel();
                    doc.setId(id);
                    return doc;
                })
                .collect(Collectors.toList());

        // Llamamos al servicio con los parámetros desempaquetados
        CalculateDTOResponse response = fundingRequestService.checkCost(
                request.masterAgreementId(),
                request.requestedById(),
                documents);

        return ResponseEntity.ok(ApiResponse.success(response, "Cálculo realizado con éxito"));
    }

    @PostMapping("/submit")
    public ResponseEntity<ApiResponse<CalculateDTOResponse>> submitFunding(
            @Valid @RequestBody SubmitFundingDTORequest request,
            @RequestHeader(value = "User-Agent", defaultValue = "Unknown") String userAgent) {

        // Llamamos al servicio pasando los datos del body y el User-Agent del header
        CalculateDTOResponse response = fundingRequestService.submitFundingRequest(
                request.masterAgreementId(),
                request.requestedById(),
                request.supplierId(),
                request.documentIds(),
                request.termVersionId(),
                userAgent);

        return ResponseEntity.ok(ApiResponse.success(response, "Solicitud de desembolso procesada con éxito"));
    }

}
