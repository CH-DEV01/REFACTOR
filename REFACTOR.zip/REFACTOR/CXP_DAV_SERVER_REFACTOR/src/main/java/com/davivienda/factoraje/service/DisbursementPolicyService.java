package com.davivienda.factoraje.service;

import java.util.List;

import com.davivienda.factoraje.dto.disbursement_policy.DisbursementPolicyDTOResponse;

public interface DisbursementPolicyService {

    List<DisbursementPolicyDTOResponse> getDisbursementPolicies();

}
