package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.entities.UserModel;

@Repository 
public interface UserRepository extends JpaRepository<UserModel, UUID>{

    boolean existsByIdAndEntityId(UUID userId, UUID entityId);

   @EntityGraph(attributePaths = {"role"})
    Optional<UserModel> findByDui(String dui);

    boolean existsByDui(String dui);

    boolean existsByEmail(String email);
    
}
