package com.davivienda.factoraje.service;

import java.util.List;
import java.util.UUID;

import com.davivienda.factoraje.dto.credit_facility.CreditFacilityDTORequest;
import com.davivienda.factoraje.dto.credit_facility.CreditFacilityDTOResponse;
import com.davivienda.factoraje.dto.credit_facility.RestoreCreditFacilityDTORequest;
import com.davivienda.factoraje.dto.credit_facility_history.CreditFacilityHistoryDTOResponse;

public interface CreditFacilityService {
    
    CreditFacilityDTOResponse createCreditFacility(CreditFacilityDTORequest request);

    CreditFacilityDTOResponse restoreCreditFacility(RestoreCreditFacilityDTORequest request, String executedBy);

    CreditFacilityDTOResponse findByPayerId(UUID payerId);

    List<CreditFacilityHistoryDTOResponse> getHistory(UUID creditFacilityId);
}
