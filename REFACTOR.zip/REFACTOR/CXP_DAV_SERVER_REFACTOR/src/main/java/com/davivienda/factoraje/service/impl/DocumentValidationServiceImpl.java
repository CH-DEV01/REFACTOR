package com.davivienda.factoraje.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.enums.InvoiceTypeEnum;
import com.davivienda.factoraje.domain.enums.IssuanceMethodEnum;
import com.davivienda.factoraje.dto.upload_batch.InvoiceRecordDTO;
import com.davivienda.factoraje.infrastructure.file_parser.excel.BatchValidationError;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.MasterAgreementRepository;
import com.davivienda.factoraje.service.DocumentValidationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentValidationServiceImpl implements DocumentValidationService {

    private final DocumentRepository documentRepository;
    private final MasterAgreementRepository masterAgreementRepository;

    private static final Pattern UUID_PATTERN = Pattern
            .compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    private static final int MAX_INVOICE_AGE_DAYS = 120;

    @Override
    public List<BatchValidationError> validateBatch(List<InvoiceRecordDTO> invoices, UUID masterAgreementId) {

        List<BatchValidationError> errors = new ArrayList<>();
        LocalDate today = LocalDate.now();

        // 1. VALIDACIONES MASIVAS (Prevención de Doble Fondeo contra Base de Datos)
        validateDoubleFundingPaperBulk(invoices, errors);
        validateDoubleFundingDteBulk(invoices, errors);

        Set<String> seenGenerationCodes = new HashSet<>();
        Set<String> seenPhysicalKeys = new HashSet<>();

        // 2. VALIDACIONES INDIVIDUALES POR REGISTRO (En Memoria)
        for (InvoiceRecordDTO invoice : invoices) {

            IssuanceMethodEnum method = IssuanceMethodEnum.fromString(invoice.issuanceMethod());
            validateRequiredText(invoice.issuanceMethod(), "Forma de emision", 30, invoice.rowIndex(), errors);

            if (method == IssuanceMethodEnum.PAPER) {
                if (invoice.documentNumber() == null || invoice.documentNumber().isBlank()) {
                    errors.add(new BatchValidationError(invoice.rowIndex(), "Numero de documento",
                            "El número de documento es obligatorio para facturas físicas (PAPER)."));
                } else if (invoice.documentNumber().length() > 255) {
                    errors.add(new BatchValidationError(invoice.rowIndex(), "Numero de documento",
                            "El número de documento físico supera el máximo de 255 caracteres."));
                }
            }

            validateRequiredText(invoice.supplierNiu(), "NIU del proveedor", 25, invoice.rowIndex(), errors);
            validateRequiredText(invoice.invoiceType(), "Tipo de documento", 30, invoice.rowIndex(), errors);

            // Validaciones para Creación de Entidades (Proveedor)
            validateRequiredText(invoice.supplierNit(), "NIT del proveedor", 50, invoice.rowIndex(), errors);
            validateRequiredText(invoice.supplierName(), "Nombre del proveedor", 255, invoice.rowIndex(), errors);
            validateRequiredText(invoice.paymentPolicy(), "Politica de pago", 50, invoice.rowIndex(), errors);
            validateRequiredText(invoice.disbursementDay(), "Dia de desembolso", 50, invoice.rowIndex(), errors);

            // Validaciones para Creación de Entidades (Operario)
            validateRequiredText(invoice.operatorDui(), "DUI del operario", 20, invoice.rowIndex(), errors);
            validateRequiredText(invoice.operatorEmail(), "E-mail del operario", 100, invoice.rowIndex(), errors);
            validateRequiredText(invoice.operatorFirstName(), "Primer nombre del operario", 100, invoice.rowIndex(), errors);
            validateRequiredText(invoice.operatorFirstLastName(), "Primer apellido del operario", 100, invoice.rowIndex(), errors);

            validateDteFormat(invoice, errors);

            if (invoice.nominalAmount() == null || invoice.nominalAmount().compareTo(BigDecimal.ZERO) <= 0) {
                errors.add(new BatchValidationError(invoice.rowIndex(), "Monto",
                        "El monto nominal de la factura debe ser mayor a cero."));
            }

            if (invoice.issueDate() != null) {
                if (invoice.issueDate().isAfter(today)) {
                    errors.add(new BatchValidationError(invoice.rowIndex(), "Fecha de emision",
                            "La fecha de emisión no puede ser futura."));
                } else if (invoice.issueDate().isBefore(today.minusDays(MAX_INVOICE_AGE_DAYS))) {
                    errors.add(new BatchValidationError(invoice.rowIndex(), "Fecha de emision",
                            "La factura supera la antigüedad máxima permitida de " + MAX_INVOICE_AGE_DAYS + " días."));
                }
            } else {
                errors.add(new BatchValidationError(invoice.rowIndex(), "Fecha de emision",
                        "La fecha de emisión es obligatoria."));
            }

            if (method == IssuanceMethodEnum.DIGITAL && invoice.generationCode() != null) {
                if (!seenGenerationCodes.add(invoice.generationCode())) {
                    errors.add(new BatchValidationError(invoice.rowIndex(), "Codigo de generacion",
                            "Este DTE viene duplicado dentro de este mismo archivo Excel."));
                }
            } else if (method == IssuanceMethodEnum.PAPER && invoice.supplierNiu() != null
                    && invoice.documentNumber() != null) {
                String physicalKey = invoice.supplierNiu() + "-" + invoice.documentNumber();
                if (!seenPhysicalKeys.add(physicalKey)) {
                    errors.add(new BatchValidationError(invoice.rowIndex(), "Numero de documento",
                            "Esta factura física viene duplicada dentro de este mismo archivo Excel para este proveedor."));
                }
            }
        }

        return errors;
    }

    private void validateRequiredText(String value, String columnName, int maxLength, int rowIndex,
            List<BatchValidationError> errors) {
        if (value == null || value.isBlank()) {
            errors.add(new BatchValidationError(rowIndex, columnName, "El campo es obligatorio y no puede estar vacío."));
        } else if (value.length() > maxLength) {
            errors.add(new BatchValidationError(rowIndex, columnName,
                    String.format("El campo supera la longitud máxima permitida de %d caracteres. Valor recibido: %d caracteres.",
                            maxLength, value.length())));
        }
    }

    private void validateDteFormat(InvoiceRecordDTO dto, List<BatchValidationError> errors) {

        InvoiceTypeEnum tipoDocEnum = InvoiceTypeEnum.fromString(dto.invoiceType());
        if (tipoDocEnum == null) {
            errors.add(new BatchValidationError(dto.rowIndex(), "Tipo de documento",
                    "Valor no permitido. Debe utilizar el estándar exacto: 'CCF' o 'FCI'. Valor recibido: " + dto.invoiceType()));
        }

        IssuanceMethodEnum formaEmisionEnum = IssuanceMethodEnum.fromString(dto.issuanceMethod());
        if (formaEmisionEnum == null) return;

        if (formaEmisionEnum == IssuanceMethodEnum.DIGITAL) {
            if (dto.generationCode() == null || !UUID_PATTERN.matcher(dto.generationCode()).matches()) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Codigo de generacion",
                        "Los documentos DIGITALES deben contener un código de generación UUID válido de exactamente 36 caracteres."));
            }
            if (dto.receivedStamp() == null || dto.receivedStamp().trim().isEmpty()) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Sello de recepcion",
                        "Los documentos DIGITALES deben contener obligatoriamente el sello de recepción de Hacienda."));
            } else if (dto.receivedStamp().trim().length() != 40) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Sello de recepcion",
                        String.format("El sello de recepción debe tener exactamente 40 caracteres. Valor recibido: %d.",
                                dto.receivedStamp().trim().length())));
            }
            if (dto.controlNumber() == null || !dto.controlNumber().startsWith("DTE-")) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Numero de control",
                        "El número de control debe iniciar con el prefijo 'DTE-'."));
            } else if (dto.controlNumber().trim().length() != 31) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Numero de control",
                        String.format("El número de control debe tener exactamente 31 caracteres. Valor recibido: %d.",
                                dto.controlNumber().trim().length())));
            }
        } else if (formaEmisionEnum == IssuanceMethodEnum.PAPER) {
            if (dto.generationCode() != null && !dto.generationCode().isBlank()) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Codigo de generacion",
                        "Los documentos en papel (PAPER) no deben contener código de generación."));
            }
            if (dto.receivedStamp() != null && !dto.receivedStamp().isBlank()) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Sello de recepcion",
                        "Los documentos en papel (PAPER) no deben contener sello de recepción."));
            }
            if (dto.controlNumber() != null && !dto.controlNumber().isBlank()) {
                errors.add(new BatchValidationError(dto.rowIndex(), "Numero de control",
                        "Los documentos en papel (PAPER) no deben contener número de control DTE."));
            }
        }
    }

    private void validateDoubleFundingDteBulk(List<InvoiceRecordDTO> invoices, List<BatchValidationError> errors) {
        List<String> generationCodes = invoices.stream()
                .filter(inv -> IssuanceMethodEnum.fromString(inv.issuanceMethod()) == IssuanceMethodEnum.DIGITAL)
                .map(InvoiceRecordDTO::generationCode)
                .filter(code -> code != null && !code.isBlank())
                .toList();

        if (generationCodes.isEmpty()) return;
        Set<String> existingCodes = documentRepository.findExistingGenerationCodes(generationCodes);

        for (InvoiceRecordDTO invoice : invoices) {
            if (existingCodes.contains(invoice.generationCode())) {
                errors.add(new BatchValidationError(invoice.rowIndex(), "Codigo de generacion",
                        "Riesgo de Doble Fondeo: El documento electrónico (DTE) ya se encuentra financiado o registrado en la plataforma."));
            }
        }
    }

    private void validateDoubleFundingPaperBulk(List<InvoiceRecordDTO> invoices, List<BatchValidationError> errors) {
        List<InvoiceRecordDTO> paperInvoices = invoices.stream()
                .filter(inv -> IssuanceMethodEnum.fromString(inv.issuanceMethod()) == IssuanceMethodEnum.PAPER)
                .filter(inv -> inv.supplierNiu() != null && inv.issueDate() != null && inv.documentNumber() != null)
                .toList();

        if (paperInvoices.isEmpty()) return;

        var groupedInvoices = paperInvoices.stream()
                .collect(Collectors.groupingBy(
                        InvoiceRecordDTO::supplierNiu,
                        Collectors.groupingBy(inv -> inv.issueDate().getYear())));

        groupedInvoices.forEach((niu, yearMap) -> {
            yearMap.forEach((year, invoicesInGroup) -> {
                List<String> documentNumbers = invoicesInGroup.stream()
                        .map(InvoiceRecordDTO::documentNumber)
                        .toList();

                Set<String> existingNumbers = documentRepository.findExistingPhysicalDocuments(niu, documentNumbers, year);

                for (InvoiceRecordDTO invoice : invoicesInGroup) {
                    if (existingNumbers.contains(invoice.documentNumber())) {
                        errors.add(new BatchValidationError(invoice.rowIndex(), "Numero de documento",
                                String.format("Riesgo de Doble Fondeo: El documento físico '%s' del proveedor (NIU: %s) para el año %d ya se encuentra registrado en el sistema.",
                                        invoice.documentNumber(), niu, year)));
                    }
                }
            });
        });
    }
}