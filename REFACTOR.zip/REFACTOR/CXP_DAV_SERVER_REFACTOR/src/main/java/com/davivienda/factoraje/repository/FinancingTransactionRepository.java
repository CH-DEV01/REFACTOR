package com.davivienda.factoraje.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.davivienda.factoraje.domain.entities.DisbursementBatchModel;
import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.domain.entities.FinancingTransactionModel;

public interface FinancingTransactionRepository extends JpaRepository<FinancingTransactionModel, UUID> {

    List<FinancingTransactionModel> findByDocumentIn(List<DocumentModel> documents);

    List<FinancingTransactionModel> findByDisbursementBatch(DisbursementBatchModel disbursementBatchModel);
    
}
