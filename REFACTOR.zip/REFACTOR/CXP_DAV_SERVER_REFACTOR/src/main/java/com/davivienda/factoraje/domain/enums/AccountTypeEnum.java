package com.davivienda.factoraje.domain.enums;

public enum AccountTypeEnum {

    SAVINGS,
    CHECKING
   
}
