package com.davivienda.factoraje.dto.credit_facility;

import java.math.BigDecimal;
import java.util.UUID;

import com.davivienda.factoraje.domain.entities.CreditFacilityModel;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;

public record CreditFacilityDTOResponse(

        UUID id,
        GeneralStatusEnum status,
        BigDecimal facilityLimitAmount,
        BigDecimal amountInUse,
        BigDecimal availableAmount,
        UUID payerId

) {

    public static CreditFacilityDTOResponse fromEntity(CreditFacilityModel model) {
        return new CreditFacilityDTOResponse(
                model.getId(),
                model.getStatus(),
                model.getFacilityLimitAmount(),
                model.getAmountInUse(),
                model.getAvailableAmount(),
                model.getPayer().getId()
        );
    }

}
