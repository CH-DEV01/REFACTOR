package com.davivienda.factoraje.infrastructure.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

import java.util.List;
import java.util.stream.Collectors;

import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.infrastructure.file_parser.excel.BatchValidationError;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.TypeMismatchException;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

        @ExceptionHandler(DocumentNotAvailableException.class)
        public ResponseEntity<ApiResponse<Void>> handleDocumentNotAvailable(DocumentNotAvailableException ex) {

                log.warn("Conflicto al procesar documentos: {}", ex.getMessage());

                return ResponseEntity
                                .status(HttpStatus.CONFLICT)
                                .body(ApiResponse.error(ex.getMessage()));
        }

        @ExceptionHandler({ MethodArgumentTypeMismatchException.class, TypeMismatchException.class })
        public ResponseEntity<ApiResponse<Void>> handleTypeMismatchException(Exception ex) {

                String paramName = "desconocido";

                if (ex instanceof MethodArgumentTypeMismatchException methodEx) {
                        paramName = methodEx.getName();
                } else if (ex instanceof TypeMismatchException typeEx) {
                        paramName = typeEx.getPropertyName() != null ? typeEx.getPropertyName() : "desconocido";
                }

                String message = String.format(
                                "El parámetro '%s' tiene un formato inválido. Verifique que el valor enviado sea correcto (ej. un UUID válido de 36 caracteres).",
                                paramName);

                return ResponseEntity
                                .status(HttpStatus.BAD_REQUEST) // 400 Bad Request
                                .body(ApiResponse.error(message));
        }

        /**
         * Captura cuando el cliente solicita o interactúa con un recurso que no existe.
         */
        @ExceptionHandler(ResourceNotFoundException.class)
        public ResponseEntity<ApiResponse<Void>> handleResourceNotFoundException(ResourceNotFoundException ex) {
                return ResponseEntity
                                .status(HttpStatus.NOT_FOUND) // 404
                                .body(ApiResponse.error(ex.getMessage()));
        }

        /**
         * Captura cuando se intenta crear un recurso que ya existe en el sistema (Ej:
         * duplicados).
         */
        @ExceptionHandler(ResourceAlreadyExistsException.class)
        public ResponseEntity<ApiResponse<Void>> handleResourceAlreadyExistsException(
                        ResourceAlreadyExistsException ex) {
                return ResponseEntity
                                .status(HttpStatus.CONFLICT) // 409
                                .body(ApiResponse.error(ex.getMessage()));
        }

        /**
         * Captura intentos de acceso a recursos para los cuales el usuario no tiene
         * permisos.
         */
        @ExceptionHandler(UnauthorizedAccessException.class)
        public ResponseEntity<ApiResponse<Void>> handleUnauthorizedAccessException(UnauthorizedAccessException ex) {
                return ResponseEntity
                                .status(HttpStatus.FORBIDDEN) // 403 (o 401 si representa falta de autenticación)
                                .body(ApiResponse.error(ex.getMessage()));
        }

        /**
         * Captura inconsistencias lógicas específicas del ciclo de vida de un lote.
         */
        @ExceptionHandler(InvalidBatchException.class)
        public ResponseEntity<ApiResponse<Void>> handleInvalidBatchException(InvalidBatchException ex) {
                return ResponseEntity
                                .status(HttpStatus.UNPROCESSABLE_ENTITY) // 422 (o 400 dependiendo de tu preferencia)
                                .body(ApiResponse.error(ex.getMessage()));
        }

        /**
         * Captura cuando no se envía un parámetro simple (@RequestParam) en la
         * petición.
         */
        @ExceptionHandler(MissingServletRequestParameterException.class)
        public ResponseEntity<ApiResponse<Void>> handleMissingParams(MissingServletRequestParameterException ex) {
                String message = String.format("El parámetro obligatorio '%s' no fue incluido en la petición.",
                                ex.getParameterName());
                return ResponseEntity
                                .status(HttpStatus.BAD_REQUEST)
                                .body(ApiResponse.error(message));
        }

        /**
         * Captura cuando no se envía una parte obligatoria de un form-data (como el
         * 'file').
         */
        @ExceptionHandler(MissingServletRequestPartException.class)
        public ResponseEntity<ApiResponse<Void>> handleMissingRequestPart(MissingServletRequestPartException ex) {
                String message = String.format("El archivo/parámetro obligatorio '%s' no fue incluido en la petición.",
                                ex.getRequestPartName());
                return ResponseEntity
                                .status(HttpStatus.BAD_REQUEST)
                                .body(ApiResponse.error(message));
        }

        /**
         * Captura peticiones multipart malformadas o faltantes.
         */
        @ExceptionHandler(MultipartException.class)
        public ResponseEntity<ApiResponse<Void>> handleMultipartException(MultipartException ex) {
                return ResponseEntity
                                .status(HttpStatus.BAD_REQUEST)
                                .body(ApiResponse.error(
                                                "La petición debe ser de tipo 'multipart/form-data' y contener el archivo obligatorio."));
        }

        /**
         * Captura errores de archivo vacío o formato no permitido.
         */
        @ExceptionHandler(InvalidFileException.class)
        public ResponseEntity<ApiResponse<Void>> handleInvalidFileException(InvalidFileException ex) {
                return ResponseEntity
                                .status(HttpStatus.BAD_REQUEST)
                                .body(ApiResponse.error(ex.getMessage()));
        }

        /**
         * Captura fallos de Bean Validation (@NotNull) en los parámetros del Controller
         * activados por @Validated.
         */
        @ExceptionHandler(ConstraintViolationException.class)
        public ResponseEntity<ApiResponse<Void>> handleConstraintViolation(ConstraintViolationException ex) {
                String errorMessage = ex.getConstraintViolations().stream()
                                .map(ConstraintViolation::getMessage)
                                .collect(Collectors.joining("; "));
                return ResponseEntity
                                .status(HttpStatus.BAD_REQUEST)
                                .body(ApiResponse.error(errorMessage));
        }

        /**
         * Captura los errores de validación (formato y negocio) del Excel
         * y retorna la lista exacta para que el Frontend dibuje la tabla.
         */
        @ExceptionHandler(BatchValidationException.class)
        public ResponseEntity<ApiResponse<List<BatchValidationError>>> handleBatchValidationException(
                        BatchValidationException ex) {

                log.warn("Se rechazó un archivo por errores de validación. Cantidad de errores: {}",
                                ex.getValidationErrors().size());

                ApiResponse<List<BatchValidationError>> response = ApiResponse.error(
                                ex.getMessage(),
                                ex.getValidationErrors());

                return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(response);
        }

        /**
         * Captura errores de seguridad de archivo o falta de columnas estructurales
         */
        @ExceptionHandler(IllegalArgumentException.class)
        public ResponseEntity<ApiResponse<Void>> handleIllegalArgumentException(IllegalArgumentException ex) {

                log.warn("Argumento inválido / Error estructural: {}", ex.getMessage());

                ApiResponse<Void> response = ApiResponse.error(ex.getMessage());

                return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(response);
        }

        /**
         * Captura cualquier otro error técnico inesperado (Fallback)
         */
        @ExceptionHandler(Exception.class)
        public ResponseEntity<ApiResponse<Void>> handleGeneralException(Exception ex) {

                log.error("Error técnico inesperado: ", ex);

                ApiResponse<Void> response = ApiResponse
                                .error("Ocurrió un error interno en el servidor. Contacte a soporte.");

                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
}