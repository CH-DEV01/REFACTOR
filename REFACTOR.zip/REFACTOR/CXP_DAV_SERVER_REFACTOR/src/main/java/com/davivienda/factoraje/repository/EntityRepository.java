package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.dto.entity.EntityDTOResponse;

import jakarta.persistence.LockModeType;

@Repository
public interface EntityRepository extends JpaRepository<EntityModel, UUID> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT e FROM EntityModel e WHERE e.id = :id")
    Optional<EntityModel> findByIdForUpdate(@Param("id") UUID id);

    Boolean existsByNiu(String niu);

    Boolean existsByNit(String nit);

    Boolean existsByName(String name);

    @Query("SELECT e FROM EntityModel e WHERE e.entityType.code = :typeCode")
    Page<EntityModel> findAllByEntityTypeCode(
            @Param("typeCode") String typeCode, 
            Pageable pageable
    );

    Optional<EntityModel> findByNiu(String niu);


}
