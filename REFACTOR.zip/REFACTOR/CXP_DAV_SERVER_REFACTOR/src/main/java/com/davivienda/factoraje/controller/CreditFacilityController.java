package com.davivienda.factoraje.controller;

import java.net.URI;
import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.dto.credit_facility.CreditFacilityDTORequest;
import com.davivienda.factoraje.dto.credit_facility.CreditFacilityDTOResponse;
import com.davivienda.factoraje.dto.credit_facility.RestoreCreditFacilityDTORequest;
import com.davivienda.factoraje.dto.credit_facility_history.CreditFacilityHistoryDTOResponse;
import com.davivienda.factoraje.service.CreditFacilityService;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/credit-facilities")
public class CreditFacilityController {

    private final CreditFacilityService creditFacilityService;

    public CreditFacilityController(CreditFacilityService creditFacilityService) {
        this.creditFacilityService = creditFacilityService;
        log.info("CreditFacility controller initialized");
    }

    // CREATE
    @PostMapping
    public ResponseEntity<ApiResponse<CreditFacilityDTOResponse>> create(
            @Valid @RequestBody CreditFacilityDTORequest request) {

        log.info("Initiating the creation of a new credit facility");

        CreditFacilityDTOResponse response = creditFacilityService.createCreditFacility(request);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(response.id())
                .toUri();

        return ResponseEntity.created(location)
                .body(ApiResponse.success(response, "Credit facility successfully created"));

    }

    @GetMapping("/payer/{payerId}")
    public ResponseEntity<ApiResponse<CreditFacilityDTOResponse>> getByPayer(@PathVariable UUID payerId) {

        log.info("Consultando cupo de crédito para el pagador con ID: {}", payerId);
        CreditFacilityDTOResponse response = creditFacilityService.findByPayerId(payerId);

        return ResponseEntity.ok(ApiResponse.success(response, "Cupo de crédito consultado exitosamente."));
    }

    @PostMapping("/restore")
    public ResponseEntity<ApiResponse<CreditFacilityDTOResponse>> restoreCreditFacility(
            @Valid @RequestBody RestoreCreditFacilityDTORequest request,
            org.springframework.security.core.Authentication authentication) {

        String loggedUser = authentication.getName();

        CreditFacilityDTOResponse updatedFacility = creditFacilityService.restoreCreditFacility(request, loggedUser);

        return ResponseEntity.ok(ApiResponse.success(
                updatedFacility,
                "Abono aplicado y cupo restaurado exitosamente."));
    }

    @GetMapping("/history/{creditFacilityId}")
    public ResponseEntity<ApiResponse<List<CreditFacilityHistoryDTOResponse>>> getHistory(
            @PathVariable UUID creditFacilityId) {

        log.info("Consultando historial de abonos para la facilidad de crédito con ID: {}", creditFacilityId);

        List<CreditFacilityHistoryDTOResponse> history = creditFacilityService.getHistory(creditFacilityId);

        return ResponseEntity.ok(ApiResponse.success(
                history,
                "Historial de abonos consultado exitosamente."));
    }

}
