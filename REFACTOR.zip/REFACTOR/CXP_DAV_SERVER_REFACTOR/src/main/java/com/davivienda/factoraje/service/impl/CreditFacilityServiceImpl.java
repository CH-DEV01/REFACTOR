package com.davivienda.factoraje.service.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.entities.CreditFacilityHistoryModel;
import com.davivienda.factoraje.domain.entities.CreditFacilityModel;
import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.dto.credit_facility.CreditFacilityDTORequest;
import com.davivienda.factoraje.dto.credit_facility.CreditFacilityDTOResponse;
import com.davivienda.factoraje.dto.credit_facility.RestoreCreditFacilityDTORequest;
import com.davivienda.factoraje.dto.credit_facility_history.CreditFacilityHistoryDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.CreditFacilityHistoryRepository;
import com.davivienda.factoraje.repository.CreditFacilityRepository;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.CreditFacilityService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CreditFacilityServiceImpl implements CreditFacilityService {

        private final CreditFacilityRepository creditFacilityRepository;
        private final CreditFacilityHistoryRepository creditFacilityHistoryRepository;
        private final EntityRepository entityRepository;
        private final UserRepository userRepository;

        public CreditFacilityServiceImpl(
                        CreditFacilityRepository creditFacilityRepository,
                        EntityRepository entityRepository,
                        CreditFacilityHistoryRepository creditFacilityHistoryRepository,
                        UserRepository userRepository) {

                this.creditFacilityRepository = creditFacilityRepository;
                this.entityRepository = entityRepository;
                this.creditFacilityHistoryRepository = creditFacilityHistoryRepository;
                this.userRepository = userRepository;
                log.info("CreditFacility service initialized");
        }

        private void validateUniqueness(CreditFacilityDTORequest entity) {

        }

        @Override
        @Transactional
        public CreditFacilityDTOResponse createCreditFacility(CreditFacilityDTORequest request) {

                log.info("Starting the creation of a new credit facility");

                validateUniqueness(request);

                EntityModel payer = entityRepository.findById(request.payerId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "Payer not found with ID: " + request.payerId()));

                CreditFacilityModel creditFacilityModel = CreditFacilityModel.builder()
                                .facilityLimitAmount(request.facilityLimitAmount())
                                .amountInUse(request.amountInUse())
                                .status(GeneralStatusEnum.ACTIVE)
                                .payer(payer)
                                .build();

                try {
                        CreditFacilityModel savedCreditFacility = creditFacilityRepository.save(creditFacilityModel);
                        log.info("Credit facility created successfully with ID: {}", savedCreditFacility.getId());
                        return CreditFacilityDTOResponse.fromEntity(savedCreditFacility);

                } catch (DataIntegrityViolationException e) {
                        // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
                        // carrera)
                        log.error("Integrity violation when attempting to save the credit facility. Possible race condition.",
                                        e);
                        throw new ResourceAlreadyExistsException(
                                        "Integrity violation when attempting to save the credit facility. Possible race condition.");
                }

        }

        @Override
        @Transactional(readOnly = true)
        public CreditFacilityDTOResponse findByPayerId(UUID payerId) {

                CreditFacilityModel creditFacility = creditFacilityRepository.findByPayerId(payerId)
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "No se encontró el cupo de crédito para el pagador con ID: "
                                                                + payerId));

                return CreditFacilityDTOResponse.fromEntity(creditFacility);
        }

        @Override
        @Transactional
        public CreditFacilityDTOResponse restoreCreditFacility(RestoreCreditFacilityDTORequest request,
                        String executedBy) {

                UserModel user = userRepository.findByDui(executedBy)
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "No se encontró el usuario especificado."));

                // 1. Buscamos la facilidad de crédito
                CreditFacilityModel facility = creditFacilityRepository.findById(request.creditFacilityId())
                                .orElseThrow(() -> new ResourceNotFoundException(
                                                "No se encontró el cupo de crédito especificado."));

                // 2. Extraemos el consumo actual (protegido contra nulos por el
                // @Builder.Default de tu modelo)
                BigDecimal currentUsed = facility.getAmountInUse();

                // 3. Calculamos el nuevo consumo
                BigDecimal newUsedAmount = currentUsed.subtract(request.amount());

                // 4. Regla de Negocio: No se puede dejar el consumo en negativo
                if (newUsedAmount.compareTo(BigDecimal.ZERO) < 0) {
                        throw new IllegalArgumentException(String.format(
                                        "El monto a abonar ($%s) supera el consumo actual de la línea ($%s).",
                                        request.amount(), currentUsed));
                }

                // 5. Actualizamos solo el monto en uso
                facility.setAmountInUse(newUsedAmount);

                // 6. Guardamos los cambios
                creditFacilityRepository.save(facility);

                CreditFacilityHistoryModel creditFacilityHistoryModel = CreditFacilityHistoryModel.builder()
                                .amount(request.amount())
                                .creditFacility(facility)
                                .executedBy(user)
                                .payer(facility.getPayer())
                                .referenceNumber(request.reference())
                                .repaymentType(request.type())
                                .build();
                creditFacilityHistoryRepository.save(creditFacilityHistoryModel);

                // 7. Retornamos la respuesta actualizada
                return CreditFacilityDTOResponse.fromEntity(facility);
        }

        @Transactional(readOnly = true)
        public List<CreditFacilityHistoryDTOResponse> getHistory(UUID creditFacilityId) {

                // Al usar un List en el repositorio, esto ya no fallará cuando haya 2 o más
                // abonos
                List<CreditFacilityHistoryModel> historyModels = creditFacilityHistoryRepository
                                .findByCreditFacilityIdOrderByCreatedAtDesc(creditFacilityId);

                // Transformamos la lista de entidades a lista de DTOs
                return historyModels.stream()
                                .map(CreditFacilityHistoryDTOResponse::fromEntity)
                                .toList();
        }

}
