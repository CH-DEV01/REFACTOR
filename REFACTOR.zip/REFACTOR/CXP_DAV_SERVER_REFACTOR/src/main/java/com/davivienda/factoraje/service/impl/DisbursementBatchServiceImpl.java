package com.davivienda.factoraje.service.impl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.entities.DisbursementBatchModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.DisbursementBatchStatusEnum;
import com.davivienda.factoraje.dto.disbursement_batch.DisbursementBatchDTORequest;
import com.davivienda.factoraje.dto.disbursement_batch.DisbursementeBatchDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.DisbursementBatchRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.DisbursementBatchService;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DisbursementBatchServiceImpl implements DisbursementBatchService {

    private final DisbursementBatchRepository disbursementBatchRepository;
    private final UserRepository userRepository;

    public DisbursementBatchServiceImpl(
            DisbursementBatchRepository disbursementBatchRepository,
            UserRepository userRepository) {
        this.disbursementBatchRepository = disbursementBatchRepository;
        this.userRepository = userRepository;
        log.info("DisbursementBatchService initialized");

    }

    private void validateUniqueness(DisbursementBatchDTORequest request) {

        Boolean existsByBatchNumber = disbursementBatchRepository.existsByBatchNumber(request.batchNumber());

        Boolean existsByOutputFileName = disbursementBatchRepository.existsByOutputFileName((request.outputFileName()));

        if (existsByBatchNumber) {
            throw new ResourceAlreadyExistsException("Operation rejected: An entity with the provided batch number already exists.");
        }

        if (existsByOutputFileName) {
            throw new ResourceAlreadyExistsException("Operation rejected: An entity with the provided output file name already exists.");
        }       
    }

    // CREATE
    @Override
    @Transactional
    public DisbursementeBatchDTOResponse createDisbursementBatch(DisbursementBatchDTORequest request) {

        log.info("Starting the creation of a new disbursement batch");

        validateUniqueness(request);

        UserModel createdBy = userRepository.findById(request.createdBy().getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found with ID: " + request.createdBy().getId()));

        DisbursementBatchModel disbursementBatchModel = DisbursementBatchModel.builder()
                .batchNumber(request.batchNumber())
                .outputFileName(request.outputFileName())
                .transactionCount(request.transactionCount())
                .totalAmount(request.totalAmount())
                .totalCommission(request.totalCommission())
                .totalInterest(request.totalInterest())
                .status(DisbursementBatchStatusEnum.PROCESSING)
                .createdBy(createdBy)
                .build();

        try {
            DisbursementBatchModel savedDisbursementBatchModel = disbursementBatchRepository.save(disbursementBatchModel);
            log.info("Disbursement batch created successfully with ID: {}", savedDisbursementBatchModel.getId());
            return DisbursementeBatchDTOResponse.fromEntity(savedDisbursementBatchModel);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the disbursement batch. Possible race condition.", e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the disbursement batch. Possible race condition.");
        }

    }

}
