package com.davivienda.factoraje.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.entities.CreditFacilityModel;
import com.davivienda.factoraje.domain.entities.DisbursementBatchModel;
import com.davivienda.factoraje.domain.entities.DocumentLogModel;
import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.domain.entities.FinancingTransactionModel;
import com.davivienda.factoraje.domain.entities.MasterAgreementModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.domain.enums.BatchTypeEnum;
import com.davivienda.factoraje.domain.enums.DisbursementBatchStatusEnum;
import com.davivienda.factoraje.domain.enums.DocumentStatusEnum;
import com.davivienda.factoraje.dto.report.PdfReportConfig;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.infrastructure.util.BatchNumberGeneratorUtil;
import com.davivienda.factoraje.infrastructure.util.FileNamingUtil;
import com.davivienda.factoraje.repository.CreditFacilityRepository;
import com.davivienda.factoraje.repository.DisbursementBatchRepository;
import com.davivienda.factoraje.repository.DocumentLogRepository;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.FinancingTransactionRepository;
import com.davivienda.factoraje.repository.MasterAgreementRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.GenericPdfService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class SettleFundingRequestServiceImpl {

    private final UserRepository userRepository;
    private final DocumentRepository documentRepository;
    private final FinancingTransactionRepository financingTransactionRepository;
    private final DisbursementBatchRepository disbursementBatchRepository;
    private final DocumentLogRepository documentLogRepository;
    private final GenericPdfService genericPdfService;
    private final MasterAgreementRepository masterAgreementRepository;
    private final CreditFacilityRepository creditFacilityRepository;

    @Transactional
    public List<byte[]> generateDisbursementBatch(UUID createdById, String originalFileName, UUID payerId) {

        UserModel createdBy = userRepository.findById(createdById)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));

        String batchNumber = BatchNumberGeneratorUtil.generateBatchNumber(BatchTypeEnum.DISBURSEMENT);
        String fileName = FileNamingUtil.generateBatchFileName(batchNumber, originalFileName);

        DisbursementBatchModel disbursementBatchModel = DisbursementBatchModel.builder()
                .batchNumber(batchNumber)
                .outputFileName(fileName)
                .transactionCount(0)
                .totalAmount(BigDecimal.ZERO)
                .totalCommission(BigDecimal.ZERO)
                .totalInterest(BigDecimal.ZERO)
                .status(DisbursementBatchStatusEnum.CREATED) // Asumiendo que existe en tu builder
                .createdBy(createdBy)
                .build();

        disbursementBatchModel = disbursementBatchRepository.save(disbursementBatchModel);

        BigDecimal totalInterestAmount = BigDecimal.ZERO;
        BigDecimal totalCommissionAmount = BigDecimal.ZERO;
        BigDecimal totalAmountToBeDisbursed = BigDecimal.ZERO;
        Integer totalRecords = 0;

        boolean continueProcess = true;

        while (continueProcess) {
            List<DocumentModel> bloque = documentRepository
                    .findTop500ByStatusAndMasterAgreement_Payer_Id(DocumentStatusEnum.REQUESTED_FOR_FINANCING, payerId);

            if (bloque.isEmpty()) {
                continueProcess = false;
            } else {
                totalRecords += bloque.size();
                List<FinancingTransactionModel> transactions = financingTransactionRepository
                        .findByDocumentIn(bloque);

                for (FinancingTransactionModel tx : transactions) {
                    totalInterestAmount = totalInterestAmount.add(tx.getInterestAmount());
                    totalCommissionAmount = totalCommissionAmount.add(tx.getCommissionAmount());
                    totalAmountToBeDisbursed = totalAmountToBeDisbursed.add(tx.getAmountToBeDisbursed());

                    // 2. Asignar el lote
                    tx.setDisbursementBatch(disbursementBatchModel);
                }

                List<DocumentLogModel> documentLogs = new java.util.ArrayList<>();

                for (DocumentModel doc : bloque) {

                    DocumentLogModel logEntry = DocumentLogModel.builder()
                            .document(doc)
                            .status(DocumentStatusEnum.REQUESTED_FOR_DISBURSEMENT)
                            .user(createdBy)
                            .build();

                    documentLogs.add(logEntry);

                    // 2. Cambiar el estado del documento
                    doc.setStatus(DocumentStatusEnum.REQUESTED_FOR_DISBURSEMENT);
                }

                // 3. Persistir bloque
                documentRepository.saveAll(bloque);
                financingTransactionRepository.saveAll(transactions);
                documentLogRepository.saveAll(documentLogs);

                // 4. Liberar memoria de Hibernate para evitar OutOfMemory en lotes grandes
                documentRepository.flush();
                financingTransactionRepository.flush();
                documentLogRepository.flush();

                log.info("Se procesó un lote de {} documentos y sus transacciones.", bloque.size());
            }
        }

        // 5. Actualizar totales finales
        disbursementBatchModel.setTransactionCount(totalRecords);
        disbursementBatchModel.setTotalAmount(totalAmountToBeDisbursed);
        disbursementBatchModel.setTotalCommission(totalCommissionAmount);
        disbursementBatchModel.setTotalInterest(totalInterestAmount);

        disbursementBatchRepository.save(disbursementBatchModel);

        log.info("Proceso de desembolso finalizado. Total registros: {}, Total a desembolsar: {}",
                totalRecords, totalAmountToBeDisbursed);

        return buildAndGenerateGroupedPdfs(disbursementBatchModel, payerId, batchNumber);

    }

    private List<byte[]> buildAndGenerateGroupedPdfs(DisbursementBatchModel batch, UUID payerId, String batchNumber) {

        MasterAgreementModel masterAgreement = masterAgreementRepository.findByPayerId(payerId)
                .orElseThrow(
                        () -> new ResourceNotFoundException("Master agreement not found with payer ID: " + payerId));

        CreditFacilityModel creditFacility = creditFacilityRepository.findByPayerId     (masterAgreement.getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Credit Facility not found with master agreement ID: " + masterAgreement.getId()));

        String creditFacilityNumber = creditFacility.getCreditFacilityNumber();
        String payerName = masterAgreement.getPayer().getName();
        

        List<FinancingTransactionModel> batchTransactions = financingTransactionRepository.findByDisbursementBatch(batch);
        
        LocalDate disbursementDate = batchTransactions.getFirst().getScheduledDisbursementDate();

        // Agrupar por Fechas
        record GroupingKey(LocalDate requestDate, LocalDate expirationDate) {}

        Map<GroupingKey, List<FinancingTransactionModel>> groupedTransactions = batchTransactions.stream()
                .collect(Collectors.groupingBy(tx -> new GroupingKey(
                        tx.getDocument().getDueDate(), 
                        tx.getCreatedAt() 
                )));

        List<byte[]> generatedPdfs = new ArrayList<>();

        // Iterar por grupo para construir cada PDF
        for (Map.Entry<GroupingKey, List<FinancingTransactionModel>> entry : groupedTransactions.entrySet()) {

            List<FinancingTransactionModel> groupTxs = entry.getValue();

            Integer plazoDias = masterAgreement.getPaymentPolicy().getDaysCount();

            BigDecimal groupTotalToDisburse = BigDecimal.ZERO;
            BigDecimal groupCommissionWithIva = BigDecimal.ZERO;
            List<String[]> reportData = new ArrayList<>();
            
            for (FinancingTransactionModel tx : groupTxs) {
                BigDecimal txCommissionTotal = tx.getCommissionAmount().add(tx.getIvaAmount());
                
                groupTotalToDisburse = groupTotalToDisburse.add(tx.getAmountToBeDisbursed());
                groupCommissionWithIva = groupCommissionWithIva.add(txCommissionTotal);

                reportData.add(new String[]{
                        tx.getDocument().getDocumentNumber(),
                        "$" + tx.getFlatAmount().toString(),
                        "$" + tx.getInterestAmount().toString(),
                        "$" + tx.getCommissionAmount().toString(),
                        "$" + tx.getAmountToBeDisbursed().toString()
                });
            }

            BigDecimal groupNetToDisburse = groupTotalToDisburse.subtract(groupCommissionWithIva);

            // Construir Metadatos del archivo
            Map<String, String> metadata = new LinkedHashMap<>();
            metadata.put("1. Dueño de Línea de Crédito", payerName);
            metadata.put("2. Monto total a desembolsar", "$" + groupTotalToDisburse.toString());
            metadata.put("3. Comisión total con IVA", "$" + groupCommissionWithIva.toString());
            metadata.put("4. Monto a desembolsar menos comisión", "$" + groupNetToDisburse.toString());
            metadata.put("5. Número de cupo", creditFacilityNumber);
            metadata.put("6. Fecha de desembolso", disbursementDate.toString());
            metadata.put("7. Plazo de operación", plazoDias + " días");

            PdfReportConfig config = new PdfReportConfig(
                    "Desembolso Lote: " + batchNumber + " - Plazo: " + plazoDias + " días",
                    metadata,
                    new String[]{"No. Documento", "Monto Nominal", "Interés", "Comisión", "A Desembolsar"},
                    new float[]{3f, 2f, 2f, 2f, 2f},
                    reportData
            );

            generatedPdfs.add(genericPdfService.generateTableReport(config));
        }

        return generatedPdfs;

    }

    @Transactional
    public void confirmDisbursement(List<UUID> documentIds, UUID confirmedById) {

        // 1. Validar que el usuario que confirma existe
        UserModel confirmedBy = userRepository.findById(confirmedById)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con ID: " + confirmedById));

        // 2. Extraer todos los documentos solicitados de una vez
        List<DocumentModel> documents = documentRepository.findAllById(documentIds);

        // 3. Validación Fail-Fast: Asegurar que todos los IDs enviados existan en la BD
        if (documents.size() != documentIds.size()) {
            log.error("Discrepancia en confirmación: Se solicitaron {} documentos, pero se encontraron {}.",
                    documentIds.size(), documents.size());
            throw new ResourceNotFoundException("Uno o más documentos solicitados no existen en la base de datos.");
        }

        List<DocumentLogModel> documentLogs = new java.util.ArrayList<>();

        // 4. Procesar y validar reglas de negocio
        for (DocumentModel doc : documents) {

            // Fail-Fast: Bloquear si intentan confirmar un documento que no está en la
            // etapa correcta
            if (!doc.getStatus().equals(DocumentStatusEnum.REQUESTED_FOR_DISBURSEMENT)) {
                log.error("Intento de confirmación inválido. Documento {} en estado {}.",
                        doc.getDocumentNumber(), doc.getStatus());

                throw new IllegalStateException("El documento " + doc.getDocumentNumber() +
                        " no está listo para ser desembolsado.");
            }

            DocumentStatusEnum finalStatus = DocumentStatusEnum.DISBURSED;

            // Construir el registro de auditoría
            DocumentLogModel logEntry = DocumentLogModel.builder()
                    .document(doc)
                    .user(confirmedBy)
                    .status(finalStatus)
                    .build();

            documentLogs.add(logEntry);

            // Actualizar el estado del documento
            doc.setStatus(finalStatus);
        }

        // 5. Persistencia masiva
        documentRepository.saveAll(documents);
        documentLogRepository.saveAll(documentLogs);

        log.info("Confirmación exitosa: Se desembolsaron {} documentos por el usuario {}.",
                documents.size(), confirmedById);
    }

}