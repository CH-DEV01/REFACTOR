package com.davivienda.factoraje.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.davivienda.factoraje.dto.entity.EntityDTORequest;
import com.davivienda.factoraje.dto.entity.EntityDTOResponse;

public interface EntityService {

    EntityDTOResponse createEntity(EntityDTORequest request);

    Page<EntityDTOResponse> getPayers(Pageable pageable);

    Page<EntityDTOResponse> getSuppliers(Pageable pageable);

    Page<EntityDTOResponse> getEntities(Pageable pageable);

}
