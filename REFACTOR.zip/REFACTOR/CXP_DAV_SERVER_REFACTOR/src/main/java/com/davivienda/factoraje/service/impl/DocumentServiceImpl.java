package com.davivienda.factoraje.service.impl;

import java.util.UUID;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.domain.entities.MasterAgreementModel;
import com.davivienda.factoraje.domain.entities.UploadBatchModel;
import com.davivienda.factoraje.dto.document.DocumentDTORequest;
import com.davivienda.factoraje.dto.document.DocumentDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.DocumentRepository;
import com.davivienda.factoraje.repository.MasterAgreementRepository;
import com.davivienda.factoraje.repository.UploadBatchRepository;
import com.davivienda.factoraje.service.DocumentService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;
    private final MasterAgreementRepository masterAgreementRepository;
    private final UploadBatchRepository uploadBatchRepository;

    public DocumentServiceImpl(

            DocumentRepository documentRepository,
            MasterAgreementRepository mastAgreementRepository,
            UploadBatchRepository uploadBatchRepository

    ) {
        this.documentRepository = documentRepository;
        this.masterAgreementRepository = mastAgreementRepository;
        this.uploadBatchRepository = uploadBatchRepository;
        log.info("DocumentService initialized");
    }

    private void validateUniqueControlNumber(DocumentDTORequest request, UUID supplierId) {
        int year = request.issueDate().getYear();

        boolean exists = documentRepository.existsByControlNumberAndYearAndSupplier(
                request.controlNumber(),
                year,
                supplierId);

        if (exists) {
            throw new ResourceAlreadyExistsException(
                    String.format("El DTE con número de control %s del año %d ya existe para este proveedor.",
                            request.controlNumber(), year));
        }
    }

    public DocumentDTOResponse createDocument(DocumentDTORequest request) {

        log.info("");

        MasterAgreementModel masterAgreement = masterAgreementRepository.findById(request.masterAgreementId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Master agreement not found with ID: " + request.masterAgreementId()));

        UploadBatchModel uploadBatch = uploadBatchRepository.findById(request.uploadBatchId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Upload batch not found with ID: " + request.uploadBatchId()));

        validateUniqueControlNumber(request, masterAgreement.getSupplier().getId());

        DocumentModel documentModel = DocumentModel.builder()
                .controlNumber(request.controlNumber())
                .documentNumber(request.documentNumber())
                .generationCode(request.generationCode())
                .invoiceType(request.invoiceType())
                .issuanceMethod(request.issuanceMethod())
                .nominalAmount(request.nominalAmount())
                .issueDate(request.issueDate())
                .masterAgreement(masterAgreement)
                .receivedStamp(request.receivedStamp())
                .status(request.status())
                .uploadBatch(uploadBatch)
                .build();

        try {
            DocumentModel savedDocument = documentRepository.save(documentModel);
            log.info("Document created successfully with ID: {}", savedDocument.getId());
            return DocumentDTOResponse.fromEntity(savedDocument);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the document. Possible race condition.", e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the document. Possible race condition.");
        }

    }

}
