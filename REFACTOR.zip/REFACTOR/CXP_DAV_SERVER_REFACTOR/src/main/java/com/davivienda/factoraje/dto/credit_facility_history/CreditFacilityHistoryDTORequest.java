package com.davivienda.factoraje.dto.credit_facility_history;

import java.math.BigDecimal;

public record CreditFacilityHistoryDTORequest(

    


) {
    
}
