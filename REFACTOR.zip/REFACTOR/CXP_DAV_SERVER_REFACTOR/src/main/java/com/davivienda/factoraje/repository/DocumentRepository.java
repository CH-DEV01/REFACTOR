package com.davivienda.factoraje.repository;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.entities.DocumentModel;
import com.davivienda.factoraje.domain.enums.DocumentStatusEnum;

@Repository
public interface DocumentRepository extends JpaRepository<DocumentModel, UUID> {

        @Query("SELECT d.generationCode FROM DocumentModel d WHERE d.generationCode IN :generationCodes")
        Set<String> findExistingGenerationCodes(@Param("generationCodes") List<String> generationCodes);

        // Spring Data buscará los primeros 500 por Estado Y por el ID del Pagador
        List<DocumentModel> findTop500ByStatusAndMasterAgreement_Payer_Id(DocumentStatusEnum status, UUID payerId);

        @Query("SELECT COUNT(d) > 0 FROM DocumentModel d " +
                        "WHERE d.controlNumber = :controlNumber " +
                        "AND EXTRACT(YEAR FROM d.issueDate) = :year " +
                        "AND d.masterAgreement.supplier.id = :supplierId")
        boolean existsByControlNumberAndYearAndSupplier(
                        @Param("controlNumber") String controlNumber,
                        @Param("year") int year,
                        @Param("supplierId") UUID supplierId);

        /**
         * Consulta masiva (Bulk Lookup) de duplicados.
         * Busca qué documentos de la lista proporcionada ya están registrados en la BD
         * para este convenio.
         */
        @Query("""
                            SELECT d.documentNumber
                            FROM DocumentModel d
                            WHERE d.masterAgreement.id = :agreementId
                            AND d.documentNumber IN :documentNumbers
                        """)
        Set<String> findExistingDocumentNumbers(
                        @Param("documentNumbers") Set<String> documentNumbers,
                        @Param("agreementId") UUID agreementId);

        @Query("SELECT d.documentNumber FROM DocumentModel d " +
        // Navegamos del Documento -> Acuerdo -> Proveedor -> NIU
                        "WHERE d.masterAgreement.supplier.niu = :niu " +
                        "AND d.documentNumber IN :documentNumbers " +
                        "AND EXTRACT(YEAR FROM d.issueDate) = :year")
        Set<String> findExistingPhysicalDocuments(
                        @Param("niu") String niu,
                        @Param("documentNumbers") List<String> documentNumbers,
                        @Param("year") int year);
}
