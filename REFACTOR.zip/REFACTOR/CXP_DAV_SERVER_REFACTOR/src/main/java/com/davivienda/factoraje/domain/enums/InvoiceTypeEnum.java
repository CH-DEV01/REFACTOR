package com.davivienda.factoraje.domain.enums;

public enum InvoiceTypeEnum {
    CCF,
    FCI;

    public static InvoiceTypeEnum fromString(String text) {
        if (text == null || text.isBlank()) return null;
        try {
            // Convierte a mayúscula y busca el match exacto
            return InvoiceTypeEnum.valueOf(text.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return null; // Si no es CCF o FCI exacto, retorna null
        }
    }
}
