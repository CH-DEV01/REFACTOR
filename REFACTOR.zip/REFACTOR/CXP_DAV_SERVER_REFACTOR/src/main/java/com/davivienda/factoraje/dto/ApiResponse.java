package com.davivienda.factoraje.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter 
@AllArgsConstructor
@NoArgsConstructor 
public class ApiResponse<T> {

    private boolean success;
    private String message;
    private T data; 
    private LocalDateTime timestamp;

    // MÉTODO ORIGINAL DE ÉXITO
    public static <T> ApiResponse<T> success(T data, String message) {
        return new ApiResponse<>(true, message, data, LocalDateTime.now());
    }

    // NUEVO MÉTODO: Para errores con detalles (como tu lista de BatchValidationError)
    public static <T> ApiResponse<T> error(String message, T data) {
        return new ApiResponse<>(false, message, data, LocalDateTime.now());
    }

    // NUEVO MÉTODO (Sobrecarga): Para errores generales sin una lista de detalles
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(false, message, null, LocalDateTime.now());
    }
}
