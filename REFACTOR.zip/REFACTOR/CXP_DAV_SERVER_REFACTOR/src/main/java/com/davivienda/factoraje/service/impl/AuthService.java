package com.davivienda.factoraje.service.impl;

import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.dto.auth.MenuDTO;
import com.davivienda.factoraje.dto.auth.RouteDTO;
import com.davivienda.factoraje.dto.auth.UserProfileResponseDTO;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.infrastructure.security.JwtService;
import com.davivienda.factoraje.repository.UserRepository;
import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final JwtService jwtService;

    public String authenticateViaSSO(String dui) {

        // TODO: En producción, aquí deberías validar primero el token externo del SSO
        // antes de confiar ciegamente en el DUI proporcionado en la petición.

        UserModel user = userRepository.findByDui(dui)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no registrado en el sistema local."));

        if (!user.isEnabled()) {
            throw new IllegalStateException("El usuario se encuentra inactivo.");
        }

        return jwtService.generateToken(user);
    }

    public UserProfileResponseDTO getCurrentUserProfile() {
        // 1. Obtener la autenticación actual del contexto de Spring Security
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()
                || authentication.getPrincipal().equals("anonymousUser")) {
            throw new IllegalStateException("No hay un usuario autenticado en el contexto.");
        }

        // 2. El "name" en la autenticación es nuestro DUI (porque así lo configuramos
        // en getUsername())
        String dui = authentication.getName();

        // 3. Buscar el usuario fresco en la BD
        UserModel user = userRepository.findByDui(dui)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con DUI: " + dui));

        // 4. Determinar la ruta por defecto según el rol de tu sistema
        String roleName = user.getRole().getName(); // Ajusta esto si tu método se llama distinto
        String defaultRoute = determineDefaultRoute(roleName);

        List<MenuDTO> menus = determineMenus(roleName);
        List<RouteDTO> routes = determineRoutes(roleName);

        // 5. Construir y retornar el DTO (Si tienes una tabla de permisos, mapealos.
        // Aquí envío un array vacío como ejemplo)
        return new UserProfileResponseDTO(
                user.getDui(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                roleName,
                defaultRoute,
                List.of(),
                menus,
                routes
            );
    }

    private String determineDefaultRoute(String roleName) {
        return switch (roleName.toUpperCase()) {
            case "MANAGER", "ADMIN" -> "/admin";
            case "SUPPLIER" -> "/select-agreement";
            case "AUTHORIZING_TWO_MODE_AUTH", "PAYER" -> "/payer";
            case "OPERATOR" -> "/operator";
            default -> "/unauthorized";
        };
    }

    private List<RouteDTO> determineRoutes(String roleName) {
        return switch (roleName.toUpperCase()) {
            case "MANAGER", "ADMIN" -> List.of(
                    new RouteDTO("", "Menu", true),
                    new RouteDTO("agreement-management", "AgreementManagement", false),
                    new RouteDTO("supplier-management", "SupplierManagement", false),
                    new RouteDTO("payer-management-admin", "PayerManagementAdmin", false),
                    new RouteDTO("user-management", "UserManagement2", false),
                    new RouteDTO("param-management", "ParamManagement", false),
                    new RouteDTO("upload-file-admin", "UploadFilePageAdmin", false),
                    new RouteDTO("documents-history", "DocumentManagement", false),
                    new RouteDTO("view-documents/:id", "ViewDocument", false), // Soporta parámetros
                    new RouteDTO("term-management", "TermManagement", false),
                    new RouteDTO("holiday-management", "HolidayManagement", false),
                    new RouteDTO("payer-credit-line-management", "PayerCreditLineManager", false),
                    new RouteDTO("master-agreement-management", "AgreementManagement", false)
                );
            case "OPERATOR" -> List.of(
                    new RouteDTO("", "ControlTerminal", true));
            case "SUPPLIER" -> List.of(
                    new RouteDTO("", "SelectDocuments", true),
                    new RouteDTO("documents-history", "DocumentLog", false));
            case "AUTHORIZING_TWO_MODE_AUTH", "PAYER" -> List.of(
                    new RouteDTO("", "UploadFilePage", true),
                    new RouteDTO("documents-history", "PayerDocumentManagement", false));
            default -> List.of();
        };
    }

    private List<MenuDTO> determineMenus(String roleName) {
        // Adaptado a las rutas que tenías en tu archivo App.js de React
        return switch (roleName.toUpperCase()) {
            case "MANAGER", "ADMIN" -> List.of(
                    new MenuDTO("Inicio", "/admin", "home"),
                    new MenuDTO("Acuerdos", "/admin/agreement-management", "file-text"),
                    new MenuDTO("Proveedores", "/admin/supplier-management", "truck"),
                    new MenuDTO("Pagadores", "/admin/payer-management-admin", "credit-card"),
                    new MenuDTO("Usuarios", "/admin/user-management", "users"),
                    new MenuDTO("Parámetros", "/admin/param-management", "settings"),
                    new MenuDTO("Feriados", "/admin/holiday-management", "calendar"));
            case "SUPPLIER" -> List.of(
                    new MenuDTO("Seleccionar Acuerdos", "/select-agreement", "list"),
                    new MenuDTO("Documentos", "/supplier", "file"),
                    new MenuDTO("Historial", "/supplier/documents-history", "clock"));
            case "AUTHORIZING_TWO_MODE_AUTH", "PAYER" -> List.of(
                    new MenuDTO("Cargar Archivos", "/payer", "upload"),
                    new MenuDTO("Historial", "/payer/documents-history", "clock"));
            case "OPERATOR" -> List.of(
                    new MenuDTO("Terminal de Control", "/operator", "monitor"));
            default -> List.of();
        };
    }
}
