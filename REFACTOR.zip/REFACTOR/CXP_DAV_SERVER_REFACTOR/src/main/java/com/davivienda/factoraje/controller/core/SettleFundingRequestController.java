package com.davivienda.factoraje.controller.core;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.davivienda.factoraje.dto.ApiResponse;
import com.davivienda.factoraje.dto.disbursement_batch.ConfirmDisbursementRequestDTO;
import com.davivienda.factoraje.dto.disbursement_batch.GenerateBatchRequestDTO;
import com.davivienda.factoraje.service.impl.SettleFundingRequestServiceImpl;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/disbursement-requests")
@RequiredArgsConstructor
public class SettleFundingRequestController {

    private final SettleFundingRequestServiceImpl settleFundingRequestService;

    @PostMapping(value = "/generate-batch", produces = "application/zip")
    public ResponseEntity<byte[]> generateDisbursementBatch(
            @Valid @RequestBody GenerateBatchRequestDTO request) {

        log.info("Generando lote de desembolso para el pagador: {}", request.payerId());
        
        // 1. Obtener la lista de PDFs desde el servicio
        List<byte[]> pdfFiles = settleFundingRequestService.generateDisbursementBatch(
                request.createdById(), 
                request.originalFileName(),
                request.payerId()
        );

        // 2. Comprimir los PDFs en un solo archivo ZIP
        byte[] zipFile = compressToZip(pdfFiles, request.originalFileName());

        // 3. Configurar los Headers para forzar la descarga del ZIP
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.valueOf("application/zip"));
        headers.setContentDispositionFormData("attachment", "Reportes_Desembolso_" + request.originalFileName() + ".zip");
        headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");

        return ResponseEntity.ok()
                .headers(headers)
                .body(zipFile);
    }

    @PostMapping("/confirm")
    public ResponseEntity<ApiResponse<Void>> confirmDisbursement(
            @Valid @RequestBody ConfirmDisbursementRequestDTO request) {

        log.info("Confirmando desembolso de {} documentos por usuario {}", 
                 request.documentIds().size(), request.confirmedById());
        
        settleFundingRequestService.confirmDisbursement(request.documentIds(), request.confirmedById());

        return ResponseEntity.ok(ApiResponse.success(null,"El desembolso de los documentos ha sido confirmado."));
    }

    // --- MÉTODO AUXILIAR PARA COMPRESIÓN ---

    private byte[] compressToZip(List<byte[]> files, String baseName) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ZipOutputStream zos = new ZipOutputStream(baos)) {

            for (int i = 0; i < files.size(); i++) {
                // Nombrar cada archivo PDF dentro del ZIP de forma secuencial
                String fileName = "Reporte_" + baseName + "_Grupo_" + (i + 1) + ".pdf";
                
                ZipEntry entry = new ZipEntry(fileName);
                zos.putNextEntry(entry);
                zos.write(files.get(i));
                zos.closeEntry();
            }
            
            zos.finish();
            return baos.toByteArray();

        } catch (Exception e) {
            log.error("Error comprimiendo los archivos PDF", e);
            throw new RuntimeException("Error al generar el archivo comprimido de reportes", e);
        }
    }
}