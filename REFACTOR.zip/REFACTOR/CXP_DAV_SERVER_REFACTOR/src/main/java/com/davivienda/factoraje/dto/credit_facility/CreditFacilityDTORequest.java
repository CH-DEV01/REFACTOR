package com.davivienda.factoraje.dto.credit_facility;

import java.math.BigDecimal;
import java.util.UUID;

public record CreditFacilityDTORequest(

    BigDecimal facilityLimitAmount,
    BigDecimal amountInUse,
    UUID payerId
){}
