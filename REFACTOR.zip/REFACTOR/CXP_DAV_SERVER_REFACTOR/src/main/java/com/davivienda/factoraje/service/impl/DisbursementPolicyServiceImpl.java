package com.davivienda.factoraje.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.catalogs.DisbursementPolicyCat;
import com.davivienda.factoraje.dto.disbursement_policy.DisbursementPolicyDTOResponse;
import com.davivienda.factoraje.repository.DisbursementPolicyCatRepository;
import com.davivienda.factoraje.service.DisbursementPolicyService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DisbursementPolicyServiceImpl implements DisbursementPolicyService {

    private final DisbursementPolicyCatRepository disbursementPolicyCatRepository;

    public DisbursementPolicyServiceImpl(

        DisbursementPolicyCatRepository disbursementPolicyCatRepository

    ){

        this.disbursementPolicyCatRepository = disbursementPolicyCatRepository;

    }

    @Transactional(readOnly = true)
    @Override 
    public List<DisbursementPolicyDTOResponse> getDisbursementPolicies() {

        List<DisbursementPolicyCat> disbursementPolicies = disbursementPolicyCatRepository.findAll();

        return disbursementPolicies.stream()
                .map(DisbursementPolicyDTOResponse::fromEntity) 
                .toList();
    }

}
