package com.davivienda.factoraje.service.impl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.entities.CreditFacilityModel;
import com.davivienda.factoraje.domain.entities.ProductPricingTermModel;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.dto.product_pricing_term.ProductPricingTermDTORequest;
import com.davivienda.factoraje.dto.product_pricing_term.ProductPricingTermDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.CreditFacilityRepository;
import com.davivienda.factoraje.repository.ProductPricingTermRepository;
import com.davivienda.factoraje.service.ProductPricingTermService;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductPricingTermServiceImpl implements ProductPricingTermService {

    private final ProductPricingTermRepository productPricingTermRepository;
    private final CreditFacilityRepository creditFacilityRepository;

    public ProductPricingTermServiceImpl(
            ProductPricingTermRepository productPricingTermRepository,
            CreditFacilityRepository creditFacilityRepository) {
        this.creditFacilityRepository = creditFacilityRepository;
        this.productPricingTermRepository = productPricingTermRepository;
        log.info("ProductPricingTermService initialized");
    }

    private void validateUniqueness(ProductPricingTermDTORequest entity) {
        if (productPricingTermRepository.existsByCreditFacilityId(entity.creditFacilityId())) {
            log.warn("Operation rejected: An entity with the provided credit facility ID already exists.");
            throw new ResourceAlreadyExistsException(
                    "Operation rejected: An entity with the provided credit facility ID already exists.");
        }
    }

    @Transactional
    @Override
    public ProductPricingTermDTOResponse createProductPricingTerm(ProductPricingTermDTORequest request) {

        log.info("Starting the creation of a new product pricing term");
        validateUniqueness(request);

        CreditFacilityModel creditFacility = creditFacilityRepository.findById(request.creditFacilityId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Credit facility not found with ID: " + request.creditFacilityId()));

        ProductPricingTermModel productPricingTerm = ProductPricingTermModel.builder()
                .creditFacility(creditFacility)
                .calculationBase(request.calculationBase())
                .interestRate(request.interestRate())
                .commissionRate(request.commissionRate())
                .status(GeneralStatusEnum.ACTIVE)
                .build();

        try {
            ProductPricingTermModel savedProductPricingTerm = productPricingTermRepository.save(productPricingTerm);
            log.info("Product pricing term created successfully with ID: {}", savedProductPricingTerm.getId());
            return ProductPricingTermDTOResponse.fromEntity(savedProductPricingTerm);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the entity. Possible race condition.", e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the entity. Possible race condition.");
        }

    }

}
