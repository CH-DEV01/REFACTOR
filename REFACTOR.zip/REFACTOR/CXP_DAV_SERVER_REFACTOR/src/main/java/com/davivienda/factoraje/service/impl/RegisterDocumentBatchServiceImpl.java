package com.davivienda.factoraje.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.davivienda.factoraje.domain.entities.EntityModel;
import com.davivienda.factoraje.domain.entities.ExcelTemplateColumnModel;
import com.davivienda.factoraje.domain.entities.MasterAgreementModel;
import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTORequest;
import com.davivienda.factoraje.dto.report.PdfReportData;
import com.davivienda.factoraje.dto.upload_batch.BatchProcessResult;
import com.davivienda.factoraje.dto.upload_batch.InvoiceRecordDTO;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.infrastructure.file_parser.excel.BatchValidationError;
import com.davivienda.factoraje.infrastructure.file_parser.excel.ExcelParseResult;
import com.davivienda.factoraje.infrastructure.file_parser.excel.GenericExcelParser;
import com.davivienda.factoraje.infrastructure.reporting.PdfReportGenerator;
import com.davivienda.factoraje.repository.EntityRepository;
import com.davivienda.factoraje.repository.ExcelTemplateColumnRepository;
import com.davivienda.factoraje.repository.TermVersionCatRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.DocumentValidationService;
import com.davivienda.factoraje.service.RegisterDocumentBatchService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class RegisterDocumentBatchServiceImpl implements RegisterDocumentBatchService {

    private final GenericExcelParser genericExcelParser;
    private final ExcelTemplateColumnRepository excelTemplateColumnRepository;
    private final DocumentValidationService validationService;
    private final TermVersionCatRepository versionRepository;
    private final UserRepository userRepository;
    private final PdfReportGenerator pdfReportGenerator;
    private final EntityRepository entityRepository;
    private final BatchPersistenceService batchPersistenceService;

    @Override
    public BatchProcessResult processFile(
            MultipartFile file,
            AcceptanceAuditDTORequest auditRequest,
            UUID payerId,
            UUID uploadedAndApprovedBy) {

        EntityModel payer = entityRepository.findById(payerId)
                .orElseThrow(() -> new ResourceNotFoundException("El pagador especificado no existe o no es válido."));

        if (!userRepository.existsById(uploadedAndApprovedBy)) {
            throw new ResourceNotFoundException("El usuario especificado no existe.");
        }

        if (auditRequest.versionId() != null && !versionRepository.existsById(auditRequest.versionId())) {
            throw new ResourceNotFoundException("La versión de términos y condiciones especificada no existe.");
        }

        List<ExcelTemplateColumnModel> columns = excelTemplateColumnRepository.findAll();
        List<String> requiredHeaders = columns.stream()
                .filter(ExcelTemplateColumnModel::isRequired)
                .map(ExcelTemplateColumnModel::getExcelColumnName)
                .toList();

        String originalFilename = file.getOriginalFilename();
        ExcelParseResult<InvoiceRecordDTO> parseResult;

        try (InputStream inputStream = file.getInputStream();
                Workbook workbook = WorkbookFactory.create(inputStream)) {

            parseResult = genericExcelParser.parse(
                    workbook,
                    null,
                    requiredHeaders,
                    (accessor, rowIndex) -> new InvoiceRecordDTO(
                            rowIndex,
                            accessor.getLocalDate(getPhysicalColumnName(columns, "issueDate")),
                            accessor.getBigDecimal(getPhysicalColumnName(columns, "nominalAmount")),
                            accessor.getString(getPhysicalColumnName(columns, "documentNumber")),
                            accessor.getString(getPhysicalColumnName(columns, "generationCode")),
                            accessor.getString(getPhysicalColumnName(columns, "receivedStamp")),
                            accessor.getString(getPhysicalColumnName(columns, "controlNumber")),
                            accessor.getString(getPhysicalColumnName(columns, "issuanceMethod")),
                            accessor.getString(getPhysicalColumnName(columns, "invoiceType")),
                            accessor.getString(getPhysicalColumnName(columns, "supplierNiu")),
                            accessor.getString(getPhysicalColumnName(columns, "supplierNit")),
                            accessor.getString(getPhysicalColumnName(columns, "supplierName")),
                            accessor.getString(getPhysicalColumnName(columns, "paymentPolicy")),
                            accessor.getString(getPhysicalColumnName(columns, "disbursementDay")),
                            accessor.getString(getPhysicalColumnName(columns, "operatorDui")),
                            accessor.getString(getPhysicalColumnName(columns, "operatorEmail")),
                            accessor.getString(getPhysicalColumnName(columns, "operatorFirstName")),
                            accessor.getString(getPhysicalColumnName(columns, "operatorMiddleName")),
                            accessor.getString(getPhysicalColumnName(columns, "operatorFirstLastName")),
                            accessor.getString(getPhysicalColumnName(columns, "operatorSecondLastName"))
                ));

        } catch (Exception e) {
            log.error("Error al leer el Excel: {}", e.getMessage());
            throw new RuntimeException("El archivo no pudo ser leído. Verifique que sea un Excel válido.");
        }

        List<BatchValidationError> errors = new ArrayList<>();
        if (parseResult.hasErrors()) {
            errors.addAll(parseResult.parsingErrors());
        }

        List<InvoiceRecordDTO> parsedInvoices = parseResult.successfulRecords();
        if (parsedInvoices.isEmpty() && errors.isEmpty()) {
            throw new IllegalArgumentException("El archivo no contiene registros válidos de facturas.");
        }

        Map<String, List<InvoiceRecordDTO>> invoicesBySupplier = new HashMap<>();
        
        if (!parsedInvoices.isEmpty()) {
            invoicesBySupplier = parsedInvoices.stream()
                    .collect(Collectors.groupingBy(InvoiceRecordDTO::supplierNiu));

            for (Map.Entry<String, List<InvoiceRecordDTO>> entry : invoicesBySupplier.entrySet()) {
                List<InvoiceRecordDTO> supplierInvoices = entry.getValue();
                List<BatchValidationError> businessErrors = validationService.validateBatch(supplierInvoices, null);
                
                if (!businessErrors.isEmpty()) {
                    errors.addAll(businessErrors);
                }
            }
        }

        if (!errors.isEmpty()) {
            log.warn("La validación previa falló con {} errores. Generando PDF de rechazo. No se tocó la Base de Datos.", errors.size());

            List<String> errorList = errors.stream()
                    .map(err -> String.format("Fila %d [%s]: %s",
                            err.rowIndex(),
                            err.columnName() != null ? err.columnName() : "General",
                            err.errorMessage()))
                    .toList();

            PdfReportData errorReportData = new PdfReportData(
                    "Reporte de rechazo de carga",
                    Map.of(
                            "Archivo procesado", originalFilename,
                            "Total de inconsistencias", String.valueOf(errors.size())),
                    "Detalle de inconsistencias encontradas",
                    errorList 
            );

            byte[] errorPdf = pdfReportGenerator.generateReport(errorReportData);
            return new BatchProcessResult(errorPdf, false);
        }

        Map<String, MasterAgreementModel> resolvedAgreements = new HashMap<>();

        try {
            for (Map.Entry<String, List<InvoiceRecordDTO>> entry : invoicesBySupplier.entrySet()) {
                String supplierNiu = entry.getKey();
                List<InvoiceRecordDTO> supplierInvoices = entry.getValue();

                MasterAgreementModel masterAgreement = batchPersistenceService
                        .resolveOrCreateSupplierAndAgreement(payer, supplierInvoices.get(0));
                
                resolvedAgreements.put(supplierNiu, masterAgreement);
            }

            UUID batchId = batchPersistenceService.saveParsedBatchToDatabase(
                    originalFilename,
                    parsedInvoices,
                    resolvedAgreements,
                    uploadedAndApprovedBy,
                    auditRequest,
                    payerId);

            List<List<String>> tableRows = parsedInvoices.stream()
                    .map(inv -> List.of(
                            String.valueOf(inv.rowIndex()),
                            inv.documentNumber() != null ? inv.documentNumber() : "-",
                            inv.issueDate() != null ? inv.issueDate().toString() : "-",
                            inv.supplierNiu() != null ? inv.supplierNiu() : "-",
                            "$" + (inv.nominalAmount() != null ? String.format("%.2f", inv.nominalAmount()) : "0.00")))
                    .toList();

            List<String> tableHeaders = List.of(
                    "Fila", "N° Documento", "Fecha Emisión", "NIU Proveedor", "Monto Nominal");

            PdfReportData successReportData = new PdfReportData(
                    "Comprobante de carga de facturas",
                    Map.of(
                            "ID de lote", batchId.toString(),
                            "Archivo procesado", originalFilename,
                            "Total procesados", String.valueOf(parsedInvoices.size())),
                    "Detalle de documentos registrados",
                    null, 
                    tableHeaders, 
                    tableRows
            );

            byte[] successPdf = pdfReportGenerator.generateReport(successReportData);
            return new BatchProcessResult(successPdf, true);

        } catch (IllegalArgumentException e) {
            PdfReportData limitErrorReportData = new PdfReportData(
                    "Reporte de rechazo por límite de crédito",
                    Map.of("Archivo procesado", originalFilename),
                    "Observación",
                    List.of(e.getMessage()));
            
            byte[] limitErrorPdf = pdfReportGenerator.generateReport(limitErrorReportData);
            return new BatchProcessResult(limitErrorPdf, false);
            
        } catch (Exception e) {
            log.error("Fallo inesperado de base de datos durante la persistencia: {}", e.getMessage(), e);
            throw new RuntimeException("Ocurrió un error inesperado al guardar los registros en el sistema.");
        }
    }

    private String getPhysicalColumnName(List<ExcelTemplateColumnModel> columns, String logicalName) {
        return columns.stream()
                .filter(c -> c.getLogicalDtoField().equals(logicalName))
                .findFirst()
                .map(ExcelTemplateColumnModel::getExcelColumnName)
                .orElse(logicalName);
    }
}