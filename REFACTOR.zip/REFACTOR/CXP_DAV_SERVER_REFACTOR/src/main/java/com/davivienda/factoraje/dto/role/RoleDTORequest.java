package com.davivienda.factoraje.dto.role;

public record RoleDTORequest() {
    
}
