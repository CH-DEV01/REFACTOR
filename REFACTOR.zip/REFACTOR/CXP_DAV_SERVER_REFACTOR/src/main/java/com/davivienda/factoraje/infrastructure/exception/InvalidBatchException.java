package com.davivienda.factoraje.infrastructure.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class InvalidBatchException extends RuntimeException {
    public InvalidBatchException(String message) {
        super(message);
    }
}
