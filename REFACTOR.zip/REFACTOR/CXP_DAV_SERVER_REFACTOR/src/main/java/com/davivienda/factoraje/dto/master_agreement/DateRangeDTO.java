package com.davivienda.factoraje.dto.master_agreement;

import java.time.ZonedDateTime;

public record DateRangeDTO(
    ZonedDateTime lower,
    ZonedDateTime upper
) {}


