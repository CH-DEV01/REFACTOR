package com.davivienda.factoraje.infrastructure.file_parser.excel;

public record BatchValidationError(
    int rowIndex,
    String columnName, // Opcional, pero útil
    String errorMessage
) {}
