package com.davivienda.factoraje.domain.enums;

public enum FinancingTransactionStatusEnum {

    ASSIGNED,
    FREE
    
}
