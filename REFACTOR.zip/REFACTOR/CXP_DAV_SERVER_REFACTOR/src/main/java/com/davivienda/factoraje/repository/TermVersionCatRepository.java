package com.davivienda.factoraje.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.davivienda.factoraje.domain.catalogs.TermVersionCat;
import com.davivienda.factoraje.domain.enums.GeneralStatusEnum;
import com.davivienda.factoraje.domain.enums.TermTypeUniqueCodeEnum;

@Repository 
public interface TermVersionCatRepository extends JpaRepository<TermVersionCat, UUID>{

    Optional<TermVersionCat> findFirstByStatusAndTermType_UniqueCodeOrderByCreatedAtDesc(
            GeneralStatusEnum status, 
            String uniqueCode
    );
    
}
