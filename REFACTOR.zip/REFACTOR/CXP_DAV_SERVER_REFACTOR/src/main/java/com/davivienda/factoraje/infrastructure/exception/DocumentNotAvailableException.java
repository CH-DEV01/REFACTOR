package com.davivienda.factoraje.infrastructure.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class DocumentNotAvailableException extends RuntimeException {

    public DocumentNotAvailableException(String message) {
        super(message);
    }
    
    public DocumentNotAvailableException(String message, Throwable cause) {
        super(message, cause);
    }
}