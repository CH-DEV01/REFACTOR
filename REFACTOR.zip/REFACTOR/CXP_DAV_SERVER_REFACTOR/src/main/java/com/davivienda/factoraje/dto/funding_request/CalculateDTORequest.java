package com.davivienda.factoraje.dto.funding_request;

import java.util.List;
import java.util.UUID;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record CalculateDTORequest(
        @NotNull(message = "El ID del Convenio Marco es obligatorio.") UUID masterAgreementId,

        @NotNull(message = "El ID del usuario solicitante es obligatorio.") UUID requestedById,

        @NotEmpty(message = "Debe incluir al menos un ID de documento para calcular.") List<UUID> documentIds) {
}
