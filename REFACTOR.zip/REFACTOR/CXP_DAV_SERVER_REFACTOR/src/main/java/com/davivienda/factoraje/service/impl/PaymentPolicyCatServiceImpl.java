package com.davivienda.factoraje.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.davivienda.factoraje.domain.catalogs.PaymentPolicyCat;
import com.davivienda.factoraje.domain.entities.CreditFacilityHistoryModel;
import com.davivienda.factoraje.dto.credit_facility_history.CreditFacilityHistoryDTOResponse;
import com.davivienda.factoraje.dto.entity.EntityDTOResponse;
import com.davivienda.factoraje.dto.payment_policy.PaymentPolicyDTOResponse;
import com.davivienda.factoraje.repository.PaymentPolicyCatRepository;
import com.davivienda.factoraje.service.PaymentPolicyCatService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PaymentPolicyCatServiceImpl implements PaymentPolicyCatService {

    private final PaymentPolicyCatRepository paymentPolicyCatRepository;

    public PaymentPolicyCatServiceImpl(

            PaymentPolicyCatRepository paymentPolicyCatRepository

    ) {

        this.paymentPolicyCatRepository = paymentPolicyCatRepository;
    }

    @Transactional(readOnly = true)
    public List<PaymentPolicyDTOResponse> getPaymentPolicies() {

        List<PaymentPolicyCat> paymentPolicies = paymentPolicyCatRepository.findAll();

        return  paymentPolicies.stream()
                .map(PaymentPolicyDTOResponse::fromEntity)
                .toList();
    }

}
