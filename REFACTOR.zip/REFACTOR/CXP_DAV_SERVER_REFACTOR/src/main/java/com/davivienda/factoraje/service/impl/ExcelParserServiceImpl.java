// package com.davivienda.factoraje.service.impl;

// import java.math.BigDecimal;
// import java.math.RoundingMode;
// import java.util.ArrayList;
// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;

// import org.apache.poi.ss.usermodel.Cell;
// import org.apache.poi.ss.usermodel.CellType;
// import org.apache.poi.ss.usermodel.DataFormatter;
// import org.apache.poi.ss.usermodel.FormulaEvaluator;
// import org.apache.poi.ss.usermodel.Row;
// import org.apache.poi.ss.usermodel.Sheet;
// import org.apache.poi.ss.usermodel.Workbook;
// import org.springframework.stereotype.Service;

// import com.davivienda.factoraje.domain.enums.ExcelColumnEnum;
// import com.davivienda.factoraje.dto.upload_batch.InvoiceRecordDTO;
// import com.davivienda.factoraje.service.ExcelParserService;

// @Service 
// public class ExcelParserServiceImpl implements ExcelParserService {

//     /**
//      * Procesa un Workbook de Excel, mapea dinámicamente las columnas basándose en
//      * la cabecera
//      * y extrae los datos de forma segura utilizando formateadores de celdas.
//      *
//      * @param workbook El libro de Excel a procesar.
//      * @return Lista de DTOs con los registros extraídos.
//      */
//     public List<InvoiceRecordDTO> parseInvoices(Workbook workbook) {
//         Sheet sheet = workbook.getSheetAt(0);
//         List<InvoiceRecordDTO> parsedInvoices = new ArrayList<>();

//         // 1. Herramientas de extracción segura de Apache POI
//         DataFormatter formatter = new DataFormatter();
//         FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

//         // 2. Extracción y mapeo dinámico de cabeceras (Fila 0)
//         Row headerRow = sheet.getRow(0);
//         if (headerRow == null) {
//             throw new IllegalArgumentException("The Excel file is empty or does not have a header row.");
//         }

//         Map<String, Integer> headerIndexMap = buildHeaderIndexMap(headerRow, formatter);
//         validateRequiredHeaders(headerIndexMap);

//         // 3. Lectura iterativa de datos (Fila 1 en adelante)
//         for (int i = 1; i <= sheet.getLastRowNum(); i++) {
//             Row row = sheet.getRow(i);

//             // Saltamos filas completamente vacías para evitar NullPointerExceptions
//             if (row == null || isRowEmpty(row))
//                 continue;

//             InvoiceRecordDTO dto = new InvoiceRecordDTO();
//             dto.setRowIndex(i + 1);

//             // Extracción basada en el Enum (Tipo seguro y resistente a desorden de
//             // columnas)
//             dto.setIssueDate(
//                     getCellValue(row, headerIndexMap.get(ExcelColumnEnum.FECHA_EMISION.getKey()), formatter, evaluator));
//             dto.setDocumentNumber(
//                     getCellValue(row, headerIndexMap.get(ExcelColumnEnum.NUM_DOCUMENTO.getKey()), formatter, evaluator));
//             dto.setSupplierName(
//                     getCellValue(row, headerIndexMap.get(ExcelColumnEnum.PROVEEDOR.getKey()), formatter, evaluator));
//             dto.setNit(getCellValue(row, headerIndexMap.get(ExcelColumnEnum.NIT.getKey()), formatter, evaluator));
//             dto.setSupplierEmail(
//                     getCellValue(row, headerIndexMap.get(ExcelColumnEnum.CORREO.getKey()), formatter, evaluator));
//             dto.setBankAccount(
//                     getCellValue(row, headerIndexMap.get(ExcelColumnEnum.CUENTA.getKey()), formatter, evaluator));
//             dto.setSupplierCode(
//                     getCellValue(row, headerIndexMap.get(ExcelColumnEnum.CODIGO.getKey()), formatter, evaluator));

//             if (dto.getSupplierCode() == null || dto.getSupplierCode().isEmpty()) {
//                 throw new IllegalArgumentException(
//                         "The supplier code cannot be null in the row." + dto.getRowIndex());
//             }

//             // Manejo especial y limpieza para el Monto (BigDecimal)
//             String montoStr = getCellValue(row, headerIndexMap.get(ExcelColumnEnum.MONTO.getKey()), formatter, evaluator);
//             if (montoStr != null && !montoStr.isEmpty()) {
//                 try {
//                     // Limpiamos la cadena de símbolos de moneda, espacios o comas de miles
//                     String cleanAmount = montoStr.replaceAll("[^\\d.]", "");
//                     BigDecimal amount = new BigDecimal(cleanAmount).setScale(2, RoundingMode.HALF_UP);
//                     dto.setAmount(amount);
//                 } catch (NumberFormatException e) {
//                     throw new IllegalArgumentException(
//                             "Invalid numeric amount format in the row " + dto.getRowIndex() + ": " + montoStr);
//                 }
//             } else {
//                 dto.setAmount(BigDecimal.ZERO);
//             }

//             parsedInvoices.add(dto);
//         }

//         return parsedInvoices;
//     }

//     /**
//      * Lee la primera fila y crea un diccionario K: NombreColumna, V: Índice.
//      */
//     private Map<String, Integer> buildHeaderIndexMap(Row headerRow, DataFormatter formatter) {
//         Map<String, Integer> map = new HashMap<>();
//         for (Cell cell : headerRow) {
//             String headerName = formatter.formatCellValue(cell).trim().toLowerCase();
//             if (!headerName.isEmpty()) {
//                 map.put(headerName, cell.getColumnIndex());
//             }
//         }
//         return map;
//     }

//     /**
//      * Valida cruzando el mapa de cabeceras extraído contra las reglas definidas en
//      * el Enum.
//      */
//     private void validateRequiredHeaders(Map<String, Integer> headerIndexMap) {
//         for (ExcelColumnEnum column : ExcelColumnEnum.values()) {
//             if (column.isRequired() && !headerIndexMap.containsKey(column.getKey())) {
//                 throw new IllegalArgumentException("Falta la columna requerida en el Excel: " + column.getKey());
//             }
//         }
//     }

//     /**
//      * Helper para extraer de forma segura el texto de una celda, procesando
//      * fórmulas y formatos visuales.
//      */
//     private String getCellValue(Row row, Integer cellIndex, DataFormatter formatter, FormulaEvaluator evaluator) {
//         if (cellIndex == null)
//             return null; // La columna no vino en el Excel (aplica si era opcional)
//         Cell cell = row.getCell(cellIndex);
//         if (cell == null)
//             return null;

//         return formatter.formatCellValue(cell, evaluator).trim();
//     }

//     /**
//      * Helper para detectar si una fila física de Excel no contiene ningún dato
//      * real.
//      */
//     private boolean isRowEmpty(Row row) {
//         for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
//             Cell cell = row.getCell(c);
//             if (cell != null && cell.getCellType() != CellType.BLANK) {
//                 return false;
//             }
//         }
//         return true;
//     }
    
// }
