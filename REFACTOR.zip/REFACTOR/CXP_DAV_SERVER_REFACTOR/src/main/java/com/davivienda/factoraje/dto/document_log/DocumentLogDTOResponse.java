package com.davivienda.factoraje.dto.document_log;

import java.util.UUID;

import com.davivienda.factoraje.domain.entities.DocumentLogModel;

public record DocumentLogDTOResponse(

    UUID id,
    UUID documentId,
    UUID userId,
    UUID acceptanceAuditId

) {

    public static DocumentLogDTOResponse fromEntity(DocumentLogModel model){
        
        return new DocumentLogDTOResponse(
        model.getId(),
        model.getDocument().getId(),
        model.getUser().getId(),
        model.getAcceptanceAudit().getId());
    }

}
