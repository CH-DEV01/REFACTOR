package com.davivienda.factoraje.domain.enums;

public enum RepaymentTypeEnum {

    PARTIAL,
    FULL
    
}
