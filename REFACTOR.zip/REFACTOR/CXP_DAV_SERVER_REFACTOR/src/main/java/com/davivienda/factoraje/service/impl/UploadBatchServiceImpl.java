package com.davivienda.factoraje.service.impl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import com.davivienda.factoraje.domain.entities.UploadBatchModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.dto.upload_batch.UploadBatchDTORequest;
import com.davivienda.factoraje.dto.upload_batch.UploadBatchDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.UploadBatchRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.UploadBatchService;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UploadBatchServiceImpl implements UploadBatchService {

    private final UploadBatchRepository uploadBatchRepository;
    private final UserRepository userRepository;

    public UploadBatchServiceImpl(
            UploadBatchRepository uploadBatchRepository,
            UserRepository userRepository) {
        this.uploadBatchRepository = uploadBatchRepository;
        this.userRepository = userRepository;
        log.info("UploadBatchService initialized");
    }

    private void validateUniqueness(UploadBatchDTORequest request) {

        log.info("Validating uniqueness for batchNumber: {}", request.batchNumber());
        
        boolean exists = uploadBatchRepository.existsByBatchNumber(request.batchNumber());

        // 2. Si ya existe, lanzamos la excepción de negocio
        if (exists) {
            log.warn("Business rule violation: Attempt to duplicate upload batch");
            throw new ResourceAlreadyExistsException("Upload Batch already exists.");
        }
    }

    @Transactional
    @Override
    public UploadBatchDTOResponse createUploadBatch(UploadBatchDTORequest request) {

        log.info("Initiating the creation of a new upload batch");

        validateUniqueness(request);

        UserModel uploadedAndApprovedBy = userRepository.findById(request.uploadedAndApprovedBy())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found with ID: " + request.uploadedAndApprovedBy()));

        UploadBatchModel uploadBatch = UploadBatchModel.builder()
                .batchNumber(request.batchNumber())
                .fileName(request.fileName())
                .totalRecords(request.totalRecords())
                .status(request.status())
                .uploadedAndApprovedBy(uploadedAndApprovedBy)
                .build();

        try {
            UploadBatchModel savedUploadBatch = uploadBatchRepository.save(uploadBatch);
            log.info("Upload batch created successfully with ID: {}", savedUploadBatch.getId());
            return UploadBatchDTOResponse.fromEntity(savedUploadBatch);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the entity. Possible race condition.", e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the entity. Possible race condition.");
        }

    }

}
