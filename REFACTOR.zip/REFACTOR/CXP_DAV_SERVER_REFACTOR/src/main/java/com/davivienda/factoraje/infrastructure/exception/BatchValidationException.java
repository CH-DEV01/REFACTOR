package com.davivienda.factoraje.infrastructure.exception;

import java.util.List;
import com.davivienda.factoraje.infrastructure.file_parser.excel.BatchValidationError;
import lombok.Getter;

@Getter
public class BatchValidationException extends RuntimeException {

    private final List<BatchValidationError> validationErrors;

    public BatchValidationException(String message, List<BatchValidationError> validationErrors) {
        super(message);
        this.validationErrors = validationErrors;
    }
}
