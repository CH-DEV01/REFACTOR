package com.davivienda.factoraje.infrastructure.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import com.davivienda.factoraje.domain.enums.BatchTypeEnum;

public class BatchNumberGeneratorUtil {
    
    // Constructor privado para evitar que alguien use 'new BatchNumberGeneratorUtil()'
    private BatchNumberGeneratorUtil() {} 

    public static String generateBatchNumber(BatchTypeEnum batchType) {
        // 1. Obtenemos la fecha en formato compacto (Ej. 20260917)
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        
        // 2. Generamos un código único de 6 caracteres
        String randomPart = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        
        // 3. Unimos todo: Prefijo + Fecha + Código Aleatorio
        // Ejemplo de salida: INV-20260917-A8B9C1
        return batchType.getPrefix() + "-" + datePart + "-" + randomPart;
    }
}
