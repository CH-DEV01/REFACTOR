package com.davivienda.factoraje.service.impl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.davivienda.factoraje.domain.catalogs.TermVersionCat;
import com.davivienda.factoraje.domain.entities.AcceptanceAuditModel;
import com.davivienda.factoraje.domain.entities.UserModel;
import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTORequest;
import com.davivienda.factoraje.dto.acceptance_audit.AcceptanceAuditDTOResponse;
import com.davivienda.factoraje.infrastructure.exception.ResourceAlreadyExistsException;
import com.davivienda.factoraje.infrastructure.exception.ResourceNotFoundException;
import com.davivienda.factoraje.repository.AcceptanceAuditRepository;
import com.davivienda.factoraje.repository.TermVersionCatRepository;
import com.davivienda.factoraje.repository.UserRepository;
import com.davivienda.factoraje.service.AcceptanceAuditService;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AcceptanceAuditServiceImpl implements AcceptanceAuditService {

    private final AcceptanceAuditRepository acceptanceAuditRepository;
    private final UserRepository userRepository;
    private final TermVersionCatRepository termVersionCatRepository;

    public AcceptanceAuditServiceImpl(
            AcceptanceAuditRepository acceptanceAuditRepository,
            UserRepository userRepository,
            TermVersionCatRepository termVersionCatRepository) {
        this.acceptanceAuditRepository = acceptanceAuditRepository;
        this.userRepository = userRepository;
        this.termVersionCatRepository = termVersionCatRepository;
        log.info("AcceptanceService initialized");
    }

    @Override
    @Transactional
    public AcceptanceAuditDTOResponse createAcceptanceAudit(AcceptanceAuditDTORequest request) {

        log.info("Starting the creation of a new acceptance audit");

        UserModel user = userRepository.findById(request.userId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found with ID: " + request.userId()));

        TermVersionCat termVersion = termVersionCatRepository.findById(request.versionId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Term version not found with ID: " + request.versionId()));

        AcceptanceAuditModel acceptanceAuditModel = AcceptanceAuditModel.builder()
                .userAgent(request.userAgent())
                .user(user)
                .termVersion(termVersion)
                .build();

        try {
            AcceptanceAuditModel savedAcceptanceAudit = acceptanceAuditRepository.save(acceptanceAuditModel);
            log.info("Acceptance audit created successfully with ID: {}", savedAcceptanceAudit.getId());
            return AcceptanceAuditDTOResponse.fromEntity(savedAcceptanceAudit);

        } catch (DataIntegrityViolationException e) {
            // Captura violaciones de unicidad a nivel de Base de Datos por condiciones de
            // carrera)
            log.error("Integrity violation when attempting to save the acceptance audit. Possible race condition.",
                    e);
            throw new ResourceAlreadyExistsException(
                    "Integrity violation when attempting to save the acceptance audit. Possible race condition.");
        }

    }
}
