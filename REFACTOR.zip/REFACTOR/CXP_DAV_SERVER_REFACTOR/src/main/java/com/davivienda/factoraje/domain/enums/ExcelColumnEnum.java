package com.davivienda.factoraje.domain.enums;

public enum ExcelColumnEnum {

    FECHA_EMISION("fechaemision", true),
    MONTO("monto", true),
    NUM_DOCUMENTO("numerodocumento", true),
    PROVEEDOR("nombreproveedor", true),
    NIT("nit", true),
    CORREO("correoproveedor", true),
    CUENTA("cuentabancaria", true),
    CODIGO("codigo", true);

    private final String key;
    private final boolean required;

    ExcelColumnEnum(String key, boolean required) {
        this.key = key;
        this.required = required;
    }

    public String getKey() {
        return key;
    }

    public boolean isRequired() {
        return required;
    }
}
