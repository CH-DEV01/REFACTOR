// Se definen en .env.development / .env.production (ver .env.example).
const required = (name) => {
  const value = import.meta.env[name];
  if (!value) {
    throw new Error(`Falta la variable de entorno ${name}. Revise el archivo .env del ambiente.`);
  }
  return value.replace(/\/+$/, "");
};

export const API_BASE_URL = required("VITE_API_BASE_URL");
export const API_URL = `${API_BASE_URL}/api`;
export const PORTAL_URL = required("VITE_PORTAL_URL");
