export const requestKey = (request) =>
  request.batchId || `${request.dueDate}|${request.requestDate}|${request.disbursementDate}`;

export const todayIso = () => {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
};
