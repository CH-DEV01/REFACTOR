package com.davivienda.factoraje.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.davivienda.factoraje.domain.entities.SystemParameterModel;
import com.davivienda.factoraje.dto.sso.HandoffDTOResponse;
import com.davivienda.factoraje.dto.sso.OtcDTOResponse;
import com.davivienda.factoraje.repository.ParameterRepository;
import com.davivienda.factoraje.service.SsoService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class SsoServiceImpl implements SsoService {

    private final ParameterRepository parameterRepository;
    private final RestTemplate restTemplate;

    public SsoServiceImpl(ParameterRepository parameterRepository, RestTemplate restTemplate) {
        this.parameterRepository = parameterRepository;
        this.restTemplate = restTemplate;
        log.info("SsoServiceImpl initialized");
    }

    @Override
    public HandoffDTOResponse processHandoff(String appCode, String otc, String bearerTokenRequest) {

        log.info("Processing handoff for appCode: {}, otc: {}, bearerTokenRequest: {}", appCode, otc, bearerTokenRequest);

        try {

            SystemParameterModel myBearerToken = parameterRepository.findByKey("BEARER_TOKEN")
                .orElseThrow(() -> new RuntimeException("Bearer token not found"));

            SystemParameterModel payBearerToken = parameterRepository.findByKey("PAY_BEARER_TOKEN")
                .orElseThrow(() -> new RuntimeException("Pay bearer token not found"));

            SystemParameterModel myAppCode = parameterRepository.findByKey("APP_CODE")
                .orElseThrow(() -> new RuntimeException("App code not found"));

            SystemParameterModel payDaviviendaUrl = parameterRepository.findByKey("PAY_DAVIVIENDA_URL")
                .orElseThrow(() -> new RuntimeException("Pay Davivienda URL not found"));
            

            HttpHeaders headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");
            headers.set("X-Authorization", "Bearer " + payBearerToken.getValue());
            headers.set("Accept", "application/json");

            String jsonBody = "{\"otc\":\"" + otc + "\"}";
            log.info("JSON body: {}", jsonBody);
            log.info("Content-Length: {}", jsonBody.getBytes(StandardCharsets.UTF_8).length);

            HttpEntity<String> requestEntity = new HttpEntity<>(jsonBody, headers);

            log.info("Consumiendo servicio de validación de PAY-DAVIVIENDA");
            log.info("Request entity: {}", requestEntity);

            ResponseEntity<OtcDTOResponse> response = restTemplate.exchange(
                payDaviviendaUrl.getValue(), 
                HttpMethod.POST, 
                requestEntity, 
                OtcDTOResponse.class);

            OtcDTOResponse otcDTOResponse = response.getBody();

            if(otcDTOResponse == null || !Boolean.TRUE.equals(otcDTOResponse.getSuccess())) {
                log.error("Error al consumir el servicio de validación de PAY-DAVIVIENDA");
                throw new RuntimeException("Error al consumir el servicio de validación de PAY-DAVIVIENDA");
            }

            String status = otcDTOResponse.getData().getStatus();
            if(status == null || !status.equals("Validated")) {
                log.error("Error al consumir el servicio de validación de PAY-DAVIVIENDA");
                throw new RuntimeException("Error al consumir el servicio de validación de PAY-DAVIVIENDA");
            }

            // DUI
            String userIdentifier = otcDTOResponse.getData().getUser();
            String sessionToken = UUID.randomUUID().toString();

            
            
            
            
        } catch (Exception e) {
            log.error("Error processing handoff for appCode: {}, otc: {}, bearerTokenRequest: {}", appCode, otc, bearerTokenRequest, e);
            throw new RuntimeException("Error processing handoff", e);
        }


        return null;
    }
}
